import { Component, OnInit, ViewChild } from "@angular/core";
import { NavigationEnd, Router } from "@angular/router";
import { RouterExtensions } from "nativescript-angular/router";
import { DrawerTransitionBase, RadSideDrawer, SlideInOnTopTransition } from "nativescript-ui-sidedrawer";
import { filter } from "rxjs/operators";
import * as app from "tns-core-modules/application";
import * as ApplicationSettings from "application-settings";
const firebase = require("nativescript-plugin-firebase");
import { connectionType, getConnectionType, startMonitoring, stopMonitoring }from "tns-core-modules/connectivity";

@Component({
    moduleId: module.id,
    selector: "ns-app",
    templateUrl: "app.component.html"
})
export class AppComponent implements OnInit {
    private _activatedUrl: string;
    private _sideDrawerTransition: DrawerTransitionBase;
    appLoggedIn: boolean = false;
    constructor(private router: Router, private routerExtensions: RouterExtensions) {
        // Use the component constructor to inject services.
    }

    ngOnInit(): void {
        this._activatedUrl = "/home";
        this._sideDrawerTransition = new SlideInOnTopTransition();
        //this.CheckInternetConnection();
        this.router.events
            .pipe(filter((event: any) => event instanceof NavigationEnd))
            .subscribe((event: NavigationEnd) => this.ActivateURL(event));

        if (ApplicationSettings.getString("userid") != null) {
            this.loggedIn = true;
        }
    }

    // CheckInternetConnection(){
    //     connectivityModule.startMonitoring((newConnectionType) => {
    //         switch (newConnectionType) {
    //             case connectivityModule.connectionType.none:
    //                 console.log("Connection type changed to none.");
    //                 break;
    //             case connectivityModule.connectionType.wifi:
    //                 console.log("Connection type changed to WiFi.");
    //                 break;
    //             case connectivityModule.connectionType.mobile:
    //                 console.log("Connection type changed to mobile.");
    //                 break;
    //             default:
    //                 break;
    //         }
    //     });
    // }

    profileImage : any;
    username : string;
    email : string;
    loggedIn : boolean;
    ActivateURL(event:NavigationEnd)
    {
        this._activatedUrl = event.urlAfterRedirects;

        if(ApplicationSettings.getString("userid") != null)
        {
            this.loggedIn = true;
            this.profileImage = ApplicationSettings.getString("profileImage");
            this.email = ApplicationSettings.getString("email");
            this.username = ApplicationSettings.getString("username");
        }
        else{
            this.loggedIn = false;
            this.username = "Welcome Guest!";
            this.email = "";

            ApplicationSettings.remove("profileImage");
            ApplicationSettings.remove("email");
            ApplicationSettings.remove("username");
        }
        
    }

    get sideDrawerTransition(): DrawerTransitionBase {
        return this._sideDrawerTransition;
    }

    isComponentSelected(url: string): boolean {
        return this._activatedUrl === url;
    }

    onNavItemTap(navItemRoute: string): void {
        this.routerExtensions.navigate([navItemRoute], {
            transition: {
                name: "fade"
            }
        });

        const sideDrawer = <RadSideDrawer>app.getRootView();
        sideDrawer.closeDrawer();
    }

    Logout() {
        this.loggedIn = false;
        this.username = "Welcome Guest!";
        this.email = "";
        firebase.logout();
        this.routerExtensions.navigate(["signin"], {
            transition: {
                name: "fade"
            }
        });
    }
}
