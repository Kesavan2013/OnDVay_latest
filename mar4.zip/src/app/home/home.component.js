"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var app = require("tns-core-modules/application");
var Geolocation = require("nativescript-geolocation");
var date_picker_1 = require("tns-core-modules/ui/date-picker");
var bikepoolservice_1 = require("../shared/bikepoolservice");
var dialogs = require("tns-core-modules/ui/dialogs");
var router_1 = require("nativescript-angular/router");
var firebase = require("nativescript-plugin-firebase");
var ApplicationSettings = require("application-settings");
var router_2 = require("@angular/router");
var HomeComponent = /** @class */ (function () {
    function HomeComponent(bikepoolservice, routerExtensions, router) {
        this.bikepoolservice = bikepoolservice;
        this.routerExtensions = routerExtensions;
        this.router = router;
        this.currentLocation = "Triplicane";
        // Use the component constructor to inject providers.
    }
    HomeComponent.prototype.ngOnInit = function () {
        //this.ClearRideSettings();
        this.items = [];
        this.items.push("Car");
        this.items.push("Bike");
        // call setDatePickerTime method
        this.setDatePickerTime();
        // Init your component properties here.
        var location = this.getDeviceLocation();
        this.InitFireBasePlugIn();
        this.updateStatusAvail();
    };
    HomeComponent.prototype.setDatePickerTime = function () {
        var date = new Date();
        var datePicker = new date_picker_1.DatePicker();
        datePicker.day = date.getDate();
        datePicker.month = date.getMonth() + 1;
        datePicker.year = date.getFullYear();
        datePicker.date = new Date(); // using Date object
        datePicker.minDate = new Date(date.getFullYear(), date.getMonth() + 1, date.getDate());
        datePicker.maxDate = new Date(2040, 4, 20);
    };
    HomeComponent.prototype.updateStatusAvail = function () {
        var path = ".info/connected";
        var onValueEvent = function (result) {
            if (result.error) {
                console.log("error" + result.error);
            }
            else {
                console.log("connected: " + result.value);
            }
        };
        firebase.addValueEventListener(function (data) {
            if (data.value) {
                console.log('Status: Online');
            }
            else {
                console.log('Status: Offline');
            }
        }, '.info/connected');
    };
    HomeComponent.prototype.InitFireBasePlugIn = function () {
        var _this = this;
        firebase.init({
            //persist should be set to false as otherwise numbers aren't returned during livesync
            persist: false,
            url: "https://metroapplicationproject.firebaseio.com",
            onPushTokenReceivedCallback: function (token) {
                ApplicationSettings.setString('device_token', token);
                console.log('device token: ', token); // <-- add this
            },
            onMessageReceivedCallback: function (message) {
                var objNotificationMessage = message.data.value;
                console.log(message.data.value);
                var navigationExtras = {
                    queryParams: {
                        objNotificationMessage: objNotificationMessage
                    }
                };
                _this.router.navigate(["rideinfo"], navigationExtras);
            },
            notificationCallbackAndroid: function (message) {
                console.log(JSON.stringify(message));
                //if (message.foreground == false) {
                dialogs.alert({
                    title: "On d Vay",
                    message: "Riders Requested Notification",
                    okButtonText: "ok"
                });
                // } else {
                //     console.log("Message received when inside the app");
                // }
            },
            onAuthStateChanged: function (data) {
                console.log(JSON.stringify(data));
                if (data.loggedIn) {
                    ApplicationSettings.setString("userid", data.user.uid);
                }
                else {
                    ApplicationSettings.remove("userid");
                    console.log("OnAuthState" + data);
                }
            }
        }).then(function (instance) {
            console.log("firebase.init done");
            console.log(instance);
        }, function (error) {
            console.log("firebase.init error: " + error);
        });
    };
    HomeComponent.prototype.onDatePickerLoaded = function (data) {
    };
    HomeComponent.prototype.getDeviceLocation = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            Geolocation.enableLocationRequest().then(function () {
                Geolocation.getCurrentLocation({ timeout: 10000 }).then(function (location) {
                    resolve(location);
                    // Call updateDeviceLocation method
                    _this.userlatitude = location.latitude;
                    _this.userlongtitude = location.longitude;
                    _this.updateDeviceLocation(location.latitude, location.longitude);
                }).catch(function (error) {
                    reject(error);
                });
            });
        });
    };
    HomeComponent.prototype.updateDeviceLocation = function (lat, long) {
        var _this = this;
        this.FromLat = lat;
        this.FromLong = long;
        var formURL = "?prox=" + lat + "," + long;
        this.bikepoolservice.GetAddress(formURL).subscribe(function (address) { return _this.handleSuccessDeviceLoc(address); }, function (error) { return _this.handleErrorDeviceLoc(error); });
    };
    HomeComponent.prototype.handleSuccessDeviceLoc = function (success) {
        var objResult = success.Response.View[0].Result[0];
        this.currentLocation = objResult.Location.Address.Label;
        this.FromLat = objResult.Location.DisplayPosition.Latitude;
        this.FromLong = objResult.Location.DisplayPosition.Longitude;
        ApplicationSettings.setString("fromlat", this.FromLat.toString());
        ApplicationSettings.setString("fromlong", this.FromLong.toString());
    };
    HomeComponent.prototype.handleErrorDeviceLoc = function (error) { };
    HomeComponent.prototype.onSubmit = function (args) {
        var _this = this;
        var searchBar = args.object;
        this.bikepoolservice.GetAddressAC(searchBar.text).subscribe(function (ac) { return _this.handleACSuccess(ac); }, function (error) { return _this.handleACError(error); });
    };
    HomeComponent.prototype.setRideSettings = function () {
        // ApplicationSettings.setString("currentlocation",this.currentLocation);
        // ApplicationSettings.setString("tolocation",this.searchPhrase);
        // ApplicationSettings.setString("ridedistance",this.totalRideDistance);
        // ApplicationSettings.setString("ridetime",this.selectedRideTime);
        // ApplicationSettings.setString("fromlat",this.FromLat);
        // ApplicationSettings.setString("fromlong",this.FromLong);
        // ApplicationSettings.setString("tolat",this.ToLat);
        // ApplicationSettings.setString("tolong",this.ToLong);
    };
    HomeComponent.prototype.ClearRideSettings = function () {
        // ApplicationSettings.remove("currentlocation");
        // ApplicationSettings.remove("tolocation");
        // ApplicationSettings.remove("ridedistance");
        // ApplicationSettings.remove("ridetime");
        // ApplicationSettings.remove("fromlat");
        // ApplicationSettings.remove("fromlong");
        // ApplicationSettings.remove("tolat");
        // ApplicationSettings.remove("tolong");
    };
    HomeComponent.prototype.handleACSuccess = function (success) {
        var objResult = success.Response.View[0].Result[0];
        this.searchPhrase = objResult.Location.Address.Label;
        this.ToLat = objResult.Location.DisplayPosition.Latitude;
        this.ToLong = objResult.Location.DisplayPosition.Longitude;
        ApplicationSettings.setString("currentlocation", this.currentLocation);
        ApplicationSettings.setString("tolocation", this.searchPhrase);
        this.CalculateDistance();
    };
    HomeComponent.prototype.handleACError = function (error) { };
    HomeComponent.prototype.onTextChanged = function (args) {
        var searchBar = args.object;
    };
    HomeComponent.prototype.onClear = function (args) {
        var searchBar = args.object;
        searchBar.text = "";
        searchBar.hint = "Enter Location";
    };
    HomeComponent.prototype.onchange = function (args) {
        console.log("Drop Down selected index changed from " + args.oldIndex + " to " + args.newIndex);
    };
    HomeComponent.prototype.onopen = function () {
        console.log("Drop Down opened.");
    };
    HomeComponent.prototype.onclose = function () {
        console.log("Drop Down closed.");
    };
    HomeComponent.prototype.onDrawerButtonTap = function () {
        var sideDrawer = app.getRootView();
        sideDrawer.showDrawer();
    };
    HomeComponent.prototype.onFindRiders = function (event) {
        //this.setRideSettings();
        this.routerExtensions.navigate(["/riderslist"], { clearHistory: true });
    };
    HomeComponent.prototype.onPickerLoaded = function (args) {
        var timePicker = args.object;
        timePicker.hour = 9;
        timePicker.minute = 25;
    };
    HomeComponent.prototype.onTimeChanged = function (args) {
        var totalTime;
        var hour = args.value.getHours();
        var minutes = args.value.getMinutes();
        if (parseFloat(hour) >= 12) {
            var FormatHour = parseFloat(hour) - 12;
            this.selectedRideTime = (FormatHour == 0) ? "12" : FormatHour.toString() + " : " + minutes + " pm";
        }
        else {
            this.selectedRideTime = parseFloat(hour).toString() + " : " + minutes.toString() + " am";
        }
        ApplicationSettings.setString("ridetime", this.selectedRideTime);
        //this.setRideSettings();
    };
    HomeComponent.prototype.CalculateDistance = function () {
        var _this = this;
        var locationFrom = new Geolocation.Location();
        locationFrom.latitude = parseFloat(this.FromLat);
        locationFrom.longitude = parseFloat(this.FromLong);
        var locationTo = new Geolocation.Location();
        locationTo.latitude = parseFloat(this.ToLat);
        locationTo.longitude = parseFloat(this.ToLong);
        var url = "waypoint0=" + this.FromLat + "," + this.FromLong + "&waypoint1=" + this.ToLat + "," + this.ToLong;
        console.log(url);
        this.bikepoolservice.GetDistance(url).subscribe(function (distance) { return _this.distancesuccess(distance); }, function (error) { return _this.distanceerror(error); });
    };
    HomeComponent.prototype.distancesuccess = function (distance) {
        var dist = distance.response.route[0].summary.distance;
        var travelTime = distance.response.route[0].summary.travelTime;
        this.totalRideDistance = dist / 1000;
        ApplicationSettings.setString("ridedistance", this.totalRideDistance.toString(2));
    };
    HomeComponent.prototype.distanceerror = function (error) {
        console.log(error);
    };
    HomeComponent = __decorate([
        core_1.Component({
            selector: "Home",
            moduleId: module.id,
            templateUrl: "./home.component.html"
        }),
        __metadata("design:paramtypes", [bikepoolservice_1.BikePoolService, router_1.RouterExtensions,
            router_2.Router])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaG9tZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJob21lLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQUVsRCxrREFBb0Q7QUFDcEQsc0RBQXdEO0FBSXhELCtEQUE2RDtBQUc3RCw2REFBNEQ7QUFDNUQscURBQXVEO0FBQ3ZELHNEQUErRDtBQUMvRCxJQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsOEJBQThCLENBQUMsQ0FBQztBQUN6RCwwREFBNEQ7QUFDNUQsMENBQXlEO0FBT3pEO0lBV0ksdUJBQW9CLGVBQWtDLEVBQVUsZ0JBQWtDLEVBQ3RGLE1BQWE7UUFETCxvQkFBZSxHQUFmLGVBQWUsQ0FBbUI7UUFBVSxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWtCO1FBQ3RGLFdBQU0sR0FBTixNQUFNLENBQU87UUFWekIsb0JBQWUsR0FBVyxZQUFZLENBQUM7UUFXbkMscURBQXFEO0lBQ3pELENBQUM7SUFFRCxnQ0FBUSxHQUFSO1FBRUksMkJBQTJCO1FBQzNCLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRXhCLGdDQUFnQztRQUNoQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUV6Qix1Q0FBdUM7UUFDdkMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFFeEMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFFMUIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7SUFDN0IsQ0FBQztJQUVELHlDQUFpQixHQUFqQjtRQUNJLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7UUFDdEIsSUFBTSxVQUFVLEdBQUcsSUFBSSx3QkFBVSxFQUFFLENBQUM7UUFDcEMsVUFBVSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDaEMsVUFBVSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZDLFVBQVUsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3JDLFVBQVUsQ0FBQyxJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxDQUFDLG9CQUFvQjtRQUVsRCxVQUFVLENBQUMsT0FBTyxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZGLFVBQVUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQseUNBQWlCLEdBQWpCO1FBQ0ksSUFBSSxJQUFJLEdBQUcsaUJBQWlCLENBQUM7UUFDN0IsSUFBSSxZQUFZLEdBQUcsVUFBVSxNQUFNO1lBQy9CLElBQUksTUFBTSxDQUFDLEtBQUssRUFBRTtnQkFDZCxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDdkM7aUJBQU07Z0JBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQzdDO1FBQ0wsQ0FBQyxDQUFDO1FBRUYsUUFBUSxDQUFDLHFCQUFxQixDQUFDLFVBQUEsSUFBSTtZQUMvQixJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7Z0JBQ1osT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2FBQ2pDO2lCQUFNO2dCQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQzthQUNsQztRQUVMLENBQUMsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO0lBQzFCLENBQUM7SUFFRCwwQ0FBa0IsR0FBbEI7UUFBQSxpQkFxREM7UUFwREcsUUFBUSxDQUFDLElBQUksQ0FBQztZQUNWLHFGQUFxRjtZQUNyRixPQUFPLEVBQUUsS0FBSztZQUNkLEdBQUcsRUFBRSxnREFBZ0Q7WUFDckQsMkJBQTJCLEVBQUUsVUFBVSxLQUFLO2dCQUN4QyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLEtBQUssQ0FBQyxDQUFDO2dCQUNyRCxPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsZUFBZTtZQUN6RCxDQUFDO1lBRUQseUJBQXlCLEVBQUUsVUFBQyxPQUFZO2dCQUNwQyxJQUFJLHNCQUFzQixHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO2dCQUNoRCxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQy9CLElBQUksZ0JBQWdCLEdBQXFCO29CQUNyQyxXQUFXLEVBQUU7d0JBQ1Qsc0JBQXNCLHdCQUFBO3FCQUN6QjtpQkFDSixDQUFDO2dCQUVGLEtBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztZQUN4RCxDQUFDO1lBQ0gsMkJBQTJCLEVBQUUsVUFBQyxPQUFZO2dCQUN0QyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztnQkFFckMsb0NBQW9DO2dCQUNoQyxPQUFPLENBQUMsS0FBSyxDQUFDO29CQUNWLEtBQUssRUFBRSxVQUFVO29CQUNqQixPQUFPLEVBQUUsK0JBQStCO29CQUN4QyxZQUFZLEVBQUUsSUFBSTtpQkFDckIsQ0FBQyxDQUFDO2dCQUNQLFdBQVc7Z0JBQ1gsMkRBQTJEO2dCQUMzRCxJQUFJO1lBQ1IsQ0FBQztZQUNELGtCQUFrQixFQUFFLFVBQUMsSUFBUztnQkFDMUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUE7Z0JBQ2pDLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtvQkFDZixtQkFBbUIsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ3pEO3FCQUNJO29CQUNELG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDckMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLENBQUM7aUJBQ3JDO1lBQ0wsQ0FBQztTQUNKLENBQUMsQ0FBQyxJQUFJLENBQ0gsVUFBVSxRQUFRO1lBQ2QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQ2xDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDMUIsQ0FBQyxFQUNELFVBQVUsS0FBSztZQUNYLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDLENBQUM7UUFDakQsQ0FBQyxDQUNBLENBQUM7SUFDVixDQUFDO0lBRUQsMENBQWtCLEdBQWxCLFVBQW1CLElBQWU7SUFFbEMsQ0FBQztJQUtPLHlDQUFpQixHQUF6QjtRQUFBLGlCQWNDO1FBYkcsT0FBTyxJQUFJLE9BQU8sQ0FBQyxVQUFDLE9BQU8sRUFBRSxNQUFNO1lBQy9CLFdBQVcsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLElBQUksQ0FBQztnQkFDckMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUEsUUFBUTtvQkFDNUQsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUNsQixtQ0FBbUM7b0JBQ25DLEtBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQztvQkFDdEMsS0FBSSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDO29CQUN6QyxLQUFJLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ3JFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFBLEtBQUs7b0JBQ1YsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNsQixDQUFDLENBQUMsQ0FBQztZQUNQLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsNENBQW9CLEdBQXBCLFVBQXFCLEdBQUcsRUFBRSxJQUFJO1FBQTlCLGlCQU1DO1FBTEcsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUM7UUFBQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztRQUN6QyxJQUFJLE9BQU8sR0FBRyxRQUFRLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7UUFDMUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUM5QyxVQUFBLE9BQU8sSUFBSSxPQUFBLEtBQUksQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsRUFBcEMsQ0FBb0MsRUFDL0MsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLEVBQWhDLENBQWdDLENBQUMsQ0FBQTtJQUNsRCxDQUFDO0lBRUQsOENBQXNCLEdBQXRCLFVBQXVCLE9BQU87UUFDMUIsSUFBSSxTQUFTLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ25ELElBQUksQ0FBQyxlQUFlLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO1FBQ3hELElBQUksQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDO1FBQzNELElBQUksQ0FBQyxRQUFRLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDO1FBQzdELG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBQ2pFLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZFLENBQUM7SUFFRCw0Q0FBb0IsR0FBcEIsVUFBcUIsS0FBSyxJQUFHLENBQUM7SUFFdkIsZ0NBQVEsR0FBZixVQUFnQixJQUFJO1FBQXBCLGlCQUtDO1FBSkcsSUFBSSxTQUFTLEdBQWMsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUN2QyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUN2RCxVQUFBLEVBQUUsSUFBSSxPQUFBLEtBQUksQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLEVBQXhCLENBQXdCLEVBQzlCLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsRUFBekIsQ0FBeUIsQ0FBQyxDQUFBO0lBQzNDLENBQUM7SUFFRCx1Q0FBZSxHQUFmO1FBQ0kseUVBQXlFO1FBQ3pFLGlFQUFpRTtRQUNqRSx3RUFBd0U7UUFDeEUsbUVBQW1FO1FBQ25FLHlEQUF5RDtRQUN6RCwyREFBMkQ7UUFDM0QscURBQXFEO1FBQ3JELHVEQUF1RDtJQUMzRCxDQUFDO0lBRUQseUNBQWlCLEdBQWpCO1FBRUksaURBQWlEO1FBQ2pELDRDQUE0QztRQUM1Qyw4Q0FBOEM7UUFDOUMsMENBQTBDO1FBQzFDLHlDQUF5QztRQUN6QywwQ0FBMEM7UUFDMUMsdUNBQXVDO1FBQ3ZDLHdDQUF3QztJQUM1QyxDQUFDO0lBRUQsdUNBQWUsR0FBZixVQUFnQixPQUFPO1FBQ25CLElBQUksU0FBUyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsWUFBWSxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztRQUNyRCxJQUFJLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQztRQUN6RCxJQUFJLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQztRQUMzRCxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsaUJBQWlCLEVBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQ3RFLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQzlELElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO0lBQzdCLENBQUM7SUFFRCxxQ0FBYSxHQUFiLFVBQWMsS0FBSyxJQUFJLENBQUM7SUFFakIscUNBQWEsR0FBcEIsVUFBcUIsSUFBSTtRQUNyQixJQUFJLFNBQVMsR0FBYyxJQUFJLENBQUMsTUFBTSxDQUFDO0lBQzNDLENBQUM7SUFFTSwrQkFBTyxHQUFkLFVBQWUsSUFBSTtRQUNmLElBQUksU0FBUyxHQUFjLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDdkMsU0FBUyxDQUFDLElBQUksR0FBRyxFQUFFLENBQUM7UUFDcEIsU0FBUyxDQUFDLElBQUksR0FBRyxnQkFBZ0IsQ0FBQztJQUN0QyxDQUFDO0lBRU0sZ0NBQVEsR0FBZixVQUFnQixJQUFtQztRQUMvQyxPQUFPLENBQUMsR0FBRyxDQUFDLDJDQUF5QyxJQUFJLENBQUMsUUFBUSxZQUFPLElBQUksQ0FBQyxRQUFVLENBQUMsQ0FBQztJQUM5RixDQUFDO0lBRU0sOEJBQU0sR0FBYjtRQUNJLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRU0sK0JBQU8sR0FBZDtRQUNJLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQseUNBQWlCLEdBQWpCO1FBQ0ksSUFBTSxVQUFVLEdBQWtCLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNwRCxVQUFVLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVELG9DQUFZLEdBQVosVUFBYSxLQUFLO1FBQ2QseUJBQXlCO1FBQ3pCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRSxFQUFFLFlBQVksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFFRCxzQ0FBYyxHQUFkLFVBQWUsSUFBSTtRQUNmLElBQUksVUFBVSxHQUFlLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDekMsVUFBVSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUM7UUFDcEIsVUFBVSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUlELHFDQUFhLEdBQWIsVUFBYyxJQUFJO1FBRWQsSUFBSSxTQUFTLENBQUM7UUFDZCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2pDLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7UUFFdEMsSUFBRyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxFQUN6QjtZQUNJLElBQUksVUFBVSxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDdkMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsR0FBRyxLQUFLLEdBQUcsT0FBTyxHQUFHLEtBQUssQ0FBQztTQUN0RzthQUNHO1lBQ0EsSUFBSSxDQUFDLGdCQUFnQixHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUUsR0FBRyxLQUFLLEdBQUcsT0FBTyxDQUFDLFFBQVEsRUFBRSxHQUFHLEtBQUssQ0FBQztTQUM1RjtRQUNELG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDaEUseUJBQXlCO0lBQzdCLENBQUM7SUFFRCx5Q0FBaUIsR0FBakI7UUFBQSxpQkFlQztRQWRHLElBQUksWUFBWSxHQUFHLElBQUksV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQzlDLFlBQVksQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNqRCxZQUFZLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFbkQsSUFBSSxVQUFVLEdBQUcsSUFBSSxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDNUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzdDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUUvQyxJQUFJLEdBQUcsR0FBRyxZQUFZLEdBQUMsSUFBSSxDQUFDLE9BQU8sR0FBQyxHQUFHLEdBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRSxhQUFhLEdBQUMsSUFBSSxDQUFDLEtBQUssR0FBQyxHQUFHLEdBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQTtRQUMvRixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2pCLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FDM0MsVUFBQSxRQUFRLElBQUksT0FBQSxLQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxFQUE5QixDQUE4QixFQUMxQyxVQUFBLEtBQUssSUFBSSxPQUFBLEtBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLEVBQXpCLENBQXlCLENBQ3JDLENBQUE7SUFDTCxDQUFDO0lBRUQsdUNBQWUsR0FBZixVQUFnQixRQUFRO1FBRXBCLElBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUE7UUFDdEQsSUFBSSxVQUFVLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztRQUMvRCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxHQUFDLElBQUksQ0FBQztRQUNuQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNyRixDQUFDO0lBRUQscUNBQWEsR0FBYixVQUFjLEtBQUs7UUFFZixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3ZCLENBQUM7SUFuU1EsYUFBYTtRQUx6QixnQkFBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLE1BQU07WUFDaEIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFdBQVcsRUFBRSx1QkFBdUI7U0FDdkMsQ0FBQzt5Q0FZd0MsaUNBQWUsRUFBNkIseUJBQWdCO1lBQy9FLGVBQU07T0FaaEIsYUFBYSxDQW9TekI7SUFBRCxvQkFBQztDQUFBLEFBcFNELElBb1NDO0FBcFNZLHNDQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgUmFkU2lkZURyYXdlciB9IGZyb20gXCJuYXRpdmVzY3JpcHQtdWktc2lkZWRyYXdlclwiO1xuaW1wb3J0ICogYXMgYXBwIGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL2FwcGxpY2F0aW9uXCI7XG5pbXBvcnQgKiBhcyBHZW9sb2NhdGlvbiBmcm9tIFwibmF0aXZlc2NyaXB0LWdlb2xvY2F0aW9uXCI7XG5pbXBvcnQgeyBBY2N1cmFjeSB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL2VudW1zXCI7IC8vIHVzZWQgdG8gZGVzY3JpYmUgYXQgd2hhdCBhY2N1cmFjeSB0aGUgbG9jYXRpb24gc2hvdWxkIGJlIGdldFxuaW1wb3J0IHsgU2VhcmNoQmFyIH0gZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvdWkvc2VhcmNoLWJhclwiO1xuaW1wb3J0IHsgU2VsZWN0ZWRJbmRleENoYW5nZWRFdmVudERhdGEgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWRyb3AtZG93blwiO1xuaW1wb3J0IHsgRGF0ZVBpY2tlciB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL2RhdGUtcGlja2VyXCI7XG5pbXBvcnQgeyBUaW1lUGlja2VyIH0gZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvdWkvdGltZS1waWNrZXJcIjtcbmltcG9ydCB7IEV2ZW50RGF0YSwgT2JzZXJ2YWJsZSB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL2RhdGEvb2JzZXJ2YWJsZVwiO1xuaW1wb3J0IHsgQmlrZVBvb2xTZXJ2aWNlIH0gZnJvbSBcIi4uL3NoYXJlZC9iaWtlcG9vbHNlcnZpY2VcIjtcbmltcG9ydCAqIGFzIGRpYWxvZ3MgZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvdWkvZGlhbG9nc1wiO1xuaW1wb3J0IHsgUm91dGVyRXh0ZW5zaW9ucyB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9yb3V0ZXJcIjtcbmNvbnN0IGZpcmViYXNlID0gcmVxdWlyZShcIm5hdGl2ZXNjcmlwdC1wbHVnaW4tZmlyZWJhc2VcIik7XG5pbXBvcnQgKiBhcyBBcHBsaWNhdGlvblNldHRpbmdzIGZyb20gXCJhcHBsaWNhdGlvbi1zZXR0aW5nc1wiO1xuaW1wb3J0IHtSb3V0ZXIsIE5hdmlnYXRpb25FeHRyYXN9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcblxuQENvbXBvbmVudCh7XG4gICAgc2VsZWN0b3I6IFwiSG9tZVwiLFxuICAgIG1vZHVsZUlkOiBtb2R1bGUuaWQsXG4gICAgdGVtcGxhdGVVcmw6IFwiLi9ob21lLmNvbXBvbmVudC5odG1sXCJcbn0pXG5leHBvcnQgY2xhc3MgSG9tZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG5cbiAgICBjdXJyZW50TG9jYXRpb246IHN0cmluZyA9IFwiVHJpcGxpY2FuZVwiO1xuICAgIGl0ZW1zOiBhbnk7XG4gICAgc2VhcmNoUGhyYXNlOiBzdHJpbmc7XG4gICAgRnJvbUxhdDogc3RyaW5nO1xuICAgIEZyb21Mb25nOiBzdHJpbmc7XG4gICAgVG9MYXQ6IHN0cmluZztcbiAgICBUb0xvbmc6IHN0cmluZztcbiAgICB0b3RhbFJpZGVEaXN0YW5jZSA6IGFueTtcblxuICAgIGNvbnN0cnVjdG9yKHByaXZhdGUgYmlrZXBvb2xzZXJ2aWNlOiAoQmlrZVBvb2xTZXJ2aWNlKSwgcHJpdmF0ZSByb3V0ZXJFeHRlbnNpb25zOiBSb3V0ZXJFeHRlbnNpb25zLFxuICAgICAgICBwcml2YXRlIHJvdXRlcjpSb3V0ZXIpIHtcbiAgICAgICAgLy8gVXNlIHRoZSBjb21wb25lbnQgY29uc3RydWN0b3IgdG8gaW5qZWN0IHByb3ZpZGVycy5cbiAgICB9XG5cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcblxuICAgICAgICAvL3RoaXMuQ2xlYXJSaWRlU2V0dGluZ3MoKTtcbiAgICAgICAgdGhpcy5pdGVtcyA9IFtdO1xuICAgICAgICB0aGlzLml0ZW1zLnB1c2goXCJDYXJcIik7XG4gICAgICAgIHRoaXMuaXRlbXMucHVzaChcIkJpa2VcIik7XG5cbiAgICAgICAgLy8gY2FsbCBzZXREYXRlUGlja2VyVGltZSBtZXRob2RcbiAgICAgICAgdGhpcy5zZXREYXRlUGlja2VyVGltZSgpO1xuXG4gICAgICAgIC8vIEluaXQgeW91ciBjb21wb25lbnQgcHJvcGVydGllcyBoZXJlLlxuICAgICAgICBsZXQgbG9jYXRpb24gPSB0aGlzLmdldERldmljZUxvY2F0aW9uKCk7XG5cbiAgICAgICAgdGhpcy5Jbml0RmlyZUJhc2VQbHVnSW4oKTtcblxuICAgICAgICB0aGlzLnVwZGF0ZVN0YXR1c0F2YWlsKCk7XG4gICAgfVxuXG4gICAgc2V0RGF0ZVBpY2tlclRpbWUoKSB7XG4gICAgICAgIGxldCBkYXRlID0gbmV3IERhdGUoKTtcbiAgICAgICAgY29uc3QgZGF0ZVBpY2tlciA9IG5ldyBEYXRlUGlja2VyKCk7XG4gICAgICAgIGRhdGVQaWNrZXIuZGF5ID0gZGF0ZS5nZXREYXRlKCk7XG4gICAgICAgIGRhdGVQaWNrZXIubW9udGggPSBkYXRlLmdldE1vbnRoKCkgKyAxO1xuICAgICAgICBkYXRlUGlja2VyLnllYXIgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XG4gICAgICAgIGRhdGVQaWNrZXIuZGF0ZSA9IG5ldyBEYXRlKCk7IC8vIHVzaW5nIERhdGUgb2JqZWN0XG5cbiAgICAgICAgZGF0ZVBpY2tlci5taW5EYXRlID0gbmV3IERhdGUoZGF0ZS5nZXRGdWxsWWVhcigpLCBkYXRlLmdldE1vbnRoKCkgKyAxLCBkYXRlLmdldERhdGUoKSk7XG4gICAgICAgIGRhdGVQaWNrZXIubWF4RGF0ZSA9IG5ldyBEYXRlKDIwNDAsIDQsIDIwKTtcbiAgICB9XG5cbiAgICB1cGRhdGVTdGF0dXNBdmFpbCgpIHtcbiAgICAgICAgdmFyIHBhdGggPSBcIi5pbmZvL2Nvbm5lY3RlZFwiO1xuICAgICAgICB2YXIgb25WYWx1ZUV2ZW50ID0gZnVuY3Rpb24gKHJlc3VsdCkge1xuICAgICAgICAgICAgaWYgKHJlc3VsdC5lcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZXJyb3JcIiArIHJlc3VsdC5lcnJvcik7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiY29ubmVjdGVkOiBcIiArIHJlc3VsdC52YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgZmlyZWJhc2UuYWRkVmFsdWVFdmVudExpc3RlbmVyKGRhdGEgPT4ge1xuICAgICAgICAgICAgaWYgKGRhdGEudmFsdWUpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnU3RhdHVzOiBPbmxpbmUnKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ1N0YXR1czogT2ZmbGluZScpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgIH0sICcuaW5mby9jb25uZWN0ZWQnKTtcbiAgICB9XG5cbiAgICBJbml0RmlyZUJhc2VQbHVnSW4oKSB7XG4gICAgICAgIGZpcmViYXNlLmluaXQoe1xuICAgICAgICAgICAgLy9wZXJzaXN0IHNob3VsZCBiZSBzZXQgdG8gZmFsc2UgYXMgb3RoZXJ3aXNlIG51bWJlcnMgYXJlbid0IHJldHVybmVkIGR1cmluZyBsaXZlc3luY1xuICAgICAgICAgICAgcGVyc2lzdDogZmFsc2UsXG4gICAgICAgICAgICB1cmw6IFwiaHR0cHM6Ly9tZXRyb2FwcGxpY2F0aW9ucHJvamVjdC5maXJlYmFzZWlvLmNvbVwiLFxuICAgICAgICAgICAgb25QdXNoVG9rZW5SZWNlaXZlZENhbGxiYWNrOiBmdW5jdGlvbiAodG9rZW4pIHtcbiAgICAgICAgICAgICAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZygnZGV2aWNlX3Rva2VuJywgdG9rZW4pO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdkZXZpY2UgdG9rZW46ICcsIHRva2VuKTsgLy8gPC0tIGFkZCB0aGlzXG4gICAgICAgICAgICB9LFxuXG4gICAgICAgICAgICBvbk1lc3NhZ2VSZWNlaXZlZENhbGxiYWNrOiAobWVzc2FnZTogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgbGV0IG9iak5vdGlmaWNhdGlvbk1lc3NhZ2UgPSBtZXNzYWdlLmRhdGEudmFsdWU7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2cobWVzc2FnZS5kYXRhLnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgbGV0IG5hdmlnYXRpb25FeHRyYXM6IE5hdmlnYXRpb25FeHRyYXMgPSB7XG4gICAgICAgICAgICAgICAgICAgICBxdWVyeVBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgIG9iak5vdGlmaWNhdGlvbk1lc3NhZ2VcbiAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoW1wicmlkZWluZm9cIl0sIG5hdmlnYXRpb25FeHRyYXMpO1xuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgbm90aWZpY2F0aW9uQ2FsbGJhY2tBbmRyb2lkOiAobWVzc2FnZTogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkobWVzc2FnZSkpO1xuXG4gICAgICAgICAgICAgICAgLy9pZiAobWVzc2FnZS5mb3JlZ3JvdW5kID09IGZhbHNlKSB7XG4gICAgICAgICAgICAgICAgICAgIGRpYWxvZ3MuYWxlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiT24gZCBWYXlcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUmlkZXJzIFJlcXVlc3RlZCBOb3RpZmljYXRpb25cIixcbiAgICAgICAgICAgICAgICAgICAgICAgIG9rQnV0dG9uVGV4dDogXCJva1wiXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIC8vIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gICAgIGNvbnNvbGUubG9nKFwiTWVzc2FnZSByZWNlaXZlZCB3aGVuIGluc2lkZSB0aGUgYXBwXCIpO1xuICAgICAgICAgICAgICAgIC8vIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvbkF1dGhTdGF0ZUNoYW5nZWQ6IChkYXRhOiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhKU09OLnN0cmluZ2lmeShkYXRhKSlcbiAgICAgICAgICAgICAgICBpZiAoZGF0YS5sb2dnZWRJbikgeyAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwidXNlcmlkXCIsZGF0YS51c2VyLnVpZCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBBcHBsaWNhdGlvblNldHRpbmdzLnJlbW92ZShcInVzZXJpZFwiKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJPbkF1dGhTdGF0ZVwiICsgZGF0YSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KS50aGVuKFxuICAgICAgICAgICAgZnVuY3Rpb24gKGluc3RhbmNlKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJmaXJlYmFzZS5pbml0IGRvbmVcIik7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coaW5zdGFuY2UpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGZ1bmN0aW9uIChlcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZmlyZWJhc2UuaW5pdCBlcnJvcjogXCIgKyBlcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICApO1xuICAgIH1cblxuICAgIG9uRGF0ZVBpY2tlckxvYWRlZChkYXRhOiBFdmVudERhdGEpIHtcblxuICAgIH1cblxuICAgIHVzZXJsYXRpdHVkZSA6IGFueTtcbiAgICB1c2VybG9uZ3RpdHVkZSA6IGFueTtcblxuICAgIHByaXZhdGUgZ2V0RGV2aWNlTG9jYXRpb24oKTogUHJvbWlzZTxhbnk+IHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIEdlb2xvY2F0aW9uLmVuYWJsZUxvY2F0aW9uUmVxdWVzdCgpLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIEdlb2xvY2F0aW9uLmdldEN1cnJlbnRMb2NhdGlvbih7IHRpbWVvdXQ6IDEwMDAwIH0pLnRoZW4obG9jYXRpb24gPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXNvbHZlKGxvY2F0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgLy8gQ2FsbCB1cGRhdGVEZXZpY2VMb2NhdGlvbiBtZXRob2RcbiAgICAgICAgICAgICAgICAgICAgdGhpcy51c2VybGF0aXR1ZGUgPSBsb2NhdGlvbi5sYXRpdHVkZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy51c2VybG9uZ3RpdHVkZSA9IGxvY2F0aW9uLmxvbmdpdHVkZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy51cGRhdGVEZXZpY2VMb2NhdGlvbihsb2NhdGlvbi5sYXRpdHVkZSwgbG9jYXRpb24ubG9uZ2l0dWRlKTtcbiAgICAgICAgICAgICAgICB9KS5jYXRjaChlcnJvciA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnJvcik7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgdXBkYXRlRGV2aWNlTG9jYXRpb24obGF0LCBsb25nKSB7XG4gICAgICAgIHRoaXMuRnJvbUxhdCA9IGxhdDsgdGhpcy5Gcm9tTG9uZyA9IGxvbmc7XG4gICAgICAgIGxldCBmb3JtVVJMID0gXCI/cHJveD1cIiArIGxhdCArIFwiLFwiICsgbG9uZztcbiAgICAgICAgdGhpcy5iaWtlcG9vbHNlcnZpY2UuR2V0QWRkcmVzcyhmb3JtVVJMKS5zdWJzY3JpYmUoXG4gICAgICAgICAgICBhZGRyZXNzID0+IHRoaXMuaGFuZGxlU3VjY2Vzc0RldmljZUxvYyhhZGRyZXNzKSxcbiAgICAgICAgICAgIGVycm9yID0+IHRoaXMuaGFuZGxlRXJyb3JEZXZpY2VMb2MoZXJyb3IpKVxuICAgIH1cblxuICAgIGhhbmRsZVN1Y2Nlc3NEZXZpY2VMb2Moc3VjY2VzcykgeyAgICAgICAgXG4gICAgICAgIGxldCBvYmpSZXN1bHQgPSBzdWNjZXNzLlJlc3BvbnNlLlZpZXdbMF0uUmVzdWx0WzBdO1xuICAgICAgICB0aGlzLmN1cnJlbnRMb2NhdGlvbiA9IG9ialJlc3VsdC5Mb2NhdGlvbi5BZGRyZXNzLkxhYmVsOyAgICAgICAgXG4gICAgICAgIHRoaXMuRnJvbUxhdCA9IG9ialJlc3VsdC5Mb2NhdGlvbi5EaXNwbGF5UG9zaXRpb24uTGF0aXR1ZGU7XG4gICAgICAgIHRoaXMuRnJvbUxvbmcgPSBvYmpSZXN1bHQuTG9jYXRpb24uRGlzcGxheVBvc2l0aW9uLkxvbmdpdHVkZTtcbiAgICAgICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJmcm9tbGF0XCIsdGhpcy5Gcm9tTGF0LnRvU3RyaW5nKCkpO1xuICAgICAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcImZyb21sb25nXCIsdGhpcy5Gcm9tTG9uZy50b1N0cmluZygpKTtcbiAgICB9XG5cbiAgICBoYW5kbGVFcnJvckRldmljZUxvYyhlcnJvcikge31cblxuICAgIHB1YmxpYyBvblN1Ym1pdChhcmdzKSB7XG4gICAgICAgIGxldCBzZWFyY2hCYXIgPSA8U2VhcmNoQmFyPmFyZ3Mub2JqZWN0O1xuICAgICAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5HZXRBZGRyZXNzQUMoc2VhcmNoQmFyLnRleHQpLnN1YnNjcmliZShcbiAgICAgICAgICAgIGFjID0+IHRoaXMuaGFuZGxlQUNTdWNjZXNzKGFjKSxcbiAgICAgICAgICAgIGVycm9yID0+IHRoaXMuaGFuZGxlQUNFcnJvcihlcnJvcikpXG4gICAgfVxuXG4gICAgc2V0UmlkZVNldHRpbmdzKCl7XG4gICAgICAgIC8vIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwiY3VycmVudGxvY2F0aW9uXCIsdGhpcy5jdXJyZW50TG9jYXRpb24pO1xuICAgICAgICAvLyBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcInRvbG9jYXRpb25cIix0aGlzLnNlYXJjaFBocmFzZSk7XG4gICAgICAgIC8vIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwicmlkZWRpc3RhbmNlXCIsdGhpcy50b3RhbFJpZGVEaXN0YW5jZSk7XG4gICAgICAgIC8vIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwicmlkZXRpbWVcIix0aGlzLnNlbGVjdGVkUmlkZVRpbWUpO1xuICAgICAgICAvLyBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcImZyb21sYXRcIix0aGlzLkZyb21MYXQpO1xuICAgICAgICAvLyBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcImZyb21sb25nXCIsdGhpcy5Gcm9tTG9uZyk7XG4gICAgICAgIC8vIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwidG9sYXRcIix0aGlzLlRvTGF0KTtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJ0b2xvbmdcIix0aGlzLlRvTG9uZyk7XG4gICAgfVxuXG4gICAgQ2xlYXJSaWRlU2V0dGluZ3MoKVxuICAgIHtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5yZW1vdmUoXCJjdXJyZW50bG9jYXRpb25cIik7XG4gICAgICAgIC8vIEFwcGxpY2F0aW9uU2V0dGluZ3MucmVtb3ZlKFwidG9sb2NhdGlvblwiKTtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5yZW1vdmUoXCJyaWRlZGlzdGFuY2VcIik7XG4gICAgICAgIC8vIEFwcGxpY2F0aW9uU2V0dGluZ3MucmVtb3ZlKFwicmlkZXRpbWVcIik7XG4gICAgICAgIC8vIEFwcGxpY2F0aW9uU2V0dGluZ3MucmVtb3ZlKFwiZnJvbWxhdFwiKTtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5yZW1vdmUoXCJmcm9tbG9uZ1wiKTtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5yZW1vdmUoXCJ0b2xhdFwiKTtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5yZW1vdmUoXCJ0b2xvbmdcIik7XG4gICAgfVxuXG4gICAgaGFuZGxlQUNTdWNjZXNzKHN1Y2Nlc3MpIHtcbiAgICAgICAgbGV0IG9ialJlc3VsdCA9IHN1Y2Nlc3MuUmVzcG9uc2UuVmlld1swXS5SZXN1bHRbMF07ICAgICAgICBcbiAgICAgICAgdGhpcy5zZWFyY2hQaHJhc2UgPSBvYmpSZXN1bHQuTG9jYXRpb24uQWRkcmVzcy5MYWJlbDsgICAgICAgIFxuICAgICAgICB0aGlzLlRvTGF0ID0gb2JqUmVzdWx0LkxvY2F0aW9uLkRpc3BsYXlQb3NpdGlvbi5MYXRpdHVkZTtcbiAgICAgICAgdGhpcy5Ub0xvbmcgPSBvYmpSZXN1bHQuTG9jYXRpb24uRGlzcGxheVBvc2l0aW9uLkxvbmdpdHVkZTsgICAgICAgIFxuICAgICAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcImN1cnJlbnRsb2NhdGlvblwiLHRoaXMuY3VycmVudExvY2F0aW9uKTtcbiAgICAgICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJ0b2xvY2F0aW9uXCIsdGhpcy5zZWFyY2hQaHJhc2UpO1xuICAgICAgICB0aGlzLkNhbGN1bGF0ZURpc3RhbmNlKCk7ICAgICAgICBcbiAgICB9XG5cbiAgICBoYW5kbGVBQ0Vycm9yKGVycm9yKSB7IH1cblxuICAgIHB1YmxpYyBvblRleHRDaGFuZ2VkKGFyZ3MpIHtcbiAgICAgICAgbGV0IHNlYXJjaEJhciA9IDxTZWFyY2hCYXI+YXJncy5vYmplY3Q7XG4gICAgfVxuXG4gICAgcHVibGljIG9uQ2xlYXIoYXJncykge1xuICAgICAgICBsZXQgc2VhcmNoQmFyID0gPFNlYXJjaEJhcj5hcmdzLm9iamVjdDtcbiAgICAgICAgc2VhcmNoQmFyLnRleHQgPSBcIlwiO1xuICAgICAgICBzZWFyY2hCYXIuaGludCA9IFwiRW50ZXIgTG9jYXRpb25cIjtcbiAgICB9XG5cbiAgICBwdWJsaWMgb25jaGFuZ2UoYXJnczogU2VsZWN0ZWRJbmRleENoYW5nZWRFdmVudERhdGEpIHtcbiAgICAgICAgY29uc29sZS5sb2coYERyb3AgRG93biBzZWxlY3RlZCBpbmRleCBjaGFuZ2VkIGZyb20gJHthcmdzLm9sZEluZGV4fSB0byAke2FyZ3MubmV3SW5kZXh9YCk7XG4gICAgfVxuXG4gICAgcHVibGljIG9ub3BlbigpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJEcm9wIERvd24gb3BlbmVkLlwiKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgb25jbG9zZSgpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJEcm9wIERvd24gY2xvc2VkLlwiKTtcbiAgICB9XG5cbiAgICBvbkRyYXdlckJ1dHRvblRhcCgpOiB2b2lkIHtcbiAgICAgICAgY29uc3Qgc2lkZURyYXdlciA9IDxSYWRTaWRlRHJhd2VyPmFwcC5nZXRSb290VmlldygpO1xuICAgICAgICBzaWRlRHJhd2VyLnNob3dEcmF3ZXIoKTtcbiAgICB9XG5cbiAgICBvbkZpbmRSaWRlcnMoZXZlbnQpIHsgICAgICAgIFxuICAgICAgICAvL3RoaXMuc2V0UmlkZVNldHRpbmdzKCk7XG4gICAgICAgIHRoaXMucm91dGVyRXh0ZW5zaW9ucy5uYXZpZ2F0ZShbXCIvcmlkZXJzbGlzdFwiXSwgeyBjbGVhckhpc3Rvcnk6IHRydWUgfSk7XG4gICAgfVxuXG4gICAgb25QaWNrZXJMb2FkZWQoYXJncykge1xuICAgICAgICBsZXQgdGltZVBpY2tlciA9IDxUaW1lUGlja2VyPmFyZ3Mub2JqZWN0O1xuICAgICAgICB0aW1lUGlja2VyLmhvdXIgPSA5O1xuICAgICAgICB0aW1lUGlja2VyLm1pbnV0ZSA9IDI1O1xuICAgIH1cblxuICAgIHNlbGVjdGVkUmlkZVRpbWUgOiBzdHJpbmc7XG5cbiAgICBvblRpbWVDaGFuZ2VkKGFyZ3MpIHtcbiAgICAgICAgXG4gICAgICAgIGxldCB0b3RhbFRpbWU7XG4gICAgICAgIGxldCBob3VyID0gYXJncy52YWx1ZS5nZXRIb3VycygpO1xuICAgICAgICBsZXQgbWludXRlcyA9IGFyZ3MudmFsdWUuZ2V0TWludXRlcygpO1xuICAgICAgICBcbiAgICAgICAgaWYocGFyc2VGbG9hdChob3VyKSA+PSAxMilcbiAgICAgICAge1xuICAgICAgICAgICAgbGV0IEZvcm1hdEhvdXIgPSBwYXJzZUZsb2F0KGhvdXIpIC0gMTI7XG4gICAgICAgICAgICB0aGlzLnNlbGVjdGVkUmlkZVRpbWUgPSAoRm9ybWF0SG91ciA9PSAwKSA/IFwiMTJcIiA6IEZvcm1hdEhvdXIudG9TdHJpbmcoKSArIFwiIDogXCIgKyBtaW51dGVzICsgXCIgcG1cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNle1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZFJpZGVUaW1lID0gcGFyc2VGbG9hdChob3VyKS50b1N0cmluZygpICsgXCIgOiBcIiArIG1pbnV0ZXMudG9TdHJpbmcoKSArIFwiIGFtXCI7XG4gICAgICAgIH1cbiAgICAgICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJyaWRldGltZVwiLHRoaXMuc2VsZWN0ZWRSaWRlVGltZSk7XG4gICAgICAgIC8vdGhpcy5zZXRSaWRlU2V0dGluZ3MoKTtcbiAgICB9XG5cbiAgICBDYWxjdWxhdGVEaXN0YW5jZSgpe1xuICAgICAgICBsZXQgbG9jYXRpb25Gcm9tID0gbmV3IEdlb2xvY2F0aW9uLkxvY2F0aW9uKCk7XG4gICAgICAgIGxvY2F0aW9uRnJvbS5sYXRpdHVkZSA9IHBhcnNlRmxvYXQodGhpcy5Gcm9tTGF0KTtcbiAgICAgICAgbG9jYXRpb25Gcm9tLmxvbmdpdHVkZSA9IHBhcnNlRmxvYXQodGhpcy5Gcm9tTG9uZyk7XG5cbiAgICAgICAgbGV0IGxvY2F0aW9uVG8gPSBuZXcgR2VvbG9jYXRpb24uTG9jYXRpb24oKTtcbiAgICAgICAgbG9jYXRpb25Uby5sYXRpdHVkZSA9IHBhcnNlRmxvYXQodGhpcy5Ub0xhdCk7XG4gICAgICAgIGxvY2F0aW9uVG8ubG9uZ2l0dWRlID0gcGFyc2VGbG9hdCh0aGlzLlRvTG9uZyk7XG5cbiAgICAgICAgdmFyIHVybCA9IFwid2F5cG9pbnQwPVwiK3RoaXMuRnJvbUxhdCtcIixcIit0aGlzLkZyb21Mb25nICtcIiZ3YXlwb2ludDE9XCIrdGhpcy5Ub0xhdCtcIixcIit0aGlzLlRvTG9uZ1xuICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5HZXREaXN0YW5jZSh1cmwpLnN1YnNjcmliZShcbiAgICAgICAgICAgIGRpc3RhbmNlID0+IHRoaXMuZGlzdGFuY2VzdWNjZXNzKGRpc3RhbmNlKSxcbiAgICAgICAgICAgIGVycm9yID0+IHRoaXMuZGlzdGFuY2VlcnJvcihlcnJvcilcbiAgICAgICAgKVxuICAgIH1cblxuICAgIGRpc3RhbmNlc3VjY2VzcyhkaXN0YW5jZSlcbiAgICB7XG4gICAgICAgIGxldCBkaXN0ID0gZGlzdGFuY2UucmVzcG9uc2Uucm91dGVbMF0uc3VtbWFyeS5kaXN0YW5jZSAgICAgICAgXG4gICAgICAgIGxldCB0cmF2ZWxUaW1lID0gZGlzdGFuY2UucmVzcG9uc2Uucm91dGVbMF0uc3VtbWFyeS50cmF2ZWxUaW1lO1xuICAgICAgICB0aGlzLnRvdGFsUmlkZURpc3RhbmNlID0gZGlzdC8xMDAwO1xuICAgICAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcInJpZGVkaXN0YW5jZVwiLHRoaXMudG90YWxSaWRlRGlzdGFuY2UudG9TdHJpbmcoMikpO1xuICAgIH1cblxuICAgIGRpc3RhbmNlZXJyb3IoZXJyb3IpXG4gICAge1xuICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XG4gICAgfVxufVxuIl19