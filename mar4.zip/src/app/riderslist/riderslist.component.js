"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var app = require("tns-core-modules/application");
var bikepoolservice_1 = require("../shared/bikepoolservice");
var services_1 = require("../shared/services");
var ApplicationSettings = require("application-settings");
var Geolocation = require("nativescript-geolocation");
var RidersItem = /** @class */ (function () {
    function RidersItem(name, distance, status, userid, devicetoken, profilePhoto) {
        this.name = name;
        this.distance = distance;
        this.status = status;
        this.userid = userid;
        this.devicetoken = devicetoken;
        this.profilePhoto = profilePhoto;
    }
    return RidersItem;
}());
var RiderListComponent = /** @class */ (function () {
    function RiderListComponent(bikepoolservice) {
        var _this = this;
        this.bikepoolservice = bikepoolservice;
        this.dataItems = [];
        this.bikepoolservice.PostService(services_1.ServiceURL.RideUsers, null).subscribe(function (riders) { return _this.RidersListSuccess(riders); }, function (error) { return _this.RiderListError(error); });
    }
    RiderListComponent.prototype.RidersListSuccess = function (riders) {
        console.log(riders);
        for (var ride = 0; ride < riders.Data.length; ride++) {
            var distance = this.CalculateDistance(riders.Data[ride].latitude, riders.Data[ride].longitude);
            this.dataItems.push(new RidersItem(riders.Data[ride].username, distance.toString(), riders.Data[ride].status, riders.Data[ride].userid, riders.Data[ride].deviceToken, riders.Data[ride].profilePhoto));
        }
    };
    RiderListComponent.prototype.CalculateDistance = function (lat, long) {
        var locationFrom = new Geolocation.Location();
        locationFrom.latitude = parseFloat(ApplicationSettings.getString("fromlat"));
        locationFrom.longitude = parseFloat(ApplicationSettings.getString("fromlong"));
        var locationTo = new Geolocation.Location();
        locationTo.latitude = parseFloat(lat);
        locationTo.longitude = parseFloat(long);
        var distance = Geolocation.distance(locationFrom, locationTo);
        return (distance / 1000).toFixed(2).toString() + "kms";
    };
    RiderListComponent.prototype.RiderListError = function (error) {
    };
    RiderListComponent.prototype.ngOnInit = function () {
    };
    RiderListComponent.prototype.onDrawerButtonTap = function () {
        var sideDrawer = app.getRootView();
        sideDrawer.showDrawer();
    };
    RiderListComponent.prototype.onItemTap = function (args) {
        var _this = this;
        var selectedRider = this.dataItems[args.index];
        var objRideStatus = {
            userid: selectedRider.userid,
            rideStartTime: ApplicationSettings.getString("ridetime"),
            rideDistance: ApplicationSettings.getString("ridedistance"),
            currentLocation: ApplicationSettings.getString("currentlocation"),
            destinationLocation: ApplicationSettings.getString("tolocation"),
            deviceToken: selectedRider.devicetoken
        };
        console.log(objRideStatus);
        this.bikepoolservice.PostService(services_1.ServiceURL.RequestForRide, objRideStatus).subscribe(function (success) { return _this.RideStatusSuccess(success); }, function (error) { return _this.RideStatusError(error); });
    };
    RiderListComponent.prototype.RideStatusSuccess = function (response) {
        console.log(response);
    };
    RiderListComponent.prototype.RideStatusError = function (error) {
        console.log(error);
    };
    RiderListComponent.prototype.onRiderItemTap = function (item) {
        console.log(item);
    };
    RiderListComponent.prototype.onSetupItemView = function (args) {
        args.view.context.third = (args.index % 3 === 0);
    };
    RiderListComponent = __decorate([
        core_1.Component({
            selector: 'ns-riderslist',
            templateUrl: './riderslist.component.html',
            moduleId: module.id,
        }),
        __metadata("design:paramtypes", [bikepoolservice_1.BikePoolService])
    ], RiderListComponent);
    return RiderListComponent;
}());
exports.RiderListComponent = RiderListComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmlkZXJzbGlzdC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJyaWRlcnNsaXN0LmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQUVsRCxrREFBb0Q7QUFFcEQsNkRBQTJEO0FBQzNELCtDQUFnRDtBQUNoRCwwREFBNEQ7QUFDNUQsc0RBQXdEO0FBRXhEO0lBQ0Usb0JBQW1CLElBQVksRUFDdEIsUUFBZ0IsRUFBUyxNQUFjLEVBQVMsTUFBYyxFQUM5RCxXQUFrQixFQUFRLFlBQW1CO1FBRm5DLFNBQUksR0FBSixJQUFJLENBQVE7UUFDdEIsYUFBUSxHQUFSLFFBQVEsQ0FBUTtRQUFTLFdBQU0sR0FBTixNQUFNLENBQVE7UUFBUyxXQUFNLEdBQU4sTUFBTSxDQUFRO1FBQzlELGdCQUFXLEdBQVgsV0FBVyxDQUFPO1FBQVEsaUJBQVksR0FBWixZQUFZLENBQU87SUFBSSxDQUFDO0lBQzdELGlCQUFDO0FBQUQsQ0FBQyxBQUpELElBSUM7QUFPRDtJQWdDRSw0QkFBb0IsZUFBZ0M7UUFBcEQsaUJBT0M7UUFQbUIsb0JBQWUsR0FBZixlQUFlLENBQWlCO1FBQ2xELElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO1FBRXBCLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLHFCQUFVLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FDcEUsVUFBQSxNQUFNLElBQUksT0FBQSxLQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLEVBQTlCLENBQThCLEVBQ3hDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBMUIsQ0FBMEIsQ0FDcEMsQ0FBQTtJQUNILENBQUM7SUFqQ0QsOENBQWlCLEdBQWpCLFVBQWtCLE1BQU07UUFFdEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVwQixLQUFLLElBQUksSUFBSSxHQUFHLENBQUMsRUFBRSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDcEQsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUE7WUFDOUYsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLFFBQVEsRUFBRSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxFQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQTtTQUN0TTtJQUNILENBQUM7SUFFRCw4Q0FBaUIsR0FBakIsVUFBa0IsR0FBRyxFQUFFLElBQUk7UUFDekIsSUFBSSxZQUFZLEdBQUcsSUFBSSxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDOUMsWUFBWSxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7UUFDN0UsWUFBWSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7UUFFL0UsSUFBSSxVQUFVLEdBQUcsSUFBSSxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDNUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDdEMsVUFBVSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFeEMsSUFBSSxRQUFRLEdBQUcsV0FBVyxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDOUQsT0FBTyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEdBQUcsS0FBSyxDQUFDO0lBQ3pELENBQUM7SUFFRCwyQ0FBYyxHQUFkLFVBQWUsS0FBSztJQUVwQixDQUFDO0lBVUQscUNBQVEsR0FBUjtJQUNBLENBQUM7SUFFRCw4Q0FBaUIsR0FBakI7UUFDRSxJQUFNLFVBQVUsR0FBa0IsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3BELFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsc0NBQVMsR0FBVCxVQUFVLElBQUk7UUFBZCxpQkFtQkM7UUFsQkMsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFL0MsSUFBSSxhQUFhLEdBQ2pCO1lBQ0UsTUFBTSxFQUFHLGFBQWEsQ0FBQyxNQUFNO1lBQzdCLGFBQWEsRUFBRyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDO1lBQ3pELFlBQVksRUFBRyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDO1lBQzVELGVBQWUsRUFBRyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUM7WUFDbEUsbUJBQW1CLEVBQUcsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQztZQUNqRSxXQUFXLEVBQUcsYUFBYSxDQUFDLFdBQVc7U0FDeEMsQ0FBQTtRQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUM7UUFFM0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxjQUFjLEVBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUNqRixVQUFBLE9BQU8sSUFBRyxPQUFBLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsRUFBL0IsQ0FBK0IsRUFDekMsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxFQUEzQixDQUEyQixDQUNyQyxDQUFBO0lBQ0gsQ0FBQztJQUVELDhDQUFpQixHQUFqQixVQUFrQixRQUFRO1FBRXhCLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDeEIsQ0FBQztJQUVELDRDQUFlLEdBQWYsVUFBZ0IsS0FBSztRQUVuQixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3JCLENBQUM7SUFFRCwyQ0FBYyxHQUFkLFVBQWUsSUFBZ0I7UUFDN0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNwQixDQUFDO0lBRUQsNENBQWUsR0FBZixVQUFnQixJQUF1QjtRQUNyQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBdEZVLGtCQUFrQjtRQUw5QixnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLGVBQWU7WUFDekIsV0FBVyxFQUFFLDZCQUE2QjtZQUMxQyxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7U0FDcEIsQ0FBQzt5Q0FpQ3FDLGlDQUFlO09BaEN6QyxrQkFBa0IsQ0F1RjlCO0lBQUQseUJBQUM7Q0FBQSxBQXZGRCxJQXVGQztBQXZGWSxnREFBa0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUmFkU2lkZURyYXdlciB9IGZyb20gXCJuYXRpdmVzY3JpcHQtdWktc2lkZWRyYXdlclwiO1xuaW1wb3J0ICogYXMgYXBwIGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL2FwcGxpY2F0aW9uXCI7XG5pbXBvcnQgeyBTZXR1cEl0ZW1WaWV3QXJncyB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9kaXJlY3RpdmVzXCI7XG5pbXBvcnQgeyBCaWtlUG9vbFNlcnZpY2UgfSBmcm9tIFwiLi4vc2hhcmVkL2Jpa2Vwb29sc2VydmljZVwiXG5pbXBvcnQgeyBTZXJ2aWNlVVJMIH0gZnJvbSBcIi4uL3NoYXJlZC9zZXJ2aWNlc1wiO1xuaW1wb3J0ICogYXMgQXBwbGljYXRpb25TZXR0aW5ncyBmcm9tIFwiYXBwbGljYXRpb24tc2V0dGluZ3NcIjtcbmltcG9ydCAqIGFzIEdlb2xvY2F0aW9uIGZyb20gXCJuYXRpdmVzY3JpcHQtZ2VvbG9jYXRpb25cIjtcblxuY2xhc3MgUmlkZXJzSXRlbSB7XG4gIGNvbnN0cnVjdG9yKHB1YmxpYyBuYW1lOiBzdHJpbmcsXG4gICAgcHVibGljIGRpc3RhbmNlOiBzdHJpbmcsIHB1YmxpYyBzdGF0dXM6IHN0cmluZywgcHVibGljIHVzZXJpZDogc3RyaW5nLFxuICAgIHB1YmxpYyBkZXZpY2V0b2tlbjpzdHJpbmcscHVibGljIHByb2ZpbGVQaG90bzpzdHJpbmcpIHsgfVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICducy1yaWRlcnNsaXN0JyxcbiAgdGVtcGxhdGVVcmw6ICcuL3JpZGVyc2xpc3QuY29tcG9uZW50Lmh0bWwnLFxuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxufSlcbmV4cG9ydCBjbGFzcyBSaWRlckxpc3RDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuXG4gIHB1YmxpYyBkYXRhSXRlbXM6IEFycmF5PFJpZGVyc0l0ZW0+O1xuICBmcm9tTGF0OiBzdHJpbmc7XG4gIGZyb21Mb25nOiBzdHJpbmc7XG5cbiAgUmlkZXJzTGlzdFN1Y2Nlc3MocmlkZXJzKSB7XG5cbiAgICBjb25zb2xlLmxvZyhyaWRlcnMpO1xuXG4gICAgZm9yIChsZXQgcmlkZSA9IDA7IHJpZGUgPCByaWRlcnMuRGF0YS5sZW5ndGg7IHJpZGUrKykge1xuICAgICAgbGV0IGRpc3RhbmNlID0gdGhpcy5DYWxjdWxhdGVEaXN0YW5jZShyaWRlcnMuRGF0YVtyaWRlXS5sYXRpdHVkZSwgcmlkZXJzLkRhdGFbcmlkZV0ubG9uZ2l0dWRlKVxuICAgICAgdGhpcy5kYXRhSXRlbXMucHVzaChuZXcgUmlkZXJzSXRlbShyaWRlcnMuRGF0YVtyaWRlXS51c2VybmFtZSwgZGlzdGFuY2UudG9TdHJpbmcoKSwgcmlkZXJzLkRhdGFbcmlkZV0uc3RhdHVzLCByaWRlcnMuRGF0YVtyaWRlXS51c2VyaWQscmlkZXJzLkRhdGFbcmlkZV0uZGV2aWNlVG9rZW4scmlkZXJzLkRhdGFbcmlkZV0ucHJvZmlsZVBob3RvKSlcbiAgICB9XG4gIH1cblxuICBDYWxjdWxhdGVEaXN0YW5jZShsYXQsIGxvbmcpOiBhbnkge1xuICAgIGxldCBsb2NhdGlvbkZyb20gPSBuZXcgR2VvbG9jYXRpb24uTG9jYXRpb24oKTtcbiAgICBsb2NhdGlvbkZyb20ubGF0aXR1ZGUgPSBwYXJzZUZsb2F0KEFwcGxpY2F0aW9uU2V0dGluZ3MuZ2V0U3RyaW5nKFwiZnJvbWxhdFwiKSk7XG4gICAgbG9jYXRpb25Gcm9tLmxvbmdpdHVkZSA9IHBhcnNlRmxvYXQoQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJmcm9tbG9uZ1wiKSk7XG5cbiAgICBsZXQgbG9jYXRpb25UbyA9IG5ldyBHZW9sb2NhdGlvbi5Mb2NhdGlvbigpO1xuICAgIGxvY2F0aW9uVG8ubGF0aXR1ZGUgPSBwYXJzZUZsb2F0KGxhdCk7XG4gICAgbG9jYXRpb25Uby5sb25naXR1ZGUgPSBwYXJzZUZsb2F0KGxvbmcpO1xuXG4gICAgbGV0IGRpc3RhbmNlID0gR2VvbG9jYXRpb24uZGlzdGFuY2UobG9jYXRpb25Gcm9tLCBsb2NhdGlvblRvKTtcbiAgICByZXR1cm4gKGRpc3RhbmNlIC8gMTAwMCkudG9GaXhlZCgyKS50b1N0cmluZygpICsgXCJrbXNcIjtcbiAgfVxuXG4gIFJpZGVyTGlzdEVycm9yKGVycm9yKSB7XG5cbiAgfVxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGJpa2Vwb29sc2VydmljZTogQmlrZVBvb2xTZXJ2aWNlKSB7XG4gICAgdGhpcy5kYXRhSXRlbXMgPSBbXTtcblxuICAgIHRoaXMuYmlrZXBvb2xzZXJ2aWNlLlBvc3RTZXJ2aWNlKFNlcnZpY2VVUkwuUmlkZVVzZXJzLCBudWxsKS5zdWJzY3JpYmUoXG4gICAgICByaWRlcnMgPT4gdGhpcy5SaWRlcnNMaXN0U3VjY2VzcyhyaWRlcnMpLFxuICAgICAgZXJyb3IgPT4gdGhpcy5SaWRlckxpc3RFcnJvcihlcnJvcilcbiAgICApXG4gIH1cblxuICBuZ09uSW5pdCgpIHtcbiAgfVxuXG4gIG9uRHJhd2VyQnV0dG9uVGFwKCk6IHZvaWQge1xuICAgIGNvbnN0IHNpZGVEcmF3ZXIgPSA8UmFkU2lkZURyYXdlcj5hcHAuZ2V0Um9vdFZpZXcoKTtcbiAgICBzaWRlRHJhd2VyLnNob3dEcmF3ZXIoKTtcbiAgfVxuXG4gIG9uSXRlbVRhcChhcmdzKSB7XG4gICAgbGV0IHNlbGVjdGVkUmlkZXIgPSB0aGlzLmRhdGFJdGVtc1thcmdzLmluZGV4XTtcbiAgICBcbiAgICBsZXQgb2JqUmlkZVN0YXR1cyA9XG4gICAge1xuICAgICAgdXNlcmlkIDogc2VsZWN0ZWRSaWRlci51c2VyaWQsXG4gICAgICByaWRlU3RhcnRUaW1lIDogQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJyaWRldGltZVwiKSxcbiAgICAgIHJpZGVEaXN0YW5jZSA6IEFwcGxpY2F0aW9uU2V0dGluZ3MuZ2V0U3RyaW5nKFwicmlkZWRpc3RhbmNlXCIpLFxuICAgICAgY3VycmVudExvY2F0aW9uIDogQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJjdXJyZW50bG9jYXRpb25cIiksXG4gICAgICBkZXN0aW5hdGlvbkxvY2F0aW9uIDogQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJ0b2xvY2F0aW9uXCIpLFxuICAgICAgZGV2aWNlVG9rZW4gOiBzZWxlY3RlZFJpZGVyLmRldmljZXRva2VuXG4gICAgfVxuXG4gICAgY29uc29sZS5sb2cob2JqUmlkZVN0YXR1cyk7XG5cbiAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLlJlcXVlc3RGb3JSaWRlLG9ialJpZGVTdGF0dXMpLnN1YnNjcmliZShcbiAgICAgIHN1Y2Nlc3MgPT50aGlzLlJpZGVTdGF0dXNTdWNjZXNzKHN1Y2Nlc3MpLFxuICAgICAgZXJyb3IgPT4gdGhpcy5SaWRlU3RhdHVzRXJyb3IoZXJyb3IpXG4gICAgKVxuICB9XG5cbiAgUmlkZVN0YXR1c1N1Y2Nlc3MocmVzcG9uc2UpXG4gIHtcbiAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XG4gIH1cblxuICBSaWRlU3RhdHVzRXJyb3IoZXJyb3IpXG4gIHtcbiAgICBjb25zb2xlLmxvZyhlcnJvcik7XG4gIH1cblxuICBvblJpZGVySXRlbVRhcChpdGVtOiBSaWRlcnNJdGVtKSB7XG4gICAgY29uc29sZS5sb2coaXRlbSk7XG4gIH1cblxuICBvblNldHVwSXRlbVZpZXcoYXJnczogU2V0dXBJdGVtVmlld0FyZ3MpIHtcbiAgICBhcmdzLnZpZXcuY29udGV4dC50aGlyZCA9IChhcmdzLmluZGV4ICUgMyA9PT0gMCk7XG4gIH1cbn1cbiJdfQ==