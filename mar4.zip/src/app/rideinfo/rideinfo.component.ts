import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { BikePoolService} from "../shared/bikepoolservice";
import { ServiceURL } from "../shared/services"


@Component({
  selector: 'ns-rideinfo',
  templateUrl: './rideinfo.component.html',
  moduleId: module.id,
})
export class RideInfoComponent implements OnInit {

  public RideFromLocation: string;
  public RideToLocation: string;
  public RideDistance: string;
  public RidePickUpTime: string;
  public RideStatus : string;
  public RideFromDeviceToken : string;
  public RideContactNo : string;
  public riderContactNo : string;

  constructor(private route: ActivatedRoute,private bikepoolservice:BikePoolService) {
    this.route.queryParams.subscribe(params => {
      let notification = params["objNotificationMessage"];
      
      var objNotification = JSON.parse(notification);
      this.RideFromLocation = objNotification.rideLocation;
      this.RideToLocation = objNotification.destinationLocation;
      this.RideDistance = objNotification.rideDistance;
      this.RidePickUpTime = objNotification.rideStartTime;   
      this.RideStatus = objNotification.ridestatus;   
      this.RideFromDeviceToken = objNotification.device_token;
      if(objNotification.phoneNo != undefined)
      {
        this.RideContactNo = objNotification.phoneNo;
        console.log("RideContactno" + this.RideContactNo);
      }
      console.log("status" + this.RideStatus);
    });
  }

  ngOnInit() {
  }

  GetRideInformation(status) : any
  {
    var objdeviceToken = [];
    objdeviceToken.push({deviceToken : this.RideFromDeviceToken})

    console.log("Phoneno" + this.riderContactNo);
    var objRideStatus = {
      deviceToken : objdeviceToken,
      requestStatus : status,
      currentLocation : this.RideFromLocation,
      destinationLocation : this.RideToLocation,
      phoneNo : this.riderContactNo
    }

    return objRideStatus;
  }

  onAccept(event){
    
    var objRide = this.GetRideInformation(1);

    this.bikepoolservice.PostService(ServiceURL.RideStatus,objRide).subscribe(
      ride => console.log("success" + JSON.stringify(ride)),
      error => console.log("error" + error)
    )
  }

  OnCancel(event){
    var objRide = this.GetRideInformation(0);
    
        this.bikepoolservice.PostService(ServiceURL.RideStatus,objRide).subscribe(
          ride => console.log(ride),
          error => console.log(error)
        )
  }
  
}
