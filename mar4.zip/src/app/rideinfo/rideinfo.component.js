"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var bikepoolservice_1 = require("../shared/bikepoolservice");
var services_1 = require("../shared/services");
var RideInfoComponent = /** @class */ (function () {
    function RideInfoComponent(route, bikepoolservice) {
        var _this = this;
        this.route = route;
        this.bikepoolservice = bikepoolservice;
        this.route.queryParams.subscribe(function (params) {
            var notification = params["objNotificationMessage"];
            var objNotification = JSON.parse(notification);
            _this.RideFromLocation = objNotification.rideLocation;
            _this.RideToLocation = objNotification.destinationLocation;
            _this.RideDistance = objNotification.rideDistance;
            _this.RidePickUpTime = objNotification.rideStartTime;
            _this.RideStatus = objNotification.ridestatus;
            _this.RideFromDeviceToken = objNotification.device_token;
            if (objNotification.phoneNo != undefined) {
                _this.RideContactNo = objNotification.phoneNo;
                console.log("RideContactno" + _this.RideContactNo);
            }
            console.log("status" + _this.RideStatus);
        });
    }
    RideInfoComponent.prototype.ngOnInit = function () {
    };
    RideInfoComponent.prototype.GetRideInformation = function (status) {
        var objdeviceToken = [];
        objdeviceToken.push({ deviceToken: this.RideFromDeviceToken });
        console.log("Phoneno" + this.riderContactNo);
        var objRideStatus = {
            deviceToken: objdeviceToken,
            requestStatus: status,
            currentLocation: this.RideFromLocation,
            destinationLocation: this.RideToLocation,
            phoneNo: this.riderContactNo
        };
        return objRideStatus;
    };
    RideInfoComponent.prototype.onAccept = function (event) {
        var objRide = this.GetRideInformation(1);
        this.bikepoolservice.PostService(services_1.ServiceURL.RideStatus, objRide).subscribe(function (ride) { return console.log("success" + JSON.stringify(ride)); }, function (error) { return console.log("error" + error); });
    };
    RideInfoComponent.prototype.OnCancel = function (event) {
        var objRide = this.GetRideInformation(0);
        this.bikepoolservice.PostService(services_1.ServiceURL.RideStatus, objRide).subscribe(function (ride) { return console.log(ride); }, function (error) { return console.log(error); });
    };
    RideInfoComponent = __decorate([
        core_1.Component({
            selector: 'ns-rideinfo',
            templateUrl: './rideinfo.component.html',
            moduleId: module.id,
        }),
        __metadata("design:paramtypes", [router_1.ActivatedRoute, bikepoolservice_1.BikePoolService])
    ], RideInfoComponent);
    return RideInfoComponent;
}());
exports.RideInfoComponent = RideInfoComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmlkZWluZm8uY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicmlkZWluZm8uY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQWtEO0FBQ2xELDBDQUFpRDtBQUNqRCw2REFBMkQ7QUFDM0QsK0NBQStDO0FBUS9DO0lBV0UsMkJBQW9CLEtBQXFCLEVBQVMsZUFBK0I7UUFBakYsaUJBa0JDO1FBbEJtQixVQUFLLEdBQUwsS0FBSyxDQUFnQjtRQUFTLG9CQUFlLEdBQWYsZUFBZSxDQUFnQjtRQUMvRSxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsVUFBQSxNQUFNO1lBQ3JDLElBQUksWUFBWSxHQUFHLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1lBRXBELElBQUksZUFBZSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDL0MsS0FBSSxDQUFDLGdCQUFnQixHQUFHLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDckQsS0FBSSxDQUFDLGNBQWMsR0FBRyxlQUFlLENBQUMsbUJBQW1CLENBQUM7WUFDMUQsS0FBSSxDQUFDLFlBQVksR0FBRyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ2pELEtBQUksQ0FBQyxjQUFjLEdBQUcsZUFBZSxDQUFDLGFBQWEsQ0FBQztZQUNwRCxLQUFJLENBQUMsVUFBVSxHQUFHLGVBQWUsQ0FBQyxVQUFVLENBQUM7WUFDN0MsS0FBSSxDQUFDLG1CQUFtQixHQUFHLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDeEQsSUFBRyxlQUFlLENBQUMsT0FBTyxJQUFJLFNBQVMsRUFDdkM7Z0JBQ0UsS0FBSSxDQUFDLGFBQWEsR0FBRyxlQUFlLENBQUMsT0FBTyxDQUFDO2dCQUM3QyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsR0FBRyxLQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7YUFDbkQ7WUFDRCxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsR0FBRyxLQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDMUMsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsb0NBQVEsR0FBUjtJQUNBLENBQUM7SUFFRCw4Q0FBa0IsR0FBbEIsVUFBbUIsTUFBTTtRQUV2QixJQUFJLGNBQWMsR0FBRyxFQUFFLENBQUM7UUFDeEIsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFDLFdBQVcsRUFBRyxJQUFJLENBQUMsbUJBQW1CLEVBQUMsQ0FBQyxDQUFBO1FBRTdELE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUM3QyxJQUFJLGFBQWEsR0FBRztZQUNsQixXQUFXLEVBQUcsY0FBYztZQUM1QixhQUFhLEVBQUcsTUFBTTtZQUN0QixlQUFlLEVBQUcsSUFBSSxDQUFDLGdCQUFnQjtZQUN2QyxtQkFBbUIsRUFBRyxJQUFJLENBQUMsY0FBYztZQUN6QyxPQUFPLEVBQUcsSUFBSSxDQUFDLGNBQWM7U0FDOUIsQ0FBQTtRQUVELE9BQU8sYUFBYSxDQUFDO0lBQ3ZCLENBQUM7SUFFRCxvQ0FBUSxHQUFSLFVBQVMsS0FBSztRQUVaLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV6QyxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxxQkFBVSxDQUFDLFVBQVUsRUFBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQ3ZFLFVBQUEsSUFBSSxJQUFJLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUE3QyxDQUE2QyxFQUNyRCxVQUFBLEtBQUssSUFBSSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxFQUE1QixDQUE0QixDQUN0QyxDQUFBO0lBQ0gsQ0FBQztJQUVELG9DQUFRLEdBQVIsVUFBUyxLQUFLO1FBQ1osSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRXJDLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLHFCQUFVLENBQUMsVUFBVSxFQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FDdkUsVUFBQSxJQUFJLElBQUksT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFqQixDQUFpQixFQUN6QixVQUFBLEtBQUssSUFBSSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQWxCLENBQWtCLENBQzVCLENBQUE7SUFDUCxDQUFDO0lBcEVVLGlCQUFpQjtRQUw3QixnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLGFBQWE7WUFDdkIsV0FBVyxFQUFFLDJCQUEyQjtZQUN4QyxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7U0FDcEIsQ0FBQzt5Q0FZMkIsdUJBQWMsRUFBeUIsaUNBQWU7T0FYdEUsaUJBQWlCLENBc0U3QjtJQUFELHdCQUFDO0NBQUEsQUF0RUQsSUFzRUM7QUF0RVksOENBQWlCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFjdGl2YXRlZFJvdXRlIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgQmlrZVBvb2xTZXJ2aWNlfSBmcm9tIFwiLi4vc2hhcmVkL2Jpa2Vwb29sc2VydmljZVwiO1xuaW1wb3J0IHsgU2VydmljZVVSTCB9IGZyb20gXCIuLi9zaGFyZWQvc2VydmljZXNcIlxuXG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ25zLXJpZGVpbmZvJyxcbiAgdGVtcGxhdGVVcmw6ICcuL3JpZGVpbmZvLmNvbXBvbmVudC5odG1sJyxcbiAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcbn0pXG5leHBvcnQgY2xhc3MgUmlkZUluZm9Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuXG4gIHB1YmxpYyBSaWRlRnJvbUxvY2F0aW9uOiBzdHJpbmc7XG4gIHB1YmxpYyBSaWRlVG9Mb2NhdGlvbjogc3RyaW5nO1xuICBwdWJsaWMgUmlkZURpc3RhbmNlOiBzdHJpbmc7XG4gIHB1YmxpYyBSaWRlUGlja1VwVGltZTogc3RyaW5nO1xuICBwdWJsaWMgUmlkZVN0YXR1cyA6IHN0cmluZztcbiAgcHVibGljIFJpZGVGcm9tRGV2aWNlVG9rZW4gOiBzdHJpbmc7XG4gIHB1YmxpYyBSaWRlQ29udGFjdE5vIDogc3RyaW5nO1xuICBwdWJsaWMgcmlkZXJDb250YWN0Tm8gOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSByb3V0ZTogQWN0aXZhdGVkUm91dGUscHJpdmF0ZSBiaWtlcG9vbHNlcnZpY2U6QmlrZVBvb2xTZXJ2aWNlKSB7XG4gICAgdGhpcy5yb3V0ZS5xdWVyeVBhcmFtcy5zdWJzY3JpYmUocGFyYW1zID0+IHtcbiAgICAgIGxldCBub3RpZmljYXRpb24gPSBwYXJhbXNbXCJvYmpOb3RpZmljYXRpb25NZXNzYWdlXCJdO1xuICAgICAgXG4gICAgICB2YXIgb2JqTm90aWZpY2F0aW9uID0gSlNPTi5wYXJzZShub3RpZmljYXRpb24pO1xuICAgICAgdGhpcy5SaWRlRnJvbUxvY2F0aW9uID0gb2JqTm90aWZpY2F0aW9uLnJpZGVMb2NhdGlvbjtcbiAgICAgIHRoaXMuUmlkZVRvTG9jYXRpb24gPSBvYmpOb3RpZmljYXRpb24uZGVzdGluYXRpb25Mb2NhdGlvbjtcbiAgICAgIHRoaXMuUmlkZURpc3RhbmNlID0gb2JqTm90aWZpY2F0aW9uLnJpZGVEaXN0YW5jZTtcbiAgICAgIHRoaXMuUmlkZVBpY2tVcFRpbWUgPSBvYmpOb3RpZmljYXRpb24ucmlkZVN0YXJ0VGltZTsgICBcbiAgICAgIHRoaXMuUmlkZVN0YXR1cyA9IG9iak5vdGlmaWNhdGlvbi5yaWRlc3RhdHVzOyAgIFxuICAgICAgdGhpcy5SaWRlRnJvbURldmljZVRva2VuID0gb2JqTm90aWZpY2F0aW9uLmRldmljZV90b2tlbjtcbiAgICAgIGlmKG9iak5vdGlmaWNhdGlvbi5waG9uZU5vICE9IHVuZGVmaW5lZClcbiAgICAgIHtcbiAgICAgICAgdGhpcy5SaWRlQ29udGFjdE5vID0gb2JqTm90aWZpY2F0aW9uLnBob25lTm87XG4gICAgICAgIGNvbnNvbGUubG9nKFwiUmlkZUNvbnRhY3Rub1wiICsgdGhpcy5SaWRlQ29udGFjdE5vKTtcbiAgICAgIH1cbiAgICAgIGNvbnNvbGUubG9nKFwic3RhdHVzXCIgKyB0aGlzLlJpZGVTdGF0dXMpO1xuICAgIH0pO1xuICB9XG5cbiAgbmdPbkluaXQoKSB7XG4gIH1cblxuICBHZXRSaWRlSW5mb3JtYXRpb24oc3RhdHVzKSA6IGFueVxuICB7XG4gICAgdmFyIG9iamRldmljZVRva2VuID0gW107XG4gICAgb2JqZGV2aWNlVG9rZW4ucHVzaCh7ZGV2aWNlVG9rZW4gOiB0aGlzLlJpZGVGcm9tRGV2aWNlVG9rZW59KVxuXG4gICAgY29uc29sZS5sb2coXCJQaG9uZW5vXCIgKyB0aGlzLnJpZGVyQ29udGFjdE5vKTtcbiAgICB2YXIgb2JqUmlkZVN0YXR1cyA9IHtcbiAgICAgIGRldmljZVRva2VuIDogb2JqZGV2aWNlVG9rZW4sXG4gICAgICByZXF1ZXN0U3RhdHVzIDogc3RhdHVzLFxuICAgICAgY3VycmVudExvY2F0aW9uIDogdGhpcy5SaWRlRnJvbUxvY2F0aW9uLFxuICAgICAgZGVzdGluYXRpb25Mb2NhdGlvbiA6IHRoaXMuUmlkZVRvTG9jYXRpb24sXG4gICAgICBwaG9uZU5vIDogdGhpcy5yaWRlckNvbnRhY3ROb1xuICAgIH1cblxuICAgIHJldHVybiBvYmpSaWRlU3RhdHVzO1xuICB9XG5cbiAgb25BY2NlcHQoZXZlbnQpe1xuICAgIFxuICAgIHZhciBvYmpSaWRlID0gdGhpcy5HZXRSaWRlSW5mb3JtYXRpb24oMSk7XG5cbiAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLlJpZGVTdGF0dXMsb2JqUmlkZSkuc3Vic2NyaWJlKFxuICAgICAgcmlkZSA9PiBjb25zb2xlLmxvZyhcInN1Y2Nlc3NcIiArIEpTT04uc3RyaW5naWZ5KHJpZGUpKSxcbiAgICAgIGVycm9yID0+IGNvbnNvbGUubG9nKFwiZXJyb3JcIiArIGVycm9yKVxuICAgIClcbiAgfVxuXG4gIE9uQ2FuY2VsKGV2ZW50KXtcbiAgICB2YXIgb2JqUmlkZSA9IHRoaXMuR2V0UmlkZUluZm9ybWF0aW9uKDApO1xuICAgIFxuICAgICAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLlJpZGVTdGF0dXMsb2JqUmlkZSkuc3Vic2NyaWJlKFxuICAgICAgICAgIHJpZGUgPT4gY29uc29sZS5sb2cocmlkZSksXG4gICAgICAgICAgZXJyb3IgPT4gY29uc29sZS5sb2coZXJyb3IpXG4gICAgICAgIClcbiAgfVxuICBcbn1cbiJdfQ==