"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ServiceURL;
(function (ServiceURL) {
    ServiceURL[ServiceURL["searchLocation"] = 1] = "searchLocation";
    ServiceURL["RideStatus"] = "/RideStatus";
    ServiceURL["RequestForRide"] = "/RequestForRide";
    ServiceURL["GetMyRide"] = "/GetMyRide";
    ServiceURL["RideUsers"] = "/RideUsers";
    ServiceURL["ResetPassword"] = "/ResetPassword";
    ServiceURL["CreateWithSocialLogin"] = "/CreateWithSocialLogin";
    ServiceURL["SignUpOnDVay"] = "/SignInWithUserPwd";
    ServiceURL["Login"] = "/SignIn";
    ServiceURL["DeleteLogOutUser"] = "/DeleteLogOutUser";
    ServiceURL["RideUpdateUserLocation"] = "/RideUpdateUserLocation";
    ServiceURL["OfferRide"] = "/OfferRide";
    ServiceURL["ConfigureRider"] = "/ConfigureRider";
    ServiceURL["GetCongfigureRider"] = "/GetCongfigureRider";
    ServiceURL["GetUser"] = "/GetUser";
    ServiceURL["UpdateDeviceToken"] = "/UpdateDeviceId";
})(ServiceURL = exports.ServiceURL || (exports.ServiceURL = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJzZXJ2aWNlcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLElBQVksVUFpQlg7QUFqQkQsV0FBWSxVQUFVO0lBQ2xCLCtEQUFrQixDQUFBO0lBQ2xCLHdDQUEwQixDQUFBO0lBQzFCLGdEQUFrQyxDQUFBO0lBQ2xDLHNDQUF3QixDQUFBO0lBQ3hCLHNDQUF3QixDQUFBO0lBQ3hCLDhDQUFnQyxDQUFBO0lBQ2hDLDhEQUFnRCxDQUFBO0lBQ2hELGlEQUFtQyxDQUFBO0lBQ25DLCtCQUFpQixDQUFBO0lBQ2pCLG9EQUFzQyxDQUFBO0lBQ3RDLGdFQUFrRCxDQUFBO0lBQ2xELHNDQUF3QixDQUFBO0lBQ3hCLGdEQUFrQyxDQUFBO0lBQ2xDLHdEQUEwQyxDQUFBO0lBQzFDLGtDQUFvQixDQUFBO0lBQ3BCLG1EQUFxQyxDQUFBO0FBQ3pDLENBQUMsRUFqQlcsVUFBVSxHQUFWLGtCQUFVLEtBQVYsa0JBQVUsUUFpQnJCIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGVudW0gU2VydmljZVVSTCB7XHJcbiAgICBzZWFyY2hMb2NhdGlvbiA9IDEsXHJcbiAgICBSaWRlU3RhdHVzID0gXCIvUmlkZVN0YXR1c1wiLCAgICBcclxuICAgIFJlcXVlc3RGb3JSaWRlID0gXCIvUmVxdWVzdEZvclJpZGVcIiwgICAgXHJcbiAgICBHZXRNeVJpZGUgPSBcIi9HZXRNeVJpZGVcIixcclxuICAgIFJpZGVVc2VycyA9IFwiL1JpZGVVc2Vyc1wiLFxyXG4gICAgUmVzZXRQYXNzd29yZCA9IFwiL1Jlc2V0UGFzc3dvcmRcIixcclxuICAgIENyZWF0ZVdpdGhTb2NpYWxMb2dpbiA9IFwiL0NyZWF0ZVdpdGhTb2NpYWxMb2dpblwiLFxyXG4gICAgU2lnblVwT25EVmF5ID0gXCIvU2lnbkluV2l0aFVzZXJQd2RcIixcclxuICAgIExvZ2luID0gXCIvU2lnbkluXCIsXHJcbiAgICBEZWxldGVMb2dPdXRVc2VyID0gXCIvRGVsZXRlTG9nT3V0VXNlclwiLFxyXG4gICAgUmlkZVVwZGF0ZVVzZXJMb2NhdGlvbiA9IFwiL1JpZGVVcGRhdGVVc2VyTG9jYXRpb25cIixcclxuICAgIE9mZmVyUmlkZSA9IFwiL09mZmVyUmlkZVwiLFxyXG4gICAgQ29uZmlndXJlUmlkZXIgPSBcIi9Db25maWd1cmVSaWRlclwiLFxyXG4gICAgR2V0Q29uZ2ZpZ3VyZVJpZGVyID0gXCIvR2V0Q29uZ2ZpZ3VyZVJpZGVyXCIsXHJcbiAgICBHZXRVc2VyID0gXCIvR2V0VXNlclwiLFxyXG4gICAgVXBkYXRlRGV2aWNlVG9rZW4gPSBcIi9VcGRhdGVEZXZpY2VJZFwiXHJcbn0iXX0=