export class ConfigureRide{
    public ContactNumber:string;
    public VechileName : string;
    public VechileNumber : string;
    public Price : number;
    public userId : string;
}