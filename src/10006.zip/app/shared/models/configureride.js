"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ConfigureRide = /** @class */ (function () {
    function ConfigureRide() {
    }
    return ConfigureRide;
}());
exports.ConfigureRide = ConfigureRide;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlndXJlcmlkZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNvbmZpZ3VyZXJpZGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQTtJQUFBO0lBTUEsQ0FBQztJQUFELG9CQUFDO0FBQUQsQ0FBQyxBQU5ELElBTUM7QUFOWSxzQ0FBYSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBDb25maWd1cmVSaWRle1xyXG4gICAgcHVibGljIENvbnRhY3ROdW1iZXI6c3RyaW5nO1xyXG4gICAgcHVibGljIFZlY2hpbGVOYW1lIDogc3RyaW5nO1xyXG4gICAgcHVibGljIFZlY2hpbGVOdW1iZXIgOiBzdHJpbmc7XHJcbiAgICBwdWJsaWMgUHJpY2UgOiBudW1iZXI7XHJcbiAgICBwdWJsaWMgdXNlcklkIDogc3RyaW5nO1xyXG59Il19