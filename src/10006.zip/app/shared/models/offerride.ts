export class offer
{
    public PickLocation : any;
    public DropLocation : any;    
    public VehicleType : number;
    public VehicleTypeText : string
    public StartTime : Date;
    public userId : string;
    public UserName : string;    
    public offerRide : boolean;
    public latitude : number;
    public longitude : number;
}