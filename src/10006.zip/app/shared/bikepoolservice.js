"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/common/http");
var BikePoolService = /** @class */ (function () {
    function BikePoolService(httpClient) {
        this.httpClient = httpClient;
        this.baseUrl = 'https://us-central1-metroapplicationproject.cloudfunctions.net';
        this.HereAPI = 'https://reverse.geocoder.api.here.com/6.2/reversegeocode.json';
        this.HereUpdateAPI = 'https://route.api.here.com/routing/7.2/calculateroute.json?';
        this.HereAPIAppID = '&app_id=x3nC7Tuf3PC7PMmqdLQz';
        this.HereAPIAppCode = '&app_code=ukGcX7YnI7TS72VdZyHp_w';
        this.HereAPIGenCode = '&gen=9';
        this.HereAPIRetMode = '&mode=retrieveAddresses';
        this.AUTOCOMPLETION_URL = 'https://autocomplete.geocoder.api.here.com/6.2/suggest.json';
    }
    BikePoolService.prototype.createRequestOptions = function () {
        var headers = new http_1.HttpHeaders({
            "Content-Type": "application/json"
        });
        return headers;
    };
    BikePoolService.prototype.GetAddressAC = function (url) {
        //let params = "?" + this.HereAPIAppID + this.HereAPIAppCode+"&searchtext=" + url;
        return this.httpClient.get("https://geocoder.api.here.com/6.2/geocode.json?searchtext=" + url + "&app_id=x3nC7Tuf3PC7PMmqdLQz&app_code=ukGcX7YnI7TS72VdZyHp_w", { headers: this.createRequestOptions() });
    };
    BikePoolService.prototype.GetAddress = function (url) {
        url = url + this.HereAPIRetMode + this.HereAPIAppID + this.HereAPIAppCode;
        return this.httpClient.get(this.HereAPI + url);
    };
    BikePoolService.prototype.GetDistance = function (url) {
        //https://route.api.here.com/routing/7.2/calculateroute.json?waypoint0=13.02398,80.17639&waypoint1=12.97939,80.21847&mode=fastest;car;traffic:enabled&app_id=x3nC7Tuf3PC7PMmqdLQz&app_code=ukGcX7YnI7TS72VdZyHp_w
        //waypoint0=13.02398,80.17639&waypoint1=12.97939,80.21847&
        var objUrl = url + "&mode=fastest;car;traffic:enabled" + this.HereAPIAppID + this.HereAPIAppCode;
        return this.httpClient.get(this.HereUpdateAPI + objUrl);
    };
    BikePoolService.prototype.GetService = function (url) {
        this.httpClient.get(this.baseUrl + url);
    };
    BikePoolService.prototype.PostService = function (url, data) {
        return this.httpClient.post(this.baseUrl + url, data);
    };
    BikePoolService = __decorate([
        core_1.Injectable(),
        __param(0, core_1.Inject(http_1.HttpClient)),
        __metadata("design:paramtypes", [http_1.HttpClient])
    ], BikePoolService);
    return BikePoolService;
}());
exports.BikePoolService = BikePoolService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmlrZXBvb2xzZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYmlrZXBvb2xzZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQW1EO0FBRW5ELDZDQUEwRTtBQUkxRTtJQVdFLHlCQUF3QyxVQUFzQjtRQUF0QixlQUFVLEdBQVYsVUFBVSxDQUFZO1FBVDlELFlBQU8sR0FBWSxnRUFBZ0UsQ0FBQztRQUNwRixZQUFPLEdBQVcsK0RBQStELENBQUM7UUFDbEYsa0JBQWEsR0FBVyw2REFBNkQsQ0FBQztRQUN0RixpQkFBWSxHQUFXLDhCQUE4QixDQUFDO1FBQ3RELG1CQUFjLEdBQVksa0NBQWtDLENBQUM7UUFDN0QsbUJBQWMsR0FBVyxRQUFRLENBQUM7UUFDbEMsbUJBQWMsR0FBWSx5QkFBeUIsQ0FBQztRQUNwRCx1QkFBa0IsR0FBWSw2REFBNkQsQ0FBQTtJQUczRixDQUFDO0lBRU8sOENBQW9CLEdBQTVCO1FBQ0UsSUFBSSxPQUFPLEdBQUcsSUFBSSxrQkFBVyxDQUFDO1lBQzVCLGNBQWMsRUFBRSxrQkFBa0I7U0FDbkMsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxPQUFPLENBQUM7SUFDakIsQ0FBQztJQUVELHNDQUFZLEdBQVosVUFBYSxHQUFHO1FBRWQsa0ZBQWtGO1FBQ2xGLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsNERBQTRELEdBQUMsR0FBRyxHQUFDLDhEQUE4RCxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUN4TSxDQUFDO0lBRUQsb0NBQVUsR0FBVixVQUFXLEdBQUc7UUFFWixHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDO1FBQzFFLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRSxHQUFHLENBQUMsQ0FBQztJQUNoRCxDQUFDO0lBRUQscUNBQVcsR0FBWCxVQUFZLEdBQUc7UUFFYixpTkFBaU47UUFDak4sMERBQTBEO1FBQ3JELElBQUksTUFBTSxHQUFHLEdBQUcsR0FBRyxtQ0FBbUMsR0FBRyxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUM7UUFDdEcsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsYUFBYSxHQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3hELENBQUM7SUFFRCxvQ0FBVSxHQUFWLFVBQVcsR0FBRztRQUVWLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUVELHFDQUFXLEdBQVgsVUFBWSxHQUFHLEVBQUMsSUFBSTtRQUVoQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEdBQUMsR0FBRyxFQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFqRFUsZUFBZTtRQUQzQixpQkFBVSxFQUFFO1FBWUUsV0FBQSxhQUFNLENBQUMsaUJBQVUsQ0FBQyxDQUFBO3lDQUFxQixpQkFBVTtPQVhuRCxlQUFlLENBa0QzQjtJQUFELHNCQUFDO0NBQUEsQUFsREQsSUFrREM7QUFsRFksMENBQWUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlLCBJbmplY3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0IHsgSHR0cCwgUmVzcG9uc2UsIEhlYWRlcnMsIFJlcXVlc3RPcHRpb25zLCBVUkxTZWFyY2hQYXJhbXMgfSBmcm9tICdAYW5ndWxhci9odHRwJztcclxuaW1wb3J0IHsgSHR0cENsaWVudCwgSHR0cEhlYWRlcnMsIEh0dHBQYXJhbXMgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCdcclxuaW1wb3J0IHsgT2JzZXJ2YWJsZSwgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgQmlrZVBvb2xTZXJ2aWNlIHtcclxuXHJcbiAgYmFzZVVybCA6IHN0cmluZyA9ICdodHRwczovL3VzLWNlbnRyYWwxLW1ldHJvYXBwbGljYXRpb25wcm9qZWN0LmNsb3VkZnVuY3Rpb25zLm5ldCc7ICBcclxuICBIZXJlQVBJOiBzdHJpbmcgPSAnaHR0cHM6Ly9yZXZlcnNlLmdlb2NvZGVyLmFwaS5oZXJlLmNvbS82LjIvcmV2ZXJzZWdlb2NvZGUuanNvbic7XHJcbiAgSGVyZVVwZGF0ZUFQSTogc3RyaW5nID0gJ2h0dHBzOi8vcm91dGUuYXBpLmhlcmUuY29tL3JvdXRpbmcvNy4yL2NhbGN1bGF0ZXJvdXRlLmpzb24/JztcclxuICBIZXJlQVBJQXBwSUQgOiBzdHJpbmcgPScmYXBwX2lkPXgzbkM3VHVmM1BDN1BNbXFkTFF6JztcclxuICBIZXJlQVBJQXBwQ29kZSA6IHN0cmluZyA9ICcmYXBwX2NvZGU9dWtHY1g3WW5JN1RTNzJWZFp5SHBfdyc7XHJcbiAgSGVyZUFQSUdlbkNvZGUgOiBzdHJpbmcgPScmZ2VuPTknO1xyXG4gIEhlcmVBUElSZXRNb2RlIDogc3RyaW5nID0gJyZtb2RlPXJldHJpZXZlQWRkcmVzc2VzJztcclxuICBBVVRPQ09NUExFVElPTl9VUkwgOiBzdHJpbmcgPSAnaHR0cHM6Ly9hdXRvY29tcGxldGUuZ2VvY29kZXIuYXBpLmhlcmUuY29tLzYuMi9zdWdnZXN0Lmpzb24nXHJcbiAgXHJcbiAgY29uc3RydWN0b3IoQEluamVjdChIdHRwQ2xpZW50KSBwcml2YXRlIGh0dHBDbGllbnQ6IEh0dHBDbGllbnQpIHtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgY3JlYXRlUmVxdWVzdE9wdGlvbnMoKSB7XHJcbiAgICBsZXQgaGVhZGVycyA9IG5ldyBIdHRwSGVhZGVycyh7XHJcbiAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiXHJcbiAgICB9KTtcclxuICAgIHJldHVybiBoZWFkZXJzO1xyXG4gIH1cclxuXHJcbiAgR2V0QWRkcmVzc0FDKHVybCk6IE9ic2VydmFibGU8YW55PlxyXG4gIHtcclxuICAgIC8vbGV0IHBhcmFtcyA9IFwiP1wiICsgdGhpcy5IZXJlQVBJQXBwSUQgKyB0aGlzLkhlcmVBUElBcHBDb2RlK1wiJnNlYXJjaHRleHQ9XCIgKyB1cmw7XHJcbiAgICByZXR1cm4gdGhpcy5odHRwQ2xpZW50LmdldChcImh0dHBzOi8vZ2VvY29kZXIuYXBpLmhlcmUuY29tLzYuMi9nZW9jb2RlLmpzb24/c2VhcmNodGV4dD1cIit1cmwrXCImYXBwX2lkPXgzbkM3VHVmM1BDN1BNbXFkTFF6JmFwcF9jb2RlPXVrR2NYN1luSTdUUzcyVmRaeUhwX3dcIiwgeyBoZWFkZXJzOiB0aGlzLmNyZWF0ZVJlcXVlc3RPcHRpb25zKCkgfSk7XHJcbiAgfVxyXG5cclxuICBHZXRBZGRyZXNzKHVybCkgOiBPYnNlcnZhYmxlPGFueT5cclxuICB7XHJcbiAgICB1cmwgPSB1cmwgKyB0aGlzLkhlcmVBUElSZXRNb2RlICsgdGhpcy5IZXJlQVBJQXBwSUQgKyB0aGlzLkhlcmVBUElBcHBDb2RlO1xyXG4gICAgcmV0dXJuIHRoaXMuaHR0cENsaWVudC5nZXQodGhpcy5IZXJlQVBJKyB1cmwpO1xyXG4gIH1cclxuXHJcbiAgR2V0RGlzdGFuY2UodXJsKTpPYnNlcnZhYmxlPGFueT5cclxuICB7XHJcbiAgICAvL2h0dHBzOi8vcm91dGUuYXBpLmhlcmUuY29tL3JvdXRpbmcvNy4yL2NhbGN1bGF0ZXJvdXRlLmpzb24/d2F5cG9pbnQwPTEzLjAyMzk4LDgwLjE3NjM5JndheXBvaW50MT0xMi45NzkzOSw4MC4yMTg0NyZtb2RlPWZhc3Rlc3Q7Y2FyO3RyYWZmaWM6ZW5hYmxlZCZhcHBfaWQ9eDNuQzdUdWYzUEM3UE1tcWRMUXomYXBwX2NvZGU9dWtHY1g3WW5JN1RTNzJWZFp5SHBfd1xyXG4gICAgLy93YXlwb2ludDA9MTMuMDIzOTgsODAuMTc2Mzkmd2F5cG9pbnQxPTEyLjk3OTM5LDgwLjIxODQ3JlxyXG4gICAgICAgICB2YXIgb2JqVXJsID0gdXJsICsgXCImbW9kZT1mYXN0ZXN0O2Nhcjt0cmFmZmljOmVuYWJsZWRcIiArIHRoaXMuSGVyZUFQSUFwcElEICsgdGhpcy5IZXJlQVBJQXBwQ29kZTtcclxuICAgIHJldHVybiB0aGlzLmh0dHBDbGllbnQuZ2V0KHRoaXMuSGVyZVVwZGF0ZUFQSStvYmpVcmwpO1xyXG4gIH1cclxuXHJcbiAgR2V0U2VydmljZSh1cmwpIFxyXG4gIHtcclxuICAgICAgdGhpcy5odHRwQ2xpZW50LmdldCh0aGlzLmJhc2VVcmwgKyB1cmwpO1xyXG4gIH1cclxuXHJcbiAgUG9zdFNlcnZpY2UodXJsLGRhdGEpIDogT2JzZXJ2YWJsZTxhbnk+XHJcbiAge1xyXG4gICAgICByZXR1cm4gdGhpcy5odHRwQ2xpZW50LnBvc3QodGhpcy5iYXNlVXJsK3VybCxkYXRhKTtcclxuICB9XHJcbn0iXX0=