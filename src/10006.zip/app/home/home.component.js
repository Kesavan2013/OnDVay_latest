"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var app = require("tns-core-modules/application");
var Geolocation = require("nativescript-geolocation");
var date_picker_1 = require("tns-core-modules/ui/date-picker");
var bikepoolservice_1 = require("../shared/bikepoolservice");
var services_1 = require("../shared/services");
var dialogs = require("tns-core-modules/ui/dialogs");
var router_1 = require("nativescript-angular/router");
var firebase = require("nativescript-plugin-firebase");
var ApplicationSettings = require("application-settings");
var router_2 = require("@angular/router");
var offerride_1 = require("../shared/models/offerride");
var nativescript_loading_screen_1 = require("nativescript-loading-screen");
var HomeComponent = /** @class */ (function () {
    function HomeComponent(bikepoolservice, routerExtensions, router, zone) {
        this.bikepoolservice = bikepoolservice;
        this.routerExtensions = routerExtensions;
        this.router = router;
        this.zone = zone;
        this.currentLocation = "";
        // Use the component constructor to inject providers.
        this.loadingScreen = new nativescript_loading_screen_1.LoadingScreen();
    }
    HomeComponent.prototype.hideLoader = function () {
        //this.loader.hide();
        this.loadingScreen.close();
    };
    HomeComponent.prototype.LoaderShow = function () {
        //this.loader.show(this.options);
        this.loadingScreen.show({
            message: "Loading..."
        });
    };
    HomeComponent.prototype.ngOnInit = function () {
        // Init your component properties here.
        this.items = [];
        this.items.push("Car");
        this.items.push("Bike");
        this.offer = new offerride_1.offer();
        // call setDatePickerTime method
        this.setDatePickerTime();
        this.LoaderShow();
        var location = this.getDeviceLocation();
        this.InitFireBasePlugIn();
        this.updateStatusAvail();
    };
    HomeComponent.prototype.setDatePickerTime = function () {
        var date = new Date();
        var datePicker = new date_picker_1.DatePicker();
        datePicker.day = date.getDate();
        datePicker.month = date.getMonth() + 1;
        datePicker.year = date.getFullYear();
        datePicker.date = new Date(); // using Date object
        datePicker.minDate = new Date(date.getFullYear(), date.getMonth() + 1, date.getDate());
        datePicker.maxDate = new Date(2040, 4, 20);
    };
    HomeComponent.prototype.updateStatusAvail = function () {
        var _this = this;
        firebase.addValueEventListener(function (data) {
            var Status;
            if (data.value) {
                console.log('Status: Online');
                Status = "Online";
            }
            else {
                console.log('Status: Offline');
                Status = "Offline";
            }
            var objUpdateUserLocation = {
                userid: ApplicationSettings.getString("userid"),
                longitude: _this.FromLat,
                latitude: _this.FromLong,
                status: Status,
                deviceToken: ApplicationSettings.getString("device_token")
            };
            _this.bikepoolservice.PostService(services_1.ServiceURL.RideUpdateUserLocation, objUpdateUserLocation).subscribe(function (success) { return console.log(success); }, function (error) { return console.log("updatedevicelocation" + error); });
        }, '.info/connected');
    };
    HomeComponent.prototype.InitFireBasePlugIn = function () {
        var _this = this;
        firebase.init({
            //persist should be set to false as otherwise numbers aren't returned during livesync
            persist: false,
            url: "https://metroapplicationproject.firebaseio.com",
            onPushTokenReceivedCallback: function (token) {
                ApplicationSettings.setString('device_token', token);
                console.log("deviceToken" + ApplicationSettings.getString('device_token'));
            },
            onMessageReceivedCallback: function (message) {
                var objNotificationMessage = message.data.value;
                console.log(message.data.value);
                var navigationExtras = {
                    queryParams: {
                        objNotificationMessage: objNotificationMessage
                    }
                };
                _this.router.navigate(["rideinfo"], navigationExtras);
            },
            notificationCallbackAndroid: function (message) {
                console.log(JSON.stringify(message));
                //if (message.foreground == false) {
                dialogs.alert({
                    title: "On d Vay",
                    message: "Riders Requested Notification",
                    okButtonText: "ok"
                });
                // } else {
                //     console.log("Message received when inside the app");
                // }
            },
            onAuthStateChanged: function (data) {
                console.log("dataError" + JSON.stringify(data));
                if (data.loggedIn) {
                    ApplicationSettings.setString("userid", data.user.uid);
                    ApplicationSettings.setString("email", data.user.email);
                    ApplicationSettings.setString("username", data.user.name);
                    ApplicationSettings.setString("profileImageURL", data.user.profileImageURL);
                }
                else {
                    console.log("OnAuthState" + data);
                }
            }
        }).then(function (instance) {
            console.log("firebase.init done");
            console.log(instance);
        }, function (error) {
            console.log("firebase.init error: " + error);
        });
    };
    HomeComponent.prototype.getDeviceLocation = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            Geolocation.enableLocationRequest().then(function () {
                Geolocation.getCurrentLocation({ timeout: 10000 }).then(function (location) {
                    resolve(location);
                    // Call updateDeviceLocation method
                    _this.userlatitude = location.latitude;
                    _this.userlongtitude = location.longitude;
                    _this.updateDeviceLocation(13.061140, 80.282478);
                    // this.updateDeviceLocation(location.latitude, location.longitude);
                    _this.hideLoader();
                }).catch(function (error) {
                    reject(error);
                });
            });
        });
    };
    HomeComponent.prototype.updateDeviceLocation = function (lat, long) {
        var _this = this;
        this.LoaderShow();
        this.FromLat = lat;
        this.FromLong = long;
        var formURL = "?prox=" + lat + "," + long;
        this.bikepoolservice.GetAddress(formURL).subscribe(function (address) { return _this.handleSuccessDeviceLoc(address); }, function (error) { return _this.handleErrorDeviceLoc(error); });
    };
    HomeComponent.prototype.handleSuccessDeviceLoc = function (success) {
        this.hideLoader();
        var objResult = success.Response.View[0].Result[0];
        this.currentLocation = objResult.Location.Address.Label;
        this.offer.PickLocation = objResult.Location.Address.Label;
        this.FromLat = objResult.Location.DisplayPosition.Latitude;
        this.FromLong = objResult.Location.DisplayPosition.Longitude;
        ApplicationSettings.setString("fromlat", this.FromLat.toString());
        ApplicationSettings.setString("fromlong", this.FromLong.toString());
    };
    HomeComponent.prototype.handleErrorDeviceLoc = function (error) { this.hideLoader(); };
    HomeComponent.prototype.onSubmit = function (args) {
        var _this = this;
        this.LoaderShow();
        var searchBar = args.object;
        this.bikepoolservice.GetAddressAC(searchBar.text).subscribe(function (ac) { return _this.handleACSuccess(ac); }, function (error) { return _this.handleACError(error); });
    };
    HomeComponent.prototype.setRideSettings = function () { };
    HomeComponent.prototype.ClearRideSettings = function () { };
    HomeComponent.prototype.handleACSuccess = function (success) {
        this.hideLoader();
        var objResult = success.Response.View[0].Result[0];
        this.searchPhrase = objResult.Location.Address.Label;
        this.ToLat = objResult.Location.DisplayPosition.Latitude;
        this.ToLong = objResult.Location.DisplayPosition.Longitude;
        ApplicationSettings.setString("currentlocation", this.currentLocation);
        ApplicationSettings.setString("tolocation", this.searchPhrase);
        this.CalculateDistance();
    };
    HomeComponent.prototype.handleACError = function (error) { this.hideLoader(); };
    HomeComponent.prototype.onTextChanged = function (args) {
        var searchBar = args.object;
    };
    HomeComponent.prototype.onClear = function (args) {
        var searchBar = args.object;
        searchBar.text = "";
        searchBar.hint = "Enter Location";
    };
    HomeComponent.prototype.onchange = function (args) {
        console.log("Drop Down selected index changed from " + args.oldIndex + " to " + args.newIndex);
    };
    HomeComponent.prototype.onopen = function () {
        console.log("Drop Down opened.");
    };
    HomeComponent.prototype.onclose = function () {
        console.log("Drop Down closed.");
    };
    HomeComponent.prototype.onDrawerButtonTap = function () {
        var sideDrawer = app.getRootView();
        sideDrawer.showDrawer();
    };
    HomeComponent.prototype.onFindRiders = function (event) {
        //this.setRideSettings();        
        if (this.searchPhrase != undefined && this.searchPhrase != '') {
            this.RequestRide();
        }
        else {
            alert({
                title: "On d Vay",
                message: "Please Search Location to Find Riders",
                okButtonText: "Ok"
            });
        }
    };
    HomeComponent.prototype.onPickerLoaded = function (args) {
        var timePicker = args.object;
        var today = new Date();
        var time = today.getHours();
        timePicker.hour = time;
        timePicker.minute = today.getMinutes() + 10;
        var periodian = (timePicker.hour >= 12) ? "am" : "pm";
        this.selectedRideTime = timePicker.hour + timePicker.minute + periodian;
        ApplicationSettings.setString("ridetime", this.selectedRideTime);
    };
    HomeComponent.prototype.onTimeChanged = function (args) {
        var totalTime;
        var hour = args.value.getHours();
        var minutes = args.value.getMinutes();
        if (parseFloat(hour) >= 12) {
            var FormatHour = parseFloat(hour) - 12;
            this.selectedRideTime = (FormatHour == 0) ? "12" : FormatHour.toString() + " : " + minutes + " pm";
        }
        else {
            this.selectedRideTime = parseFloat(hour).toString() + " : " + minutes.toString() + " am";
        }
        ApplicationSettings.setString("ridetime", this.selectedRideTime);
        //this.setRideSettings();
    };
    HomeComponent.prototype.CalculateDistance = function () {
        var _this = this;
        var locationFrom = new Geolocation.Location();
        locationFrom.latitude = parseFloat(this.FromLat);
        locationFrom.longitude = parseFloat(this.FromLong);
        var locationTo = new Geolocation.Location();
        locationTo.latitude = parseFloat(this.ToLat);
        locationTo.longitude = parseFloat(this.ToLong);
        this.showLoader = true;
        var url = "waypoint0=" + this.FromLat + "," + this.FromLong + "&waypoint1=" + this.ToLat + "," + this.ToLong;
        console.log(url);
        this.bikepoolservice.GetDistance(url).subscribe(function (distance) { return _this.distancesuccess(distance); }, function (error) { return _this.distanceerror(error); });
    };
    HomeComponent.prototype.distancesuccess = function (distance) {
        this.showLoader = false;
        var dist = distance.response.route[0].summary.distance;
        var travelTime = distance.response.route[0].summary.travelTime;
        this.totalRideDistance = dist / 1000;
        ApplicationSettings.setString("ridedistance", this.totalRideDistance.toString(2));
    };
    HomeComponent.prototype.distanceerror = function (error) {
        this.showLoader = false;
        console.log(error);
    };
    HomeComponent.prototype.submitOfferSuccess = function (success) {
        this.hideLoader();
        //this.offer = new offer();
        dialogs.alert({
            title: "On d Vay",
            message: "Ride Offer Received !",
            okButtonText: "ok"
        });
    };
    HomeComponent.prototype.submitOfferError = function (error) {
        this.hideLoader();
    };
    HomeComponent.prototype.submitOfferRide = function (event) {
        var _this = this;
        this.LoaderShow();
        console.log(this.offer);
        this.offer.userId = ApplicationSettings.getString("userid");
        this.offer.VehicleTypeText = this.items[this.offer.VechileType];
        this.offer.DropLocation = this.searchPhrase;
        this.offer.offerRide = true;
        this.offer.latitude = parseFloat(this.FromLat);
        this.offer.longitude = parseFloat(this.FromLong);
        var minutes = (this.offer.StartTime.getMinutes().toString().length == 1) ?
            "0" + this.offer.StartTime.getMinutes().toString() :
            this.offer.StartTime.getMinutes().toString();
        this.offer.StartTime = this.offer.StartTime.getHours() + " : " + minutes;
        this.offer.UserName = ApplicationSettings.getString("email");
        var objOffer = { OfferRide: this.offer };
        this.showLoader = true;
        this.bikepoolservice.PostService(services_1.ServiceURL.OfferRide, objOffer).subscribe(function (success) { return _this.submitOfferSuccess(success); }, function (error) { return _this.submitOfferError(error); });
    };
    HomeComponent.prototype.RideRequestSuccess = function (success) {
        this.hideLoader();
        ApplicationSettings.setString("ridetime", this.selectedRideTime.toString());
        this.routerExtensions.navigate(["/riderslist"], { clearHistory: true });
    };
    HomeComponent.prototype.RideRequestError = function (error) {
        this.hideLoader();
    };
    HomeComponent.prototype.RequestRide = function () {
        var _this = this;
        var rideRequest = {
            userId: ApplicationSettings.getString("userid"),
            PickLocation: this.currentLocation,
            DropLocation: this.searchPhrase,
            latitude: parseFloat(this.FromLat),
            longitude: parseFloat(this.FromLong),
            UserName: ApplicationSettings.getString("email"),
            VehicleTypeText: this.items[this.selectedIndex],
            StartTime: "",
            offerRide: false
        };
        var minutes = (this.selectedRideTime.getMinutes().toString().length == 1) ?
            "0" + this.selectedRideTime.getMinutes().toString() :
            this.selectedRideTime.getMinutes().toString();
        rideRequest.StartTime = this.selectedRideTime + " : " + minutes;
        var objOffer = { OfferRide: rideRequest };
        this.showLoader = true;
        this.bikepoolservice.PostService(services_1.ServiceURL.OfferRide, objOffer).subscribe(function (success) { return _this.RideRequestSuccess(success); }, function (error) { return _this.RideRequestError(error); });
    };
    HomeComponent = __decorate([
        core_1.Component({
            selector: "Home",
            moduleId: module.id,
            templateUrl: "./home.component.html"
        }),
        __metadata("design:paramtypes", [bikepoolservice_1.BikePoolService, router_1.RouterExtensions,
            router_2.Router, core_1.NgZone])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaG9tZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJob21lLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUEwRDtBQUUxRCxrREFBb0Q7QUFDcEQsc0RBQXdEO0FBSXhELCtEQUE2RDtBQUc3RCw2REFBNEQ7QUFDNUQsK0NBQStDO0FBQy9DLHFEQUF1RDtBQUN2RCxzREFBK0Q7QUFDL0QsSUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLDhCQUE4QixDQUFDLENBQUM7QUFDekQsMERBQTREO0FBQzVELDBDQUEyRDtBQUUzRCx3REFBbUQ7QUFFbkQsMkVBQTREO0FBUTVEO0lBb0JJLHVCQUFvQixlQUFrQyxFQUFVLGdCQUFrQyxFQUN0RixNQUFjLEVBQVUsSUFBWTtRQUQ1QixvQkFBZSxHQUFmLGVBQWUsQ0FBbUI7UUFBVSxxQkFBZ0IsR0FBaEIsZ0JBQWdCLENBQWtCO1FBQ3RGLFdBQU0sR0FBTixNQUFNLENBQVE7UUFBVSxTQUFJLEdBQUosSUFBSSxDQUFRO1FBbkJoRCxvQkFBZSxHQUFXLEVBQUUsQ0FBQztRQW9CekIscURBQXFEO1FBQ3JELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSwyQ0FBYSxFQUFFLENBQUM7SUFDN0MsQ0FBQztJQUVELGtDQUFVLEdBQVY7UUFDSSxxQkFBcUI7UUFDckIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUMvQixDQUFDO0lBRUQsa0NBQVUsR0FBVjtRQUNJLGlDQUFpQztRQUNqQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQztZQUNwQixPQUFPLEVBQUUsWUFBWTtTQUN4QixDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQsZ0NBQVEsR0FBUjtRQUVJLHVDQUF1QztRQUN2QyxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNoQixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN2QixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUV4QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksaUJBQUssRUFBRSxDQUFDO1FBRXpCLGdDQUFnQztRQUNoQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUN6QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDeEMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDMUIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7SUFDN0IsQ0FBQztJQUVELHlDQUFpQixHQUFqQjtRQUNJLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7UUFDdEIsSUFBTSxVQUFVLEdBQUcsSUFBSSx3QkFBVSxFQUFFLENBQUM7UUFDcEMsVUFBVSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDaEMsVUFBVSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZDLFVBQVUsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3JDLFVBQVUsQ0FBQyxJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxDQUFDLG9CQUFvQjtRQUVsRCxVQUFVLENBQUMsT0FBTyxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZGLFVBQVUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQseUNBQWlCLEdBQWpCO1FBQUEsaUJBMEJDO1FBeEJHLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxVQUFBLElBQUk7WUFDL0IsSUFBSSxNQUFNLENBQUM7WUFDWCxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7Z0JBQ1osT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUM5QixNQUFNLEdBQUcsUUFBUSxDQUFDO2FBQ3JCO2lCQUFNO2dCQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQztnQkFDL0IsTUFBTSxHQUFHLFNBQVMsQ0FBQzthQUN0QjtZQUVELElBQUkscUJBQXFCLEdBQ3JCO2dCQUNJLE1BQU0sRUFBRSxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDO2dCQUMvQyxTQUFTLEVBQUUsS0FBSSxDQUFDLE9BQU87Z0JBQ3ZCLFFBQVEsRUFBRSxLQUFJLENBQUMsUUFBUTtnQkFDdkIsTUFBTSxFQUFFLE1BQU07Z0JBQ2QsV0FBVyxFQUFHLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUM7YUFDOUQsQ0FBQTtZQUVMLEtBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLHFCQUFVLENBQUMsc0JBQXNCLEVBQUUscUJBQXFCLENBQUMsQ0FBQyxTQUFTLENBQ2hHLFVBQUEsT0FBTyxJQUFJLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsRUFBcEIsQ0FBb0IsRUFDL0IsVUFBQSxLQUFLLElBQUksT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixHQUFHLEtBQUssQ0FBQyxFQUEzQyxDQUEyQyxDQUN2RCxDQUFBO1FBQ0wsQ0FBQyxFQUFFLGlCQUFpQixDQUFDLENBQUM7SUFDMUIsQ0FBQztJQUVELDBDQUFrQixHQUFsQjtRQUFBLGlCQXNEQztRQXJERyxRQUFRLENBQUMsSUFBSSxDQUFDO1lBQ1YscUZBQXFGO1lBQ3JGLE9BQU8sRUFBRSxLQUFLO1lBQ2QsR0FBRyxFQUFFLGdEQUFnRDtZQUNyRCwyQkFBMkIsRUFBRSxVQUFVLEtBQUs7Z0JBQ3hDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQ3JELE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxHQUFFLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFBO1lBQzdFLENBQUM7WUFDRCx5QkFBeUIsRUFBRSxVQUFDLE9BQVk7Z0JBQ3BDLElBQUksc0JBQXNCLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7Z0JBQ2hELE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDaEMsSUFBSSxnQkFBZ0IsR0FBcUI7b0JBQ3JDLFdBQVcsRUFBRTt3QkFDVCxzQkFBc0Isd0JBQUE7cUJBQ3pCO2lCQUNKLENBQUM7Z0JBRUYsS0FBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ3pELENBQUM7WUFDRCwyQkFBMkIsRUFBRSxVQUFDLE9BQVk7Z0JBQ3RDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUVyQyxvQ0FBb0M7Z0JBQ3BDLE9BQU8sQ0FBQyxLQUFLLENBQUM7b0JBQ1YsS0FBSyxFQUFFLFVBQVU7b0JBQ2pCLE9BQU8sRUFBRSwrQkFBK0I7b0JBQ3hDLFlBQVksRUFBRSxJQUFJO2lCQUNyQixDQUFDLENBQUM7Z0JBQ0gsV0FBVztnQkFDWCwyREFBMkQ7Z0JBQzNELElBQUk7WUFDUixDQUFDO1lBQ0Qsa0JBQWtCLEVBQUUsVUFBQyxJQUFTO2dCQUMxQixPQUFPLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUE7Z0JBQy9DLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtvQkFDZixtQkFBbUIsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ3ZELG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztvQkFDdkQsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUN6RCxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsaUJBQWlCLEVBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztpQkFDOUU7cUJBQ0k7b0JBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLENBQUM7aUJBQ3JDO1lBQ0wsQ0FBQztTQUNKLENBQUMsQ0FBQyxJQUFJLENBQ0gsVUFBVSxRQUFRO1lBQ2QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQ2xDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDMUIsQ0FBQyxFQUNELFVBQVUsS0FBSztZQUNYLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLEdBQUcsS0FBSyxDQUFDLENBQUM7UUFDakQsQ0FBQyxDQUNBLENBQUM7SUFDVixDQUFDO0lBRU8seUNBQWlCLEdBQXpCO1FBQUEsaUJBZ0JDO1FBZkcsT0FBTyxJQUFJLE9BQU8sQ0FBQyxVQUFDLE9BQU8sRUFBRSxNQUFNO1lBQy9CLFdBQVcsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLElBQUksQ0FBQztnQkFDckMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUEsUUFBUTtvQkFDNUQsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUNsQixtQ0FBbUM7b0JBQ25DLEtBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQztvQkFDdEMsS0FBSSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDO29CQUN6QyxLQUFJLENBQUMsb0JBQW9CLENBQUMsU0FBUyxFQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUNoRCxvRUFBb0U7b0JBQ25FLEtBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDdEIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQUEsS0FBSztvQkFDVixNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ2xCLENBQUMsQ0FBQyxDQUFDO1lBQ1AsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCw0Q0FBb0IsR0FBcEIsVUFBcUIsR0FBRyxFQUFFLElBQUk7UUFBOUIsaUJBT0M7UUFORyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUM7UUFBQyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztRQUN6QyxJQUFJLE9BQU8sR0FBRyxRQUFRLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7UUFDMUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUM5QyxVQUFBLE9BQU8sSUFBSSxPQUFBLEtBQUksQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsRUFBcEMsQ0FBb0MsRUFDL0MsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLEVBQWhDLENBQWdDLENBQUMsQ0FBQTtJQUNsRCxDQUFDO0lBRUQsOENBQXNCLEdBQXRCLFVBQXVCLE9BQU87UUFDMUIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2xCLElBQUksU0FBUyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztRQUN4RCxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7UUFDM0QsSUFBSSxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7UUFDM0QsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUM7UUFDN0QsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFDbEUsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUVELDRDQUFvQixHQUFwQixVQUFxQixLQUFLLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUUzQyxnQ0FBUSxHQUFmLFVBQWdCLElBQUk7UUFBcEIsaUJBTUM7UUFMRyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxTQUFTLEdBQWMsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUN2QyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUN2RCxVQUFBLEVBQUUsSUFBSSxPQUFBLEtBQUksQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLEVBQXhCLENBQXdCLEVBQzlCLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsRUFBekIsQ0FBeUIsQ0FBQyxDQUFBO0lBQzNDLENBQUM7SUFFRCx1Q0FBZSxHQUFmLGNBQW9CLENBQUM7SUFFckIseUNBQWlCLEdBQWpCLGNBQXNCLENBQUM7SUFFdkIsdUNBQWUsR0FBZixVQUFnQixPQUFPO1FBQ25CLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLFNBQVMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkQsSUFBSSxDQUFDLFlBQVksR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7UUFDckQsSUFBSSxDQUFDLEtBQUssR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7UUFDekQsSUFBSSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUM7UUFDM0QsbUJBQW1CLENBQUMsU0FBUyxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUN2RSxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUMvRCxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztJQUM3QixDQUFDO0lBRUQscUNBQWEsR0FBYixVQUFjLEtBQUssSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBRXBDLHFDQUFhLEdBQXBCLFVBQXFCLElBQUk7UUFDckIsSUFBSSxTQUFTLEdBQWMsSUFBSSxDQUFDLE1BQU0sQ0FBQztJQUMzQyxDQUFDO0lBRU0sK0JBQU8sR0FBZCxVQUFlLElBQUk7UUFDZixJQUFJLFNBQVMsR0FBYyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ3ZDLFNBQVMsQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ3BCLFNBQVMsQ0FBQyxJQUFJLEdBQUcsZ0JBQWdCLENBQUM7SUFDdEMsQ0FBQztJQUVNLGdDQUFRLEdBQWYsVUFBZ0IsSUFBbUM7UUFDL0MsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQ0FBeUMsSUFBSSxDQUFDLFFBQVEsWUFBTyxJQUFJLENBQUMsUUFBVSxDQUFDLENBQUM7SUFDOUYsQ0FBQztJQUVNLDhCQUFNLEdBQWI7UUFDSSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVNLCtCQUFPLEdBQWQ7UUFDSSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVELHlDQUFpQixHQUFqQjtRQUNJLElBQU0sVUFBVSxHQUFrQixHQUFHLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEQsVUFBVSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCxvQ0FBWSxHQUFaLFVBQWEsS0FBSztRQUNkLGlDQUFpQztRQUNqQyxJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksRUFBRSxFQUFFO1lBQzNELElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUN0QjthQUNJO1lBQ0QsS0FBSyxDQUFDO2dCQUNGLEtBQUssRUFBRSxVQUFVO2dCQUNqQixPQUFPLEVBQUUsdUNBQXVDO2dCQUNoRCxZQUFZLEVBQUUsSUFBSTthQUNyQixDQUFDLENBQUE7U0FDTDtJQUNMLENBQUM7SUFFRCxzQ0FBYyxHQUFkLFVBQWUsSUFBSTtRQUNmLElBQUksVUFBVSxHQUFlLElBQUksQ0FBQyxNQUFNLENBQUM7UUFFekMsSUFBSSxLQUFLLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUN2QixJQUFJLElBQUksR0FBRyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7UUFFNUIsVUFBVSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7UUFDdkIsVUFBVSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsVUFBVSxFQUFFLEdBQUcsRUFBRSxDQUFDO1FBRTVDLElBQUksU0FBUyxHQUFHLENBQUMsVUFBVSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUE7UUFDckQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLFVBQVUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUM7UUFDeEUsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztJQUNyRSxDQUFDO0lBRUQscUNBQWEsR0FBYixVQUFjLElBQUk7UUFFZCxJQUFJLFNBQVMsQ0FBQztRQUNkLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDakMsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUV0QyxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEVBQUU7WUFDeEIsSUFBSSxVQUFVLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUN2QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxHQUFHLEtBQUssR0FBRyxPQUFPLEdBQUcsS0FBSyxDQUFDO1NBQ3RHO2FBQ0k7WUFDRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRSxHQUFHLEtBQUssR0FBRyxPQUFPLENBQUMsUUFBUSxFQUFFLEdBQUcsS0FBSyxDQUFDO1NBQzVGO1FBQ0QsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUNqRSx5QkFBeUI7SUFDN0IsQ0FBQztJQUVELHlDQUFpQixHQUFqQjtRQUFBLGlCQWdCQztRQWZHLElBQUksWUFBWSxHQUFHLElBQUksV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQzlDLFlBQVksQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNqRCxZQUFZLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFbkQsSUFBSSxVQUFVLEdBQUcsSUFBSSxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDNUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzdDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUUvQyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztRQUN2QixJQUFJLEdBQUcsR0FBRyxZQUFZLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFFBQVEsR0FBRyxhQUFhLEdBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQTtRQUM1RyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2pCLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FDM0MsVUFBQSxRQUFRLElBQUksT0FBQSxLQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxFQUE5QixDQUE4QixFQUMxQyxVQUFBLEtBQUssSUFBSSxPQUFBLEtBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLEVBQXpCLENBQXlCLENBQ3JDLENBQUE7SUFDTCxDQUFDO0lBRUQsdUNBQWUsR0FBZixVQUFnQixRQUFRO1FBQ3BCLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1FBQ3hCLElBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUE7UUFDdEQsSUFBSSxVQUFVLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztRQUMvRCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNyQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN0RixDQUFDO0lBRUQscUNBQWEsR0FBYixVQUFjLEtBQUs7UUFDZixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUN4QixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3ZCLENBQUM7SUFFRCwwQ0FBa0IsR0FBbEIsVUFBbUIsT0FBTztRQUN0QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsMkJBQTJCO1FBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUM7WUFDVixLQUFLLEVBQUUsVUFBVTtZQUNqQixPQUFPLEVBQUUsdUJBQXVCO1lBQ2hDLFlBQVksRUFBRSxJQUFJO1NBQ3JCLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCx3Q0FBZ0IsR0FBaEIsVUFBaUIsS0FBSztRQUNsQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVELHVDQUFlLEdBQWYsVUFBZ0IsS0FBSztRQUFyQixpQkFxQkM7UUFwQkcsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2xCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM1RCxJQUFJLENBQUMsS0FBSyxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDaEUsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQztRQUM1QyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFDNUIsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2pELElBQUksT0FBTyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDdEUsR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7WUFDcEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDakQsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLEdBQUcsS0FBSyxHQUFHLE9BQU8sQ0FBQztRQUN6RSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDN0QsSUFBSSxRQUFRLEdBQUcsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBRXpDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLHFCQUFVLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxDQUFDLFNBQVMsQ0FDdEUsVUFBQSxPQUFPLElBQUksT0FBQSxLQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLEVBQWhDLENBQWdDLEVBQzNDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxFQUE1QixDQUE0QixDQUN4QyxDQUFBO0lBQ0wsQ0FBQztJQUVELDBDQUFrQixHQUFsQixVQUFtQixPQUFPO1FBQ3RCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixtQkFBbUIsQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBQzVFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRSxFQUFFLFlBQVksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFFRCx3Q0FBZ0IsR0FBaEIsVUFBaUIsS0FBSztRQUNsQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVELG1DQUFXLEdBQVg7UUFBQSxpQkEyQkM7UUF6QkcsSUFBSSxXQUFXLEdBQUc7WUFDZCxNQUFNLEVBQUUsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztZQUMvQyxZQUFZLEVBQUcsSUFBSSxDQUFDLGVBQWU7WUFDbkMsWUFBWSxFQUFDLElBQUksQ0FBQyxZQUFZO1lBQzlCLFFBQVEsRUFBRyxVQUFVLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztZQUNuQyxTQUFTLEVBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7WUFDckMsUUFBUSxFQUFHLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUM7WUFDakQsZUFBZSxFQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztZQUNoRCxTQUFTLEVBQUcsRUFBRTtZQUNkLFNBQVMsRUFBQyxLQUFLO1NBQ2xCLENBQUE7UUFFRCxJQUFJLE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN2RSxHQUFHLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBRWxELFdBQVcsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssR0FBRyxPQUFPLENBQUM7UUFFaEUsSUFBSSxRQUFRLEdBQUcsRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLENBQUM7UUFFMUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7UUFDdkIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxTQUFTLEVBQUUsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUN0RSxVQUFBLE9BQU8sSUFBSSxPQUFBLEtBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsRUFBaEMsQ0FBZ0MsRUFDM0MsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEVBQTVCLENBQTRCLENBQ3hDLENBQUE7SUFDTCxDQUFDO0lBellRLGFBQWE7UUFMekIsZ0JBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxNQUFNO1lBQ2hCLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixXQUFXLEVBQUUsdUJBQXVCO1NBQ3ZDLENBQUM7eUNBcUJ3QyxpQ0FBZSxFQUE2Qix5QkFBZ0I7WUFDOUUsZUFBTSxFQUFnQixhQUFNO09BckJ2QyxhQUFhLENBMFl6QjtJQUFELG9CQUFDO0NBQUEsQUExWUQsSUEwWUM7QUExWVksc0NBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgTmdab25lIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IFJhZFNpZGVEcmF3ZXIgfSBmcm9tIFwibmF0aXZlc2NyaXB0LXVpLXNpZGVkcmF3ZXJcIjtcbmltcG9ydCAqIGFzIGFwcCBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9hcHBsaWNhdGlvblwiO1xuaW1wb3J0ICogYXMgR2VvbG9jYXRpb24gZnJvbSBcIm5hdGl2ZXNjcmlwdC1nZW9sb2NhdGlvblwiO1xuaW1wb3J0IHsgQWNjdXJhY3kgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy91aS9lbnVtc1wiOyAvLyB1c2VkIHRvIGRlc2NyaWJlIGF0IHdoYXQgYWNjdXJhY3kgdGhlIGxvY2F0aW9uIHNob3VsZCBiZSBnZXRcbmltcG9ydCB7IFNlYXJjaEJhciB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL3NlYXJjaC1iYXJcIjtcbmltcG9ydCB7IFNlbGVjdGVkSW5kZXhDaGFuZ2VkRXZlbnREYXRhIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1kcm9wLWRvd25cIjtcbmltcG9ydCB7IERhdGVQaWNrZXIgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy91aS9kYXRlLXBpY2tlclwiO1xuaW1wb3J0IHsgVGltZVBpY2tlciB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL3RpbWUtcGlja2VyXCI7XG5pbXBvcnQgeyBFdmVudERhdGEsIE9ic2VydmFibGUgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9kYXRhL29ic2VydmFibGVcIjtcbmltcG9ydCB7IEJpa2VQb29sU2VydmljZSB9IGZyb20gXCIuLi9zaGFyZWQvYmlrZXBvb2xzZXJ2aWNlXCI7XG5pbXBvcnQgeyBTZXJ2aWNlVVJMIH0gZnJvbSBcIi4uL3NoYXJlZC9zZXJ2aWNlc1wiXG5pbXBvcnQgKiBhcyBkaWFsb2dzIGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL2RpYWxvZ3NcIjtcbmltcG9ydCB7IFJvdXRlckV4dGVuc2lvbnMgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvcm91dGVyXCI7XG5jb25zdCBmaXJlYmFzZSA9IHJlcXVpcmUoXCJuYXRpdmVzY3JpcHQtcGx1Z2luLWZpcmViYXNlXCIpO1xuaW1wb3J0ICogYXMgQXBwbGljYXRpb25TZXR0aW5ncyBmcm9tIFwiYXBwbGljYXRpb24tc2V0dGluZ3NcIjtcbmltcG9ydCB7IFJvdXRlciwgTmF2aWdhdGlvbkV4dHJhcyB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IFRhYlZpZXcsIFRhYlZpZXdJdGVtIH0gZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvdWkvdGFiLXZpZXdcIjtcbmltcG9ydCB7IG9mZmVyIH0gZnJvbSBcIi4uL3NoYXJlZC9tb2RlbHMvb2ZmZXJyaWRlXCI7XG5pbXBvcnQgeyBEYXRlVGltZVBpY2tlciB9IGZyb20gXCJuYXRpdmVzY3JpcHQtZGF0ZXRpbWVwaWNrZXJcIjtcbmltcG9ydCB7IExvYWRpbmdTY3JlZW4gfSBmcm9tICduYXRpdmVzY3JpcHQtbG9hZGluZy1zY3JlZW4nO1xuaW1wb3J0IHsgc3RyaW5naWZ5IH0gZnJvbSBcIkBhbmd1bGFyL2NvcmUvc3JjL3JlbmRlcjMvdXRpbFwiO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogXCJIb21lXCIsXG4gICAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcbiAgICB0ZW1wbGF0ZVVybDogXCIuL2hvbWUuY29tcG9uZW50Lmh0bWxcIlxufSlcbmV4cG9ydCBjbGFzcyBIb21lQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcblxuICAgIGN1cnJlbnRMb2NhdGlvbjogc3RyaW5nID0gXCJcIjtcbiAgICBpdGVtczogYW55O1xuICAgIHNlYXJjaFBocmFzZTogc3RyaW5nO1xuICAgIEZyb21MYXQ6IHN0cmluZztcbiAgICBGcm9tTG9uZzogc3RyaW5nO1xuICAgIFRvTGF0OiBzdHJpbmc7XG4gICAgVG9Mb25nOiBzdHJpbmc7XG4gICAgdG90YWxSaWRlRGlzdGFuY2U6IGFueTtcbiAgICBzaG93TG9hZGVyOiBib29sZWFuO1xuICAgIG9mZmVyOiBhbnk7XG4gICAgU3RhcnRUaW1lOiBhbnk7XG4gICAgVmVoaWNsZVR5cGU6IGFueTtcbiAgICB1c2VybGF0aXR1ZGU6IGFueTtcbiAgICB1c2VybG9uZ3RpdHVkZTogYW55O1xuICAgIHNlbGVjdGVkSW5kZXggOiBhbnk7XG4gICAgc2VsZWN0ZWRSaWRlVGltZTogYW55O1xuICAgIHByaXZhdGUgbG9hZGluZ1NjcmVlbjogTG9hZGluZ1NjcmVlbjsgICAgXG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIGJpa2Vwb29sc2VydmljZTogKEJpa2VQb29sU2VydmljZSksIHByaXZhdGUgcm91dGVyRXh0ZW5zaW9uczogUm91dGVyRXh0ZW5zaW9ucyxcbiAgICAgICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlciwgcHJpdmF0ZSB6b25lOiBOZ1pvbmUpIHtcbiAgICAgICAgLy8gVXNlIHRoZSBjb21wb25lbnQgY29uc3RydWN0b3IgdG8gaW5qZWN0IHByb3ZpZGVycy5cbiAgICAgICAgdGhpcy5sb2FkaW5nU2NyZWVuID0gbmV3IExvYWRpbmdTY3JlZW4oKTtcbiAgICB9XG5cbiAgICBoaWRlTG9hZGVyKCkge1xuICAgICAgICAvL3RoaXMubG9hZGVyLmhpZGUoKTtcbiAgICAgICAgdGhpcy5sb2FkaW5nU2NyZWVuLmNsb3NlKCk7XG4gICAgfVxuXG4gICAgTG9hZGVyU2hvdygpIHtcbiAgICAgICAgLy90aGlzLmxvYWRlci5zaG93KHRoaXMub3B0aW9ucyk7XG4gICAgICAgIHRoaXMubG9hZGluZ1NjcmVlbi5zaG93KHtcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwiTG9hZGluZy4uLlwiXG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xuXG4gICAgICAgIC8vIEluaXQgeW91ciBjb21wb25lbnQgcHJvcGVydGllcyBoZXJlLlxuICAgICAgICB0aGlzLml0ZW1zID0gW107XG4gICAgICAgIHRoaXMuaXRlbXMucHVzaChcIkNhclwiKTtcbiAgICAgICAgdGhpcy5pdGVtcy5wdXNoKFwiQmlrZVwiKTtcblxuICAgICAgICB0aGlzLm9mZmVyID0gbmV3IG9mZmVyKCk7XG5cbiAgICAgICAgLy8gY2FsbCBzZXREYXRlUGlja2VyVGltZSBtZXRob2RcbiAgICAgICAgdGhpcy5zZXREYXRlUGlja2VyVGltZSgpO1xuICAgICAgICB0aGlzLkxvYWRlclNob3coKTtcbiAgICAgICAgbGV0IGxvY2F0aW9uID0gdGhpcy5nZXREZXZpY2VMb2NhdGlvbigpO1xuICAgICAgICB0aGlzLkluaXRGaXJlQmFzZVBsdWdJbigpO1xuICAgICAgICB0aGlzLnVwZGF0ZVN0YXR1c0F2YWlsKCk7XG4gICAgfVxuXG4gICAgc2V0RGF0ZVBpY2tlclRpbWUoKSB7XG4gICAgICAgIGxldCBkYXRlID0gbmV3IERhdGUoKTtcbiAgICAgICAgY29uc3QgZGF0ZVBpY2tlciA9IG5ldyBEYXRlUGlja2VyKCk7XG4gICAgICAgIGRhdGVQaWNrZXIuZGF5ID0gZGF0ZS5nZXREYXRlKCk7XG4gICAgICAgIGRhdGVQaWNrZXIubW9udGggPSBkYXRlLmdldE1vbnRoKCkgKyAxO1xuICAgICAgICBkYXRlUGlja2VyLnllYXIgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XG4gICAgICAgIGRhdGVQaWNrZXIuZGF0ZSA9IG5ldyBEYXRlKCk7IC8vIHVzaW5nIERhdGUgb2JqZWN0XG5cbiAgICAgICAgZGF0ZVBpY2tlci5taW5EYXRlID0gbmV3IERhdGUoZGF0ZS5nZXRGdWxsWWVhcigpLCBkYXRlLmdldE1vbnRoKCkgKyAxLCBkYXRlLmdldERhdGUoKSk7XG4gICAgICAgIGRhdGVQaWNrZXIubWF4RGF0ZSA9IG5ldyBEYXRlKDIwNDAsIDQsIDIwKTtcbiAgICB9XG5cbiAgICB1cGRhdGVTdGF0dXNBdmFpbCgpIHtcblxuICAgICAgICBmaXJlYmFzZS5hZGRWYWx1ZUV2ZW50TGlzdGVuZXIoZGF0YSA9PiB7XG4gICAgICAgICAgICBsZXQgU3RhdHVzO1xuICAgICAgICAgICAgaWYgKGRhdGEudmFsdWUpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnU3RhdHVzOiBPbmxpbmUnKTtcbiAgICAgICAgICAgICAgICBTdGF0dXMgPSBcIk9ubGluZVwiO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnU3RhdHVzOiBPZmZsaW5lJyk7XG4gICAgICAgICAgICAgICAgU3RhdHVzID0gXCJPZmZsaW5lXCI7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGxldCBvYmpVcGRhdGVVc2VyTG9jYXRpb24gPVxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgdXNlcmlkOiBBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcInVzZXJpZFwiKSxcbiAgICAgICAgICAgICAgICAgICAgbG9uZ2l0dWRlOiB0aGlzLkZyb21MYXQsXG4gICAgICAgICAgICAgICAgICAgIGxhdGl0dWRlOiB0aGlzLkZyb21Mb25nLFxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IFN0YXR1cyxcbiAgICAgICAgICAgICAgICAgICAgZGV2aWNlVG9rZW4gOiBBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcImRldmljZV90b2tlblwiKVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdGhpcy5iaWtlcG9vbHNlcnZpY2UuUG9zdFNlcnZpY2UoU2VydmljZVVSTC5SaWRlVXBkYXRlVXNlckxvY2F0aW9uLCBvYmpVcGRhdGVVc2VyTG9jYXRpb24pLnN1YnNjcmliZShcbiAgICAgICAgICAgICAgICBzdWNjZXNzID0+IGNvbnNvbGUubG9nKHN1Y2Nlc3MpLFxuICAgICAgICAgICAgICAgIGVycm9yID0+IGNvbnNvbGUubG9nKFwidXBkYXRlZGV2aWNlbG9jYXRpb25cIiArIGVycm9yKVxuICAgICAgICAgICAgKVxuICAgICAgICB9LCAnLmluZm8vY29ubmVjdGVkJyk7XG4gICAgfVxuXG4gICAgSW5pdEZpcmVCYXNlUGx1Z0luKCkge1xuICAgICAgICBmaXJlYmFzZS5pbml0KHtcbiAgICAgICAgICAgIC8vcGVyc2lzdCBzaG91bGQgYmUgc2V0IHRvIGZhbHNlIGFzIG90aGVyd2lzZSBudW1iZXJzIGFyZW4ndCByZXR1cm5lZCBkdXJpbmcgbGl2ZXN5bmNcbiAgICAgICAgICAgIHBlcnNpc3Q6IGZhbHNlLFxuICAgICAgICAgICAgdXJsOiBcImh0dHBzOi8vbWV0cm9hcHBsaWNhdGlvbnByb2plY3QuZmlyZWJhc2Vpby5jb21cIixcbiAgICAgICAgICAgIG9uUHVzaFRva2VuUmVjZWl2ZWRDYWxsYmFjazogZnVuY3Rpb24gKHRva2VuKSB7XG4gICAgICAgICAgICAgICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoJ2RldmljZV90b2tlbicsIHRva2VuKTsgICAgXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJkZXZpY2VUb2tlblwiKyBBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZygnZGV2aWNlX3Rva2VuJykpICAgICAgICAgICBcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvbk1lc3NhZ2VSZWNlaXZlZENhbGxiYWNrOiAobWVzc2FnZTogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgbGV0IG9iak5vdGlmaWNhdGlvbk1lc3NhZ2UgPSBtZXNzYWdlLmRhdGEudmFsdWU7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2cobWVzc2FnZS5kYXRhLnZhbHVlKTtcbiAgICAgICAgICAgICAgICBsZXQgbmF2aWdhdGlvbkV4dHJhczogTmF2aWdhdGlvbkV4dHJhcyA9IHtcbiAgICAgICAgICAgICAgICAgICAgcXVlcnlQYXJhbXM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9iak5vdGlmaWNhdGlvbk1lc3NhZ2VcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShbXCJyaWRlaW5mb1wiXSwgbmF2aWdhdGlvbkV4dHJhcyk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgbm90aWZpY2F0aW9uQ2FsbGJhY2tBbmRyb2lkOiAobWVzc2FnZTogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkobWVzc2FnZSkpO1xuXG4gICAgICAgICAgICAgICAgLy9pZiAobWVzc2FnZS5mb3JlZ3JvdW5kID09IGZhbHNlKSB7XG4gICAgICAgICAgICAgICAgZGlhbG9ncy5hbGVydCh7XG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIk9uIGQgVmF5XCIsXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUmlkZXJzIFJlcXVlc3RlZCBOb3RpZmljYXRpb25cIixcbiAgICAgICAgICAgICAgICAgICAgb2tCdXR0b25UZXh0OiBcIm9rXCJcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAvLyB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhcIk1lc3NhZ2UgcmVjZWl2ZWQgd2hlbiBpbnNpZGUgdGhlIGFwcFwiKTtcbiAgICAgICAgICAgICAgICAvLyB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgb25BdXRoU3RhdGVDaGFuZ2VkOiAoZGF0YTogYW55KSA9PiB7ICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZGF0YUVycm9yXCIgKyBKU09OLnN0cmluZ2lmeShkYXRhKSlcbiAgICAgICAgICAgICAgICBpZiAoZGF0YS5sb2dnZWRJbikge1xuICAgICAgICAgICAgICAgICAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcInVzZXJpZFwiLCBkYXRhLnVzZXIudWlkKTtcbiAgICAgICAgICAgICAgICAgICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJlbWFpbFwiLGRhdGEudXNlci5lbWFpbCk7XG4gICAgICAgICAgICAgICAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwidXNlcm5hbWVcIixkYXRhLnVzZXIubmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwicHJvZmlsZUltYWdlVVJMXCIsZGF0YS51c2VyLnByb2ZpbGVJbWFnZVVSTCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgeyAgICAgICAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiT25BdXRoU3RhdGVcIiArIGRhdGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSkudGhlbihcbiAgICAgICAgICAgIGZ1bmN0aW9uIChpbnN0YW5jZSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZmlyZWJhc2UuaW5pdCBkb25lXCIpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGluc3RhbmNlKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBmdW5jdGlvbiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImZpcmViYXNlLmluaXQgZXJyb3I6IFwiICsgZXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgKTtcbiAgICB9XG5cbiAgICBwcml2YXRlIGdldERldmljZUxvY2F0aW9uKCk6IFByb21pc2U8YW55PiB7XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICBHZW9sb2NhdGlvbi5lbmFibGVMb2NhdGlvblJlcXVlc3QoKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICBHZW9sb2NhdGlvbi5nZXRDdXJyZW50TG9jYXRpb24oeyB0aW1lb3V0OiAxMDAwMCB9KS50aGVuKGxvY2F0aW9uID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShsb2NhdGlvbik7XG4gICAgICAgICAgICAgICAgICAgIC8vIENhbGwgdXBkYXRlRGV2aWNlTG9jYXRpb24gbWV0aG9kXG4gICAgICAgICAgICAgICAgICAgIHRoaXMudXNlcmxhdGl0dWRlID0gbG9jYXRpb24ubGF0aXR1ZGU7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMudXNlcmxvbmd0aXR1ZGUgPSBsb2NhdGlvbi5sb25naXR1ZGU7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMudXBkYXRlRGV2aWNlTG9jYXRpb24oMTMuMDYxMTQwLDgwLjI4MjQ3OCk7XG4gICAgICAgICAgICAgICAgICAgLy8gdGhpcy51cGRhdGVEZXZpY2VMb2NhdGlvbihsb2NhdGlvbi5sYXRpdHVkZSwgbG9jYXRpb24ubG9uZ2l0dWRlKTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5oaWRlTG9hZGVyKCk7XG4gICAgICAgICAgICAgICAgfSkuY2F0Y2goZXJyb3IgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZWplY3QoZXJyb3IpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHVwZGF0ZURldmljZUxvY2F0aW9uKGxhdCwgbG9uZykge1xuICAgICAgICB0aGlzLkxvYWRlclNob3coKTtcbiAgICAgICAgdGhpcy5Gcm9tTGF0ID0gbGF0OyB0aGlzLkZyb21Mb25nID0gbG9uZztcbiAgICAgICAgbGV0IGZvcm1VUkwgPSBcIj9wcm94PVwiICsgbGF0ICsgXCIsXCIgKyBsb25nO1xuICAgICAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5HZXRBZGRyZXNzKGZvcm1VUkwpLnN1YnNjcmliZShcbiAgICAgICAgICAgIGFkZHJlc3MgPT4gdGhpcy5oYW5kbGVTdWNjZXNzRGV2aWNlTG9jKGFkZHJlc3MpLFxuICAgICAgICAgICAgZXJyb3IgPT4gdGhpcy5oYW5kbGVFcnJvckRldmljZUxvYyhlcnJvcikpXG4gICAgfVxuXG4gICAgaGFuZGxlU3VjY2Vzc0RldmljZUxvYyhzdWNjZXNzKSB7XG4gICAgICAgIHRoaXMuaGlkZUxvYWRlcigpO1xuICAgICAgICBsZXQgb2JqUmVzdWx0ID0gc3VjY2Vzcy5SZXNwb25zZS5WaWV3WzBdLlJlc3VsdFswXTtcbiAgICAgICAgdGhpcy5jdXJyZW50TG9jYXRpb24gPSBvYmpSZXN1bHQuTG9jYXRpb24uQWRkcmVzcy5MYWJlbDtcbiAgICAgICAgdGhpcy5vZmZlci5QaWNrTG9jYXRpb24gPSBvYmpSZXN1bHQuTG9jYXRpb24uQWRkcmVzcy5MYWJlbDtcbiAgICAgICAgdGhpcy5Gcm9tTGF0ID0gb2JqUmVzdWx0LkxvY2F0aW9uLkRpc3BsYXlQb3NpdGlvbi5MYXRpdHVkZTtcbiAgICAgICAgdGhpcy5Gcm9tTG9uZyA9IG9ialJlc3VsdC5Mb2NhdGlvbi5EaXNwbGF5UG9zaXRpb24uTG9uZ2l0dWRlO1xuICAgICAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcImZyb21sYXRcIiwgdGhpcy5Gcm9tTGF0LnRvU3RyaW5nKCkpO1xuICAgICAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcImZyb21sb25nXCIsIHRoaXMuRnJvbUxvbmcudG9TdHJpbmcoKSk7XG4gICAgfVxuXG4gICAgaGFuZGxlRXJyb3JEZXZpY2VMb2MoZXJyb3IpIHsgdGhpcy5oaWRlTG9hZGVyKCk7IH1cblxuICAgIHB1YmxpYyBvblN1Ym1pdChhcmdzKSB7XG4gICAgICAgIHRoaXMuTG9hZGVyU2hvdygpO1xuICAgICAgICBsZXQgc2VhcmNoQmFyID0gPFNlYXJjaEJhcj5hcmdzLm9iamVjdDtcbiAgICAgICAgdGhpcy5iaWtlcG9vbHNlcnZpY2UuR2V0QWRkcmVzc0FDKHNlYXJjaEJhci50ZXh0KS5zdWJzY3JpYmUoXG4gICAgICAgICAgICBhYyA9PiB0aGlzLmhhbmRsZUFDU3VjY2VzcyhhYyksXG4gICAgICAgICAgICBlcnJvciA9PiB0aGlzLmhhbmRsZUFDRXJyb3IoZXJyb3IpKVxuICAgIH1cblxuICAgIHNldFJpZGVTZXR0aW5ncygpIHsgfVxuXG4gICAgQ2xlYXJSaWRlU2V0dGluZ3MoKSB7IH1cblxuICAgIGhhbmRsZUFDU3VjY2VzcyhzdWNjZXNzKSB7XG4gICAgICAgIHRoaXMuaGlkZUxvYWRlcigpO1xuICAgICAgICBsZXQgb2JqUmVzdWx0ID0gc3VjY2Vzcy5SZXNwb25zZS5WaWV3WzBdLlJlc3VsdFswXTtcbiAgICAgICAgdGhpcy5zZWFyY2hQaHJhc2UgPSBvYmpSZXN1bHQuTG9jYXRpb24uQWRkcmVzcy5MYWJlbDtcbiAgICAgICAgdGhpcy5Ub0xhdCA9IG9ialJlc3VsdC5Mb2NhdGlvbi5EaXNwbGF5UG9zaXRpb24uTGF0aXR1ZGU7XG4gICAgICAgIHRoaXMuVG9Mb25nID0gb2JqUmVzdWx0LkxvY2F0aW9uLkRpc3BsYXlQb3NpdGlvbi5Mb25naXR1ZGU7XG4gICAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwiY3VycmVudGxvY2F0aW9uXCIsIHRoaXMuY3VycmVudExvY2F0aW9uKTtcbiAgICAgICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJ0b2xvY2F0aW9uXCIsIHRoaXMuc2VhcmNoUGhyYXNlKTtcbiAgICAgICAgdGhpcy5DYWxjdWxhdGVEaXN0YW5jZSgpO1xuICAgIH1cblxuICAgIGhhbmRsZUFDRXJyb3IoZXJyb3IpIHsgdGhpcy5oaWRlTG9hZGVyKCk7IH1cblxuICAgIHB1YmxpYyBvblRleHRDaGFuZ2VkKGFyZ3MpIHtcbiAgICAgICAgbGV0IHNlYXJjaEJhciA9IDxTZWFyY2hCYXI+YXJncy5vYmplY3Q7XG4gICAgfVxuXG4gICAgcHVibGljIG9uQ2xlYXIoYXJncykge1xuICAgICAgICBsZXQgc2VhcmNoQmFyID0gPFNlYXJjaEJhcj5hcmdzLm9iamVjdDtcbiAgICAgICAgc2VhcmNoQmFyLnRleHQgPSBcIlwiO1xuICAgICAgICBzZWFyY2hCYXIuaGludCA9IFwiRW50ZXIgTG9jYXRpb25cIjtcbiAgICB9XG5cbiAgICBwdWJsaWMgb25jaGFuZ2UoYXJnczogU2VsZWN0ZWRJbmRleENoYW5nZWRFdmVudERhdGEpIHtcbiAgICAgICAgY29uc29sZS5sb2coYERyb3AgRG93biBzZWxlY3RlZCBpbmRleCBjaGFuZ2VkIGZyb20gJHthcmdzLm9sZEluZGV4fSB0byAke2FyZ3MubmV3SW5kZXh9YCk7XG4gICAgfVxuXG4gICAgcHVibGljIG9ub3BlbigpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJEcm9wIERvd24gb3BlbmVkLlwiKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgb25jbG9zZSgpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJEcm9wIERvd24gY2xvc2VkLlwiKTtcbiAgICB9XG5cbiAgICBvbkRyYXdlckJ1dHRvblRhcCgpOiB2b2lkIHtcbiAgICAgICAgY29uc3Qgc2lkZURyYXdlciA9IDxSYWRTaWRlRHJhd2VyPmFwcC5nZXRSb290VmlldygpO1xuICAgICAgICBzaWRlRHJhd2VyLnNob3dEcmF3ZXIoKTtcbiAgICB9XG5cbiAgICBvbkZpbmRSaWRlcnMoZXZlbnQpIHtcbiAgICAgICAgLy90aGlzLnNldFJpZGVTZXR0aW5ncygpOyAgICAgICAgXG4gICAgICAgIGlmICh0aGlzLnNlYXJjaFBocmFzZSAhPSB1bmRlZmluZWQgJiYgdGhpcy5zZWFyY2hQaHJhc2UgIT0gJycpIHtcbiAgICAgICAgICAgIHRoaXMuUmVxdWVzdFJpZGUoKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGFsZXJ0KHtcbiAgICAgICAgICAgICAgICB0aXRsZTogXCJPbiBkIFZheVwiLFxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIFNlYXJjaCBMb2NhdGlvbiB0byBGaW5kIFJpZGVyc1wiLFxuICAgICAgICAgICAgICAgIG9rQnV0dG9uVGV4dDogXCJPa1wiXG4gICAgICAgICAgICB9KVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgb25QaWNrZXJMb2FkZWQoYXJncykge1xuICAgICAgICBsZXQgdGltZVBpY2tlciA9IDxUaW1lUGlja2VyPmFyZ3Mub2JqZWN0O1xuXG4gICAgICAgIHZhciB0b2RheSA9IG5ldyBEYXRlKCk7XG4gICAgICAgIHZhciB0aW1lID0gdG9kYXkuZ2V0SG91cnMoKTtcblxuICAgICAgICB0aW1lUGlja2VyLmhvdXIgPSB0aW1lO1xuICAgICAgICB0aW1lUGlja2VyLm1pbnV0ZSA9IHRvZGF5LmdldE1pbnV0ZXMoKSArIDEwO1xuXG4gICAgICAgIGxldCBwZXJpb2RpYW4gPSAodGltZVBpY2tlci5ob3VyID49IDEyKSA/IFwiYW1cIiA6IFwicG1cIlxuICAgICAgICB0aGlzLnNlbGVjdGVkUmlkZVRpbWUgPSB0aW1lUGlja2VyLmhvdXIgKyB0aW1lUGlja2VyLm1pbnV0ZSArIHBlcmlvZGlhbjtcbiAgICAgICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJyaWRldGltZVwiLCB0aGlzLnNlbGVjdGVkUmlkZVRpbWUpO1xuICAgIH1cblxuICAgIG9uVGltZUNoYW5nZWQoYXJncykge1xuXG4gICAgICAgIGxldCB0b3RhbFRpbWU7XG4gICAgICAgIGxldCBob3VyID0gYXJncy52YWx1ZS5nZXRIb3VycygpO1xuICAgICAgICBsZXQgbWludXRlcyA9IGFyZ3MudmFsdWUuZ2V0TWludXRlcygpO1xuXG4gICAgICAgIGlmIChwYXJzZUZsb2F0KGhvdXIpID49IDEyKSB7XG4gICAgICAgICAgICBsZXQgRm9ybWF0SG91ciA9IHBhcnNlRmxvYXQoaG91cikgLSAxMjtcbiAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRSaWRlVGltZSA9IChGb3JtYXRIb3VyID09IDApID8gXCIxMlwiIDogRm9ybWF0SG91ci50b1N0cmluZygpICsgXCIgOiBcIiArIG1pbnV0ZXMgKyBcIiBwbVwiO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZFJpZGVUaW1lID0gcGFyc2VGbG9hdChob3VyKS50b1N0cmluZygpICsgXCIgOiBcIiArIG1pbnV0ZXMudG9TdHJpbmcoKSArIFwiIGFtXCI7XG4gICAgICAgIH1cbiAgICAgICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJyaWRldGltZVwiLCB0aGlzLnNlbGVjdGVkUmlkZVRpbWUpO1xuICAgICAgICAvL3RoaXMuc2V0UmlkZVNldHRpbmdzKCk7XG4gICAgfVxuXG4gICAgQ2FsY3VsYXRlRGlzdGFuY2UoKSB7XG4gICAgICAgIGxldCBsb2NhdGlvbkZyb20gPSBuZXcgR2VvbG9jYXRpb24uTG9jYXRpb24oKTtcbiAgICAgICAgbG9jYXRpb25Gcm9tLmxhdGl0dWRlID0gcGFyc2VGbG9hdCh0aGlzLkZyb21MYXQpO1xuICAgICAgICBsb2NhdGlvbkZyb20ubG9uZ2l0dWRlID0gcGFyc2VGbG9hdCh0aGlzLkZyb21Mb25nKTtcblxuICAgICAgICBsZXQgbG9jYXRpb25UbyA9IG5ldyBHZW9sb2NhdGlvbi5Mb2NhdGlvbigpO1xuICAgICAgICBsb2NhdGlvblRvLmxhdGl0dWRlID0gcGFyc2VGbG9hdCh0aGlzLlRvTGF0KTtcbiAgICAgICAgbG9jYXRpb25Uby5sb25naXR1ZGUgPSBwYXJzZUZsb2F0KHRoaXMuVG9Mb25nKTtcblxuICAgICAgICB0aGlzLnNob3dMb2FkZXIgPSB0cnVlO1xuICAgICAgICB2YXIgdXJsID0gXCJ3YXlwb2ludDA9XCIgKyB0aGlzLkZyb21MYXQgKyBcIixcIiArIHRoaXMuRnJvbUxvbmcgKyBcIiZ3YXlwb2ludDE9XCIgKyB0aGlzLlRvTGF0ICsgXCIsXCIgKyB0aGlzLlRvTG9uZ1xuICAgICAgICBjb25zb2xlLmxvZyh1cmwpO1xuICAgICAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5HZXREaXN0YW5jZSh1cmwpLnN1YnNjcmliZShcbiAgICAgICAgICAgIGRpc3RhbmNlID0+IHRoaXMuZGlzdGFuY2VzdWNjZXNzKGRpc3RhbmNlKSxcbiAgICAgICAgICAgIGVycm9yID0+IHRoaXMuZGlzdGFuY2VlcnJvcihlcnJvcilcbiAgICAgICAgKVxuICAgIH1cblxuICAgIGRpc3RhbmNlc3VjY2VzcyhkaXN0YW5jZSkge1xuICAgICAgICB0aGlzLnNob3dMb2FkZXIgPSBmYWxzZTtcbiAgICAgICAgbGV0IGRpc3QgPSBkaXN0YW5jZS5yZXNwb25zZS5yb3V0ZVswXS5zdW1tYXJ5LmRpc3RhbmNlXG4gICAgICAgIGxldCB0cmF2ZWxUaW1lID0gZGlzdGFuY2UucmVzcG9uc2Uucm91dGVbMF0uc3VtbWFyeS50cmF2ZWxUaW1lO1xuICAgICAgICB0aGlzLnRvdGFsUmlkZURpc3RhbmNlID0gZGlzdCAvIDEwMDA7XG4gICAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwicmlkZWRpc3RhbmNlXCIsIHRoaXMudG90YWxSaWRlRGlzdGFuY2UudG9TdHJpbmcoMikpO1xuICAgIH1cblxuICAgIGRpc3RhbmNlZXJyb3IoZXJyb3IpIHtcbiAgICAgICAgdGhpcy5zaG93TG9hZGVyID0gZmFsc2U7XG4gICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcbiAgICB9XG5cbiAgICBzdWJtaXRPZmZlclN1Y2Nlc3Moc3VjY2Vzcykge1xuICAgICAgICB0aGlzLmhpZGVMb2FkZXIoKTtcbiAgICAgICAgLy90aGlzLm9mZmVyID0gbmV3IG9mZmVyKCk7XG4gICAgICAgIGRpYWxvZ3MuYWxlcnQoe1xuICAgICAgICAgICAgdGl0bGU6IFwiT24gZCBWYXlcIixcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwiUmlkZSBPZmZlciBSZWNlaXZlZCAhXCIsXG4gICAgICAgICAgICBva0J1dHRvblRleHQ6IFwib2tcIlxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBzdWJtaXRPZmZlckVycm9yKGVycm9yKSB7XG4gICAgICAgIHRoaXMuaGlkZUxvYWRlcigpO1xuICAgIH1cblxuICAgIHN1Ym1pdE9mZmVyUmlkZShldmVudCkge1xuICAgICAgICB0aGlzLkxvYWRlclNob3coKTtcbiAgICAgICAgY29uc29sZS5sb2codGhpcy5vZmZlcik7XG4gICAgICAgIHRoaXMub2ZmZXIudXNlcklkID0gQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJ1c2VyaWRcIik7XG4gICAgICAgIHRoaXMub2ZmZXIuVmVoaWNsZVR5cGVUZXh0ID0gdGhpcy5pdGVtc1t0aGlzLm9mZmVyLlZlY2hpbGVUeXBlXTsgICAgICBcbiAgICAgICAgdGhpcy5vZmZlci5Ecm9wTG9jYXRpb24gPSB0aGlzLnNlYXJjaFBocmFzZTtcbiAgICAgICAgdGhpcy5vZmZlci5vZmZlclJpZGUgPSB0cnVlOyAgXG4gICAgICAgIHRoaXMub2ZmZXIubGF0aXR1ZGUgPSBwYXJzZUZsb2F0KHRoaXMuRnJvbUxhdCk7XG4gICAgICAgIHRoaXMub2ZmZXIubG9uZ2l0dWRlID0gcGFyc2VGbG9hdCh0aGlzLkZyb21Mb25nKTtcbiAgICAgICAgbGV0IG1pbnV0ZXMgPSAodGhpcy5vZmZlci5TdGFydFRpbWUuZ2V0TWludXRlcygpLnRvU3RyaW5nKCkubGVuZ3RoID09IDEpID9cbiAgICAgICAgICAgIFwiMFwiICsgdGhpcy5vZmZlci5TdGFydFRpbWUuZ2V0TWludXRlcygpLnRvU3RyaW5nKCkgOlxuICAgICAgICAgICAgdGhpcy5vZmZlci5TdGFydFRpbWUuZ2V0TWludXRlcygpLnRvU3RyaW5nKCk7XG4gICAgICAgIHRoaXMub2ZmZXIuU3RhcnRUaW1lID0gdGhpcy5vZmZlci5TdGFydFRpbWUuZ2V0SG91cnMoKSArIFwiIDogXCIgKyBtaW51dGVzO1xuICAgICAgICB0aGlzLm9mZmVyLlVzZXJOYW1lID0gQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJlbWFpbFwiKTtcbiAgICAgICAgdmFyIG9iak9mZmVyID0geyBPZmZlclJpZGU6IHRoaXMub2ZmZXIgfTtcblxuICAgICAgICB0aGlzLnNob3dMb2FkZXIgPSB0cnVlO1xuICAgICAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLk9mZmVyUmlkZSwgb2JqT2ZmZXIpLnN1YnNjcmliZShcbiAgICAgICAgICAgIHN1Y2Nlc3MgPT4gdGhpcy5zdWJtaXRPZmZlclN1Y2Nlc3Moc3VjY2VzcyksXG4gICAgICAgICAgICBlcnJvciA9PiB0aGlzLnN1Ym1pdE9mZmVyRXJyb3IoZXJyb3IpXG4gICAgICAgIClcbiAgICB9XG5cbiAgICBSaWRlUmVxdWVzdFN1Y2Nlc3Moc3VjY2Vzcykge1xuICAgICAgICB0aGlzLmhpZGVMb2FkZXIoKTsgICBcbiAgICAgICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJyaWRldGltZVwiLCB0aGlzLnNlbGVjdGVkUmlkZVRpbWUudG9TdHJpbmcoKSk7XG4gICAgICAgIHRoaXMucm91dGVyRXh0ZW5zaW9ucy5uYXZpZ2F0ZShbXCIvcmlkZXJzbGlzdFwiXSwgeyBjbGVhckhpc3Rvcnk6IHRydWUgfSk7ICAgICBcbiAgICB9XG5cbiAgICBSaWRlUmVxdWVzdEVycm9yKGVycm9yKSB7XG4gICAgICAgIHRoaXMuaGlkZUxvYWRlcigpO1xuICAgIH1cblxuICAgIFJlcXVlc3RSaWRlKClcbiAgICB7XG4gICAgICAgIHZhciByaWRlUmVxdWVzdCA9IHtcbiAgICAgICAgICAgIHVzZXJJZDogQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJ1c2VyaWRcIiksXG4gICAgICAgICAgICBQaWNrTG9jYXRpb24gOiB0aGlzLmN1cnJlbnRMb2NhdGlvbixcbiAgICAgICAgICAgIERyb3BMb2NhdGlvbjp0aGlzLnNlYXJjaFBocmFzZSxcbiAgICAgICAgICAgIGxhdGl0dWRlIDogcGFyc2VGbG9hdCh0aGlzLkZyb21MYXQpLFxuICAgICAgICAgICAgbG9uZ2l0dWRlIDogcGFyc2VGbG9hdCh0aGlzLkZyb21Mb25nKSxcbiAgICAgICAgICAgIFVzZXJOYW1lIDogQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJlbWFpbFwiKSxcbiAgICAgICAgICAgIFZlaGljbGVUeXBlVGV4dCA6IHRoaXMuaXRlbXNbdGhpcy5zZWxlY3RlZEluZGV4XSxcbiAgICAgICAgICAgIFN0YXJ0VGltZSA6IFwiXCIsXG4gICAgICAgICAgICBvZmZlclJpZGU6ZmFsc2UgICBcbiAgICAgICAgfVxuXG4gICAgICAgIGxldCBtaW51dGVzID0gKHRoaXMuc2VsZWN0ZWRSaWRlVGltZS5nZXRNaW51dGVzKCkudG9TdHJpbmcoKS5sZW5ndGggPT0gMSkgP1xuICAgICAgICAgICAgXCIwXCIgKyB0aGlzLnNlbGVjdGVkUmlkZVRpbWUuZ2V0TWludXRlcygpLnRvU3RyaW5nKCkgOlxuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZFJpZGVUaW1lLmdldE1pbnV0ZXMoKS50b1N0cmluZygpO1xuXG4gICAgICAgIHJpZGVSZXF1ZXN0LlN0YXJ0VGltZSA9IHRoaXMuc2VsZWN0ZWRSaWRlVGltZSArIFwiIDogXCIgKyBtaW51dGVzO1xuXG4gICAgICAgIHZhciBvYmpPZmZlciA9IHsgT2ZmZXJSaWRlOiByaWRlUmVxdWVzdCB9O1xuXG4gICAgICAgIHRoaXMuc2hvd0xvYWRlciA9IHRydWU7XG4gICAgICAgIHRoaXMuYmlrZXBvb2xzZXJ2aWNlLlBvc3RTZXJ2aWNlKFNlcnZpY2VVUkwuT2ZmZXJSaWRlLCBvYmpPZmZlcikuc3Vic2NyaWJlKFxuICAgICAgICAgICAgc3VjY2VzcyA9PiB0aGlzLlJpZGVSZXF1ZXN0U3VjY2VzcyhzdWNjZXNzKSxcbiAgICAgICAgICAgIGVycm9yID0+IHRoaXMuUmlkZVJlcXVlc3RFcnJvcihlcnJvcilcbiAgICAgICAgKVxuICAgIH1cbn1cbiJdfQ==