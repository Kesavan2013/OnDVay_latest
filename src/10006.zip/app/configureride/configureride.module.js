"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("nativescript-angular/common");
var forms_1 = require("nativescript-angular/forms");
var configureride_routing_module_1 = require("./configureride-routing.module");
var configureride_component_1 = require("./configureride.component");
var ConfigureRideModule = /** @class */ (function () {
    function ConfigureRideModule() {
    }
    ConfigureRideModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.NativeScriptCommonModule,
                configureride_routing_module_1.ConfigureRideRoutingModule,
                forms_1.NativeScriptFormsModule
            ],
            declarations: [
                configureride_component_1.ConfigurerideComponent
            ],
            schemas: [
                core_1.NO_ERRORS_SCHEMA
            ]
        })
    ], ConfigureRideModule);
    return ConfigureRideModule;
}());
exports.ConfigureRideModule = ConfigureRideModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlndXJlcmlkZS5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJjb25maWd1cmVyaWRlLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUEyRDtBQUMzRCxzREFBdUU7QUFDdkUsb0RBQXFFO0FBQ3JFLCtFQUE0RTtBQUM1RSxxRUFBbUU7QUFlbkU7SUFBQTtJQUFtQyxDQUFDO0lBQXZCLG1CQUFtQjtRQWIvQixlQUFRLENBQUM7WUFDTixPQUFPLEVBQUU7Z0JBQ0wsaUNBQXdCO2dCQUN4Qix5REFBMEI7Z0JBQzFCLCtCQUF1QjthQUMxQjtZQUNELFlBQVksRUFBRTtnQkFDVixnREFBc0I7YUFDekI7WUFDRCxPQUFPLEVBQUU7Z0JBQ0wsdUJBQWdCO2FBQ25CO1NBQ0osQ0FBQztPQUNXLG1CQUFtQixDQUFJO0lBQUQsMEJBQUM7Q0FBQSxBQUFwQyxJQUFvQztBQUF2QixrREFBbUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSwgTk9fRVJST1JTX1NDSEVNQSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7IE5hdGl2ZVNjcmlwdENvbW1vbk1vZHVsZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9jb21tb25cIjtcclxuaW1wb3J0IHsgTmF0aXZlU2NyaXB0Rm9ybXNNb2R1bGUgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvZm9ybXNcIjtcclxuaW1wb3J0IHsgQ29uZmlndXJlUmlkZVJvdXRpbmdNb2R1bGUgfSBmcm9tIFwiLi9jb25maWd1cmVyaWRlLXJvdXRpbmcubW9kdWxlXCI7XHJcbmltcG9ydCB7IENvbmZpZ3VyZXJpZGVDb21wb25lbnQgfSBmcm9tIFwiLi9jb25maWd1cmVyaWRlLmNvbXBvbmVudFwiO1xyXG5cclxuQE5nTW9kdWxlKHtcclxuICAgIGltcG9ydHM6IFtcclxuICAgICAgICBOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUsXHJcbiAgICAgICAgQ29uZmlndXJlUmlkZVJvdXRpbmdNb2R1bGUsXHJcbiAgICAgICAgTmF0aXZlU2NyaXB0Rm9ybXNNb2R1bGVcclxuICAgIF0sXHJcbiAgICBkZWNsYXJhdGlvbnM6IFtcclxuICAgICAgICBDb25maWd1cmVyaWRlQ29tcG9uZW50XHJcbiAgICBdLFxyXG4gICAgc2NoZW1hczogW1xyXG4gICAgICAgIE5PX0VSUk9SU19TQ0hFTUFcclxuICAgIF1cclxufSlcclxuZXhwb3J0IGNsYXNzIENvbmZpZ3VyZVJpZGVNb2R1bGUgeyB9XHJcbiJdfQ==