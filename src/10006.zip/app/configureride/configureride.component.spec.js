"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var testing_1 = require("@angular/core/testing");
var configureride_component_1 = require("./configureride.component");
describe('a configureride component', function () {
    var component;
    // register all needed dependencies
    beforeEach(function () {
        testing_1.TestBed.configureTestingModule({
            providers: [
                configureride_component_1.ConfigurerideComponent
            ]
        });
    });
    // instantiation through framework injection
    beforeEach(testing_1.inject([configureride_component_1.ConfigurerideComponent], function (ConfigurerideComponent) {
        component = ConfigurerideComponent;
    }));
    it('should have an instance', function () {
        expect(component).toBeDefined();
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlndXJlcmlkZS5jb21wb25lbnQuc3BlYy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImNvbmZpZ3VyZXJpZGUuY29tcG9uZW50LnNwZWMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxpREFBd0Q7QUFFeEQscUVBQW1FO0FBRW5FLFFBQVEsQ0FBQywyQkFBMkIsRUFBRTtJQUNyQyxJQUFJLFNBQWlDLENBQUM7SUFFdEMsbUNBQW1DO0lBQ25DLFVBQVUsQ0FBQztRQUNWLGlCQUFPLENBQUMsc0JBQXNCLENBQUM7WUFDOUIsU0FBUyxFQUFFO2dCQUNWLGdEQUFzQjthQUN0QjtTQUNELENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQyxDQUFDO0lBRUgsNENBQTRDO0lBQzVDLFVBQVUsQ0FBQyxnQkFBTSxDQUFDLENBQUMsZ0RBQXNCLENBQUMsRUFBRSxVQUFDLHNCQUFzQjtRQUNsRSxTQUFTLEdBQUcsc0JBQXNCLENBQUM7SUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUVKLEVBQUUsQ0FBQyx5QkFBeUIsRUFBRTtRQUM3QixNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDakMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFRlc3RCZWQsIGluamVjdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUvdGVzdGluZyc7XHJcblxyXG5pbXBvcnQgeyBDb25maWd1cmVyaWRlQ29tcG9uZW50IH0gZnJvbSAnLi9jb25maWd1cmVyaWRlLmNvbXBvbmVudCc7XHJcblxyXG5kZXNjcmliZSgnYSBjb25maWd1cmVyaWRlIGNvbXBvbmVudCcsICgpID0+IHtcclxuXHRsZXQgY29tcG9uZW50OiBDb25maWd1cmVyaWRlQ29tcG9uZW50O1xyXG5cclxuXHQvLyByZWdpc3RlciBhbGwgbmVlZGVkIGRlcGVuZGVuY2llc1xyXG5cdGJlZm9yZUVhY2goKCkgPT4ge1xyXG5cdFx0VGVzdEJlZC5jb25maWd1cmVUZXN0aW5nTW9kdWxlKHtcclxuXHRcdFx0cHJvdmlkZXJzOiBbXHJcblx0XHRcdFx0Q29uZmlndXJlcmlkZUNvbXBvbmVudFxyXG5cdFx0XHRdXHJcblx0XHR9KTtcclxuXHR9KTtcclxuXHJcblx0Ly8gaW5zdGFudGlhdGlvbiB0aHJvdWdoIGZyYW1ld29yayBpbmplY3Rpb25cclxuXHRiZWZvcmVFYWNoKGluamVjdChbQ29uZmlndXJlcmlkZUNvbXBvbmVudF0sIChDb25maWd1cmVyaWRlQ29tcG9uZW50KSA9PiB7XHJcblx0XHRjb21wb25lbnQgPSBDb25maWd1cmVyaWRlQ29tcG9uZW50O1xyXG5cdH0pKTtcclxuXHJcblx0aXQoJ3Nob3VsZCBoYXZlIGFuIGluc3RhbmNlJywgKCkgPT4ge1xyXG5cdFx0ZXhwZWN0KGNvbXBvbmVudCkudG9CZURlZmluZWQoKTtcclxuXHR9KTtcclxufSk7Il19