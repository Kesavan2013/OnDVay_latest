"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var app = require("tns-core-modules/application");
var configureride_1 = require("../shared/models/configureride");
var bikepoolservice_1 = require("../shared/bikepoolservice");
var services_1 = require("../shared/services");
var ApplicationSettings = require("application-settings");
var router_1 = require("@angular/router");
var nativescript_loading_screen_1 = require("nativescript-loading-screen");
var ConfigurerideComponent = /** @class */ (function () {
    function ConfigurerideComponent(bikepoolservice, router) {
        this.bikepoolservice = bikepoolservice;
        this.router = router;
        this.loadingScreen = new nativescript_loading_screen_1.LoadingScreen();
        this.configure = new configureride_1.ConfigureRide();
    }
    ConfigurerideComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.LoaderShow();
        var userId = { userId: ApplicationSettings.getString("userid") };
        this.bikepoolservice.PostService(services_1.ServiceURL.GetCongfigureRider, userId).subscribe(function (configure) { return _this.getConfigureRideSuccess(configure); }, function (error) { return _this.getConfigureError(error); });
    };
    ConfigurerideComponent.prototype.getConfigureError = function (error) {
        this.hideLoader();
    };
    ConfigurerideComponent.prototype.getConfigureRideSuccess = function (configure) {
        this.hideLoader();
        if (configure.success) {
            var objConfigure = configure.Data;
            this.configure.ContactNumber = objConfigure.ContactNumber;
            this.configure.Price = objConfigure.Price;
            this.configure.VechileName = objConfigure.VechileName;
            this.configure.VechileNumber = objConfigure.VechileNumber;
        }
    };
    ConfigurerideComponent.prototype.saveConfigure = function () {
        var _this = this;
        this.LoaderShow();
        this.configure.userId = ApplicationSettings.getString("userid");
        var objConfigureRider = { ConfigureRider: this.configure };
        this.bikepoolservice.PostService(services_1.ServiceURL.ConfigureRider, objConfigureRider).subscribe(function (success) { return _this.configureRideSuccess(success); }, function (error) { return _this.configureRideError(error); });
    };
    ConfigurerideComponent.prototype.configureRideSuccess = function (success) {
        this.hideLoader();
        this.router.navigate(['home']);
    };
    ConfigurerideComponent.prototype.configureRideError = function (error) {
        this.hideLoader();
        console.log(error);
    };
    ConfigurerideComponent.prototype.onDrawerButtonTap = function () {
        var sideDrawer = app.getRootView();
        sideDrawer.showDrawer();
    };
    ConfigurerideComponent.prototype.hideLoader = function () {
        this.loadingScreen.close();
    };
    ConfigurerideComponent.prototype.LoaderShow = function () {
        this.loadingScreen.show({
            message: "Loading..."
        });
    };
    ConfigurerideComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'configureride',
            templateUrl: './configureride.component.html'
        }),
        __metadata("design:paramtypes", [bikepoolservice_1.BikePoolService, router_1.Router])
    ], ConfigurerideComponent);
    return ConfigurerideComponent;
}());
exports.ConfigurerideComponent = ConfigurerideComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlndXJlcmlkZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJjb25maWd1cmVyaWRlLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQUNsRCxrREFBb0Q7QUFFcEQsZ0VBQStEO0FBQy9ELDZEQUE0RDtBQUM1RCwrQ0FBZ0Q7QUFDaEQsMERBQTREO0FBQzVELDBDQUEyRDtBQUMzRCwyRUFBNEQ7QUFRNUQ7SUFLQyxnQ0FBb0IsZUFBZ0MsRUFBUyxNQUFjO1FBQXZELG9CQUFlLEdBQWYsZUFBZSxDQUFpQjtRQUFTLFdBQU0sR0FBTixNQUFNLENBQVE7UUFDMUUsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLDJDQUFhLEVBQUUsQ0FBQztRQUN6QyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksNkJBQWEsRUFBRSxDQUFDO0lBQ3RDLENBQUM7SUFFRCx5Q0FBUSxHQUFSO1FBQUEsaUJBT0M7UUFOQSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxNQUFNLEdBQUcsRUFBRSxNQUFNLEVBQUcsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxFQUFDLENBQUM7UUFDakUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxrQkFBa0IsRUFBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQy9FLFVBQUEsU0FBUyxJQUFJLE9BQUEsS0FBSSxDQUFDLHVCQUF1QixDQUFDLFNBQVMsQ0FBQyxFQUF2QyxDQUF1QyxFQUNwRCxVQUFBLEtBQUssSUFBSSxPQUFBLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsRUFBN0IsQ0FBNkIsQ0FDdEMsQ0FBQTtJQUNGLENBQUM7SUFFRCxrREFBaUIsR0FBakIsVUFBa0IsS0FBSztRQUV0QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDbkIsQ0FBQztJQUVELHdEQUF1QixHQUF2QixVQUF3QixTQUFTO1FBRWhDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFHLFNBQVMsQ0FBQyxPQUFPLEVBQ3BCO1lBQ0MsSUFBSSxZQUFZLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQztZQUNsQyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsR0FBRyxZQUFZLENBQUMsYUFBYSxDQUFDO1lBQzFELElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQyxLQUFLLENBQUM7WUFDMUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEdBQUcsWUFBWSxDQUFDLFdBQVcsQ0FBQztZQUN0RCxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsR0FBRyxZQUFZLENBQUMsYUFBYSxDQUFDO1NBQzFEO0lBQ0YsQ0FBQztJQUVELDhDQUFhLEdBQWI7UUFBQSxpQkFTQztRQVBBLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDaEUsSUFBSSxpQkFBaUIsR0FBRyxFQUFFLGNBQWMsRUFBRyxJQUFJLENBQUMsU0FBUyxFQUFDLENBQUE7UUFDMUQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxjQUFjLEVBQUMsaUJBQWlCLENBQUMsQ0FBQyxTQUFTLENBQ3RGLFVBQUEsT0FBTyxJQUFJLE9BQUEsS0FBSSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxFQUFsQyxDQUFrQyxFQUM3QyxVQUFBLEtBQUssSUFBSSxPQUFBLEtBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsRUFBOUIsQ0FBOEIsQ0FDdkMsQ0FBQTtJQUNGLENBQUM7SUFFRCxxREFBb0IsR0FBcEIsVUFBcUIsT0FBTztRQUUzQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFFRCxtREFBa0IsR0FBbEIsVUFBbUIsS0FBSztRQUV2QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNwQixDQUFDO0lBRUQsa0RBQWlCLEdBQWpCO1FBQ0MsSUFBTSxVQUFVLEdBQWtCLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNwRCxVQUFVLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDdkIsQ0FBQztJQUVILDJDQUFVLEdBQVY7UUFDQyxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCwyQ0FBVSxHQUFWO1FBQ0MsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUM7WUFDdkIsT0FBTyxFQUFFLFlBQVk7U0FDckIsQ0FBQyxDQUFDO0lBQ0osQ0FBQztJQXpFVyxzQkFBc0I7UUFObEMsZ0JBQVMsQ0FBQztZQUNWLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixRQUFRLEVBQUUsZUFBZTtZQUN6QixXQUFXLEVBQUUsZ0NBQWdDO1NBQzdDLENBQUM7eUNBT29DLGlDQUFlLEVBQWlCLGVBQU07T0FML0Qsc0JBQXNCLENBMEVsQztJQUFELDZCQUFDO0NBQUEsQUExRUQsSUEwRUM7QUExRVksd0RBQXNCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcclxuaW1wb3J0ICogYXMgYXBwIGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL2FwcGxpY2F0aW9uXCI7XHJcbmltcG9ydCB7IFJhZFNpZGVEcmF3ZXIgfSBmcm9tIFwibmF0aXZlc2NyaXB0LXVpLXNpZGVkcmF3ZXJcIjtcclxuaW1wb3J0IHsgQ29uZmlndXJlUmlkZSB9IGZyb20gXCIuLi9zaGFyZWQvbW9kZWxzL2NvbmZpZ3VyZXJpZGVcIjtcclxuaW1wb3J0IHsgQmlrZVBvb2xTZXJ2aWNlIH0gZnJvbSBcIi4uL3NoYXJlZC9iaWtlcG9vbHNlcnZpY2VcIjtcclxuaW1wb3J0IHsgU2VydmljZVVSTCB9IGZyb20gXCIuLi9zaGFyZWQvc2VydmljZXNcIjtcclxuaW1wb3J0ICogYXMgQXBwbGljYXRpb25TZXR0aW5ncyBmcm9tIFwiYXBwbGljYXRpb24tc2V0dGluZ3NcIjtcclxuaW1wb3J0IHsgUm91dGVyLCBOYXZpZ2F0aW9uRXh0cmFzIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xyXG5pbXBvcnQgeyBMb2FkaW5nU2NyZWVuIH0gZnJvbSAnbmF0aXZlc2NyaXB0LWxvYWRpbmctc2NyZWVuJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG5cdG1vZHVsZUlkOiBtb2R1bGUuaWQsXHJcblx0c2VsZWN0b3I6ICdjb25maWd1cmVyaWRlJyxcclxuXHR0ZW1wbGF0ZVVybDogJy4vY29uZmlndXJlcmlkZS5jb21wb25lbnQuaHRtbCdcclxufSlcclxuXHJcbmV4cG9ydCBjbGFzcyBDb25maWd1cmVyaWRlQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuXHJcblx0Y29uZmlndXJlIDogQ29uZmlndXJlUmlkZTtcclxuXHRwcml2YXRlIGxvYWRpbmdTY3JlZW46IExvYWRpbmdTY3JlZW47XHRcclxuXHJcblx0Y29uc3RydWN0b3IocHJpdmF0ZSBiaWtlcG9vbHNlcnZpY2U6IEJpa2VQb29sU2VydmljZSxwcml2YXRlIHJvdXRlcjogUm91dGVyKSB7XHRcdFxyXG5cdFx0dGhpcy5sb2FkaW5nU2NyZWVuID0gbmV3IExvYWRpbmdTY3JlZW4oKTtcdFxyXG5cdFx0dGhpcy5jb25maWd1cmUgPSBuZXcgQ29uZmlndXJlUmlkZSgpO1x0XHRcclxuXHR9XHJcblxyXG5cdG5nT25Jbml0KCkge1xyXG5cdFx0dGhpcy5Mb2FkZXJTaG93KCk7XHRcdFx0XHRcclxuXHRcdGxldCB1c2VySWQgPSB7IHVzZXJJZCA6IEFwcGxpY2F0aW9uU2V0dGluZ3MuZ2V0U3RyaW5nKFwidXNlcmlkXCIpfTtcdFx0XHJcblx0XHR0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLkdldENvbmdmaWd1cmVSaWRlcix1c2VySWQpLnN1YnNjcmliZShcclxuXHRcdFx0Y29uZmlndXJlID0+IHRoaXMuZ2V0Q29uZmlndXJlUmlkZVN1Y2Nlc3MoY29uZmlndXJlKSxcclxuXHRcdFx0ZXJyb3IgPT4gdGhpcy5nZXRDb25maWd1cmVFcnJvcihlcnJvcilcclxuXHRcdClcclxuXHR9XHJcblxyXG5cdGdldENvbmZpZ3VyZUVycm9yKGVycm9yKVxyXG5cdHtcclxuXHRcdHRoaXMuaGlkZUxvYWRlcigpO1x0XHRcclxuXHR9XHJcblxyXG5cdGdldENvbmZpZ3VyZVJpZGVTdWNjZXNzKGNvbmZpZ3VyZSlcclxuXHR7XHJcblx0XHR0aGlzLmhpZGVMb2FkZXIoKTtcdFx0XHJcblx0XHRpZihjb25maWd1cmUuc3VjY2VzcylcclxuXHRcdHtcdFx0XHRcclxuXHRcdFx0bGV0IG9iakNvbmZpZ3VyZSA9IGNvbmZpZ3VyZS5EYXRhO1xyXG5cdFx0XHR0aGlzLmNvbmZpZ3VyZS5Db250YWN0TnVtYmVyID0gb2JqQ29uZmlndXJlLkNvbnRhY3ROdW1iZXI7XHJcblx0XHRcdHRoaXMuY29uZmlndXJlLlByaWNlID0gb2JqQ29uZmlndXJlLlByaWNlO1xyXG5cdFx0XHR0aGlzLmNvbmZpZ3VyZS5WZWNoaWxlTmFtZSA9IG9iakNvbmZpZ3VyZS5WZWNoaWxlTmFtZTtcclxuXHRcdFx0dGhpcy5jb25maWd1cmUuVmVjaGlsZU51bWJlciA9IG9iakNvbmZpZ3VyZS5WZWNoaWxlTnVtYmVyO1x0XHRcdFx0XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHRzYXZlQ29uZmlndXJlKCl7XHJcblx0XHRcclxuXHRcdHRoaXMuTG9hZGVyU2hvdygpO1xyXG5cdFx0dGhpcy5jb25maWd1cmUudXNlcklkID0gQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJ1c2VyaWRcIik7XHJcblx0XHR2YXIgb2JqQ29uZmlndXJlUmlkZXIgPSB7IENvbmZpZ3VyZVJpZGVyIDogdGhpcy5jb25maWd1cmV9XHJcblx0XHR0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLkNvbmZpZ3VyZVJpZGVyLG9iakNvbmZpZ3VyZVJpZGVyKS5zdWJzY3JpYmUoXHJcblx0XHRcdHN1Y2Nlc3MgPT4gdGhpcy5jb25maWd1cmVSaWRlU3VjY2VzcyhzdWNjZXNzKSxcclxuXHRcdFx0ZXJyb3IgPT4gdGhpcy5jb25maWd1cmVSaWRlRXJyb3IoZXJyb3IpXHJcblx0XHQpXHJcblx0fVxyXG5cclxuXHRjb25maWd1cmVSaWRlU3VjY2VzcyhzdWNjZXNzKVxyXG5cdHtcclxuXHRcdHRoaXMuaGlkZUxvYWRlcigpO1xyXG5cdFx0dGhpcy5yb3V0ZXIubmF2aWdhdGUoWydob21lJ10pO1xyXG5cdH1cclxuXHJcblx0Y29uZmlndXJlUmlkZUVycm9yKGVycm9yKVxyXG5cdHtcclxuXHRcdHRoaXMuaGlkZUxvYWRlcigpO1xyXG5cdFx0Y29uc29sZS5sb2coZXJyb3IpO1xyXG5cdH1cclxuXHJcblx0b25EcmF3ZXJCdXR0b25UYXAoKTogdm9pZCB7XHJcblx0XHRjb25zdCBzaWRlRHJhd2VyID0gPFJhZFNpZGVEcmF3ZXI+YXBwLmdldFJvb3RWaWV3KCk7XHJcblx0XHRzaWRlRHJhd2VyLnNob3dEcmF3ZXIoKTtcclxuXHQgIH1cclxuXHJcblx0aGlkZUxvYWRlcigpIHtcdFxyXG5cdFx0dGhpcy5sb2FkaW5nU2NyZWVuLmNsb3NlKCk7XHJcblx0fVxyXG5cdFxyXG5cdExvYWRlclNob3coKSB7XHRcdFxyXG5cdFx0dGhpcy5sb2FkaW5nU2NyZWVuLnNob3coe1xyXG5cdFx0XHRtZXNzYWdlOiBcIkxvYWRpbmcuLi5cIlxyXG5cdFx0fSk7XHJcblx0fVxyXG59Il19