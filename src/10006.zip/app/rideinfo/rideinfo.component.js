"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var bikepoolservice_1 = require("../shared/bikepoolservice");
var services_1 = require("../shared/services");
var app = require("tns-core-modules/application");
var dialogs_1 = require("tns-core-modules/ui/dialogs");
var RideInfo = /** @class */ (function () {
    function RideInfo() {
    }
    return RideInfo;
}());
exports.RideInfo = RideInfo;
var RideInfoComponent = /** @class */ (function () {
    function RideInfoComponent(route, bikepoolservice) {
        var _this = this;
        this.route = route;
        this.bikepoolservice = bikepoolservice;
        this.route.queryParams.subscribe(function (params) {
            var notification = params["objNotificationMessage"];
            _this.rideInfo = new RideInfo();
            var objNotification = JSON.parse(notification);
            _this.rideInfo.RideFromLocation = objNotification.rideLocation;
            _this.rideInfo.RideToLocation = objNotification.destinationLocation;
            _this.rideInfo.RideDistance = objNotification.rideDistance;
            _this.rideInfo.RidePickUpTime = objNotification.rideStartTime;
            _this.rideInfo.RideStatus = objNotification.ridestatus;
            _this.rideInfo.RideFromDeviceToken = objNotification.device_token;
            _this.rideInfo.RideContactNo = "000000";
            if (objNotification.phoneNo != undefined) {
                _this.rideInfo.RideContactNo = objNotification.phoneNo;
                console.log("RideContactno" + _this.rideInfo.RideContactNo);
            }
            else {
                _this.rideInfo.riderContactNo = '';
            }
            console.log("status" + _this.rideInfo.RideContactNo);
        });
    }
    RideInfoComponent.prototype.ngOnInit = function () {
    };
    RideInfoComponent.prototype.GetRideInformation = function (status, phoneno) {
        var objdeviceToken = [];
        objdeviceToken.push({ deviceToken: this.rideInfo.RideFromDeviceToken });
        console.log("Phoneno" + this.rideContactNo);
        var objRideStatus = {
            deviceToken: objdeviceToken,
            requestStatus: status,
            currentLocation: this.rideInfo.RideFromLocation,
            destinationLocation: this.rideInfo.RideToLocation,
            phoneNo: phoneno
        };
        return objRideStatus;
    };
    RideInfoComponent.prototype.onAccept = function () {
        var _this = this;
        dialogs_1.prompt({
            title: "On D Vay",
            message: "Please enter contact number for ride.",
            defaultText: "",
            okButtonText: "Ok",
            cancelButtonText: "Cancel"
        }).then(function (data) {
            if (data.result) {
                // Call the backend to reset the password
                var objemail = { emailAddress: data.text.toString().trim() };
                var objRide = _this.GetRideInformation(1, data.text.toString());
                _this.bikepoolservice.PostService(services_1.ServiceURL.RideStatus, objRide).subscribe(function (ride) { return console.log("success" + JSON.stringify(ride)); }, function (error) { return console.log("error" + error); });
            }
        });
    };
    RideInfoComponent.prototype.OnCancel = function () {
        var objRide = this.GetRideInformation(0, "00000");
        this.bikepoolservice.PostService(services_1.ServiceURL.RideStatus, objRide).subscribe(function (ride) { return console.log(ride); }, function (error) { return console.log(error); });
    };
    RideInfoComponent.prototype.onDrawerButtonTap = function () {
        var sideDrawer = app.getRootView();
        sideDrawer.showDrawer();
    };
    RideInfoComponent = __decorate([
        core_1.Component({
            selector: 'ns-rideinfo',
            templateUrl: './rideinfo.component.html',
            moduleId: module.id,
        }),
        __metadata("design:paramtypes", [router_1.ActivatedRoute, bikepoolservice_1.BikePoolService])
    ], RideInfoComponent);
    return RideInfoComponent;
}());
exports.RideInfoComponent = RideInfoComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmlkZWluZm8uY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicmlkZWluZm8uY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQXNHO0FBQ3RHLDBDQUFpRDtBQUNqRCw2REFBNEQ7QUFDNUQsK0NBQStDO0FBRS9DLGtEQUFvRDtBQUNwRCx1REFBNEQ7QUFFNUQ7SUFBQTtJQVNBLENBQUM7SUFBRCxlQUFDO0FBQUQsQ0FBQyxBQVRELElBU0M7QUFUWSw0QkFBUTtBQWdCckI7SUFJRSwyQkFBb0IsS0FBcUIsRUFBVSxlQUFnQztRQUFuRixpQkF1QkM7UUF2Qm1CLFVBQUssR0FBTCxLQUFLLENBQWdCO1FBQVUsb0JBQWUsR0FBZixlQUFlLENBQWlCO1FBQ2pGLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxVQUFBLE1BQU07WUFDckMsSUFBSSxZQUFZLEdBQUcsTUFBTSxDQUFDLHdCQUF3QixDQUFDLENBQUM7WUFFcEQsS0FBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLFFBQVEsRUFBRSxDQUFDO1lBRS9CLElBQUksZUFBZSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDL0MsS0FBSSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsR0FBRyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQzlELEtBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxHQUFHLGVBQWUsQ0FBQyxtQkFBbUIsQ0FBQztZQUNuRSxLQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksR0FBRyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQzFELEtBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxHQUFHLGVBQWUsQ0FBQyxhQUFhLENBQUM7WUFDN0QsS0FBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEdBQUcsZUFBZSxDQUFDLFVBQVUsQ0FBQztZQUN0RCxLQUFJLENBQUMsUUFBUSxDQUFDLG1CQUFtQixHQUFHLGVBQWUsQ0FBQyxZQUFZLENBQUM7WUFDakUsS0FBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDO1lBQ3ZDLElBQUksZUFBZSxDQUFDLE9BQU8sSUFBSSxTQUFTLEVBQUU7Z0JBQ3hDLEtBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxHQUFHLGVBQWUsQ0FBQyxPQUFPLENBQUM7Z0JBQ3RELE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxHQUFHLEtBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUM7YUFDNUQ7aUJBQ0k7Z0JBQ0gsS0FBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO2FBQ25DO1lBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEdBQUcsS0FBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUN0RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxvQ0FBUSxHQUFSO0lBQ0EsQ0FBQztJQUVELDhDQUFrQixHQUFsQixVQUFtQixNQUFNLEVBQUMsT0FBTztRQUMvQixJQUFJLGNBQWMsR0FBRyxFQUFFLENBQUM7UUFDeEIsY0FBYyxDQUFDLElBQUksQ0FBQyxFQUFFLFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLG1CQUFtQixFQUFFLENBQUMsQ0FBQTtRQUV2RSxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDNUMsSUFBSSxhQUFhLEdBQUc7WUFDbEIsV0FBVyxFQUFFLGNBQWM7WUFDM0IsYUFBYSxFQUFFLE1BQU07WUFDckIsZUFBZSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCO1lBQy9DLG1CQUFtQixFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYztZQUNqRCxPQUFPLEVBQUUsT0FBTztTQUNqQixDQUFBO1FBRUQsT0FBTyxhQUFhLENBQUM7SUFDdkIsQ0FBQztJQUVELG9DQUFRLEdBQVI7UUFBQSxpQkFvQkM7UUFsQkMsZ0JBQU0sQ0FBQztZQUNMLEtBQUssRUFBRSxVQUFVO1lBQ2pCLE9BQU8sRUFBRSx1Q0FBdUM7WUFDaEQsV0FBVyxFQUFFLEVBQUU7WUFDZixZQUFZLEVBQUUsSUFBSTtZQUNsQixnQkFBZ0IsRUFBRSxRQUFRO1NBQzNCLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxJQUFJO1lBQ1gsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUNmLHlDQUF5QztnQkFFekMsSUFBSSxRQUFRLEdBQUcsRUFBRSxZQUFZLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFBO2dCQUM1RCxJQUFJLE9BQU8sR0FBRyxLQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztnQkFDOUQsS0FBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUN4RSxVQUFBLElBQUksSUFBSSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBN0MsQ0FBNkMsRUFDckQsVUFBQSxLQUFLLElBQUksT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUMsRUFBNUIsQ0FBNEIsQ0FDdEMsQ0FBQTthQUNGO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsb0NBQVEsR0FBUjtRQUNFLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEVBQUMsT0FBTyxDQUFDLENBQUM7UUFFakQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUN4RSxVQUFBLElBQUksSUFBSSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQWpCLENBQWlCLEVBQ3pCLFVBQUEsS0FBSyxJQUFJLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBbEIsQ0FBa0IsQ0FDNUIsQ0FBQTtJQUNILENBQUM7SUFFRCw2Q0FBaUIsR0FBakI7UUFDRSxJQUFNLFVBQVUsR0FBa0IsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3BELFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBbEZVLGlCQUFpQjtRQUw3QixnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLGFBQWE7WUFDdkIsV0FBVyxFQUFFLDJCQUEyQjtZQUN4QyxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7U0FDcEIsQ0FBQzt5Q0FLMkIsdUJBQWMsRUFBMkIsaUNBQWU7T0FKeEUsaUJBQWlCLENBb0Y3QjtJQUFELHdCQUFDO0NBQUEsQUFwRkQsSUFvRkM7QUFwRlksOENBQWlCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIEluamVjdGFibGUsIFZpZXdDaGlsZCwgTmdab25lLCBEb0NoZWNrLCBFbGVtZW50UmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBBY3RpdmF0ZWRSb3V0ZSB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IEJpa2VQb29sU2VydmljZSB9IGZyb20gXCIuLi9zaGFyZWQvYmlrZXBvb2xzZXJ2aWNlXCI7XG5pbXBvcnQgeyBTZXJ2aWNlVVJMIH0gZnJvbSBcIi4uL3NoYXJlZC9zZXJ2aWNlc1wiXG5pbXBvcnQgeyBSYWRTaWRlRHJhd2VyIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC11aS1zaWRlZHJhd2VyXCI7XG5pbXBvcnQgKiBhcyBhcHAgZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvYXBwbGljYXRpb25cIjtcbmltcG9ydCB7IGFsZXJ0LCBwcm9tcHQgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy91aS9kaWFsb2dzXCI7XG5cbmV4cG9ydCBjbGFzcyBSaWRlSW5mbyB7XG4gIFJpZGVGcm9tTG9jYXRpb246IHN0cmluZ1xuICBSaWRlVG9Mb2NhdGlvbjogc3RyaW5nXG4gIFJpZGVEaXN0YW5jZTogc3RyaW5nXG4gIFJpZGVQaWNrVXBUaW1lOiBzdHJpbmdcbiAgUmlkZVN0YXR1czogc3RyaW5nXG4gIFJpZGVGcm9tRGV2aWNlVG9rZW46IHN0cmluZ1xuICBSaWRlQ29udGFjdE5vOiBzdHJpbmdcbiAgcmlkZXJDb250YWN0Tm86IGFueVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICducy1yaWRlaW5mbycsXG4gIHRlbXBsYXRlVXJsOiAnLi9yaWRlaW5mby5jb21wb25lbnQuaHRtbCcsXG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXG59KVxuZXhwb3J0IGNsYXNzIFJpZGVJbmZvQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcblxuICBwdWJsaWMgcmlkZUluZm86IFJpZGVJbmZvO1xuICByaWRlQ29udGFjdE5vOiBhbnk7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcm91dGU6IEFjdGl2YXRlZFJvdXRlLCBwcml2YXRlIGJpa2Vwb29sc2VydmljZTogQmlrZVBvb2xTZXJ2aWNlKSB7XG4gICAgdGhpcy5yb3V0ZS5xdWVyeVBhcmFtcy5zdWJzY3JpYmUocGFyYW1zID0+IHtcbiAgICAgIGxldCBub3RpZmljYXRpb24gPSBwYXJhbXNbXCJvYmpOb3RpZmljYXRpb25NZXNzYWdlXCJdO1xuXG4gICAgICB0aGlzLnJpZGVJbmZvID0gbmV3IFJpZGVJbmZvKCk7XG5cbiAgICAgIHZhciBvYmpOb3RpZmljYXRpb24gPSBKU09OLnBhcnNlKG5vdGlmaWNhdGlvbik7XG4gICAgICB0aGlzLnJpZGVJbmZvLlJpZGVGcm9tTG9jYXRpb24gPSBvYmpOb3RpZmljYXRpb24ucmlkZUxvY2F0aW9uO1xuICAgICAgdGhpcy5yaWRlSW5mby5SaWRlVG9Mb2NhdGlvbiA9IG9iak5vdGlmaWNhdGlvbi5kZXN0aW5hdGlvbkxvY2F0aW9uO1xuICAgICAgdGhpcy5yaWRlSW5mby5SaWRlRGlzdGFuY2UgPSBvYmpOb3RpZmljYXRpb24ucmlkZURpc3RhbmNlO1xuICAgICAgdGhpcy5yaWRlSW5mby5SaWRlUGlja1VwVGltZSA9IG9iak5vdGlmaWNhdGlvbi5yaWRlU3RhcnRUaW1lO1xuICAgICAgdGhpcy5yaWRlSW5mby5SaWRlU3RhdHVzID0gb2JqTm90aWZpY2F0aW9uLnJpZGVzdGF0dXM7XG4gICAgICB0aGlzLnJpZGVJbmZvLlJpZGVGcm9tRGV2aWNlVG9rZW4gPSBvYmpOb3RpZmljYXRpb24uZGV2aWNlX3Rva2VuO1xuICAgICAgdGhpcy5yaWRlSW5mby5SaWRlQ29udGFjdE5vID0gXCIwMDAwMDBcIjtcbiAgICAgIGlmIChvYmpOb3RpZmljYXRpb24ucGhvbmVObyAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhpcy5yaWRlSW5mby5SaWRlQ29udGFjdE5vID0gb2JqTm90aWZpY2F0aW9uLnBob25lTm87XG4gICAgICAgIGNvbnNvbGUubG9nKFwiUmlkZUNvbnRhY3Rub1wiICsgdGhpcy5yaWRlSW5mby5SaWRlQ29udGFjdE5vKTtcbiAgICAgIH1cbiAgICAgIGVsc2Uge1xuICAgICAgICB0aGlzLnJpZGVJbmZvLnJpZGVyQ29udGFjdE5vID0gJyc7XG4gICAgICB9XG4gICAgICBjb25zb2xlLmxvZyhcInN0YXR1c1wiICsgdGhpcy5yaWRlSW5mby5SaWRlQ29udGFjdE5vKTtcbiAgICB9KTtcbiAgfVxuXG4gIG5nT25Jbml0KCkge1xuICB9XG5cbiAgR2V0UmlkZUluZm9ybWF0aW9uKHN0YXR1cyxwaG9uZW5vKTogYW55IHtcbiAgICB2YXIgb2JqZGV2aWNlVG9rZW4gPSBbXTtcbiAgICBvYmpkZXZpY2VUb2tlbi5wdXNoKHsgZGV2aWNlVG9rZW46IHRoaXMucmlkZUluZm8uUmlkZUZyb21EZXZpY2VUb2tlbiB9KVxuXG4gICAgY29uc29sZS5sb2coXCJQaG9uZW5vXCIgKyB0aGlzLnJpZGVDb250YWN0Tm8pO1xuICAgIHZhciBvYmpSaWRlU3RhdHVzID0ge1xuICAgICAgZGV2aWNlVG9rZW46IG9iamRldmljZVRva2VuLFxuICAgICAgcmVxdWVzdFN0YXR1czogc3RhdHVzLFxuICAgICAgY3VycmVudExvY2F0aW9uOiB0aGlzLnJpZGVJbmZvLlJpZGVGcm9tTG9jYXRpb24sXG4gICAgICBkZXN0aW5hdGlvbkxvY2F0aW9uOiB0aGlzLnJpZGVJbmZvLlJpZGVUb0xvY2F0aW9uLFxuICAgICAgcGhvbmVObzogcGhvbmVub1xuICAgIH1cblxuICAgIHJldHVybiBvYmpSaWRlU3RhdHVzO1xuICB9XG5cbiAgb25BY2NlcHQoKSB7XG5cbiAgICBwcm9tcHQoe1xuICAgICAgdGl0bGU6IFwiT24gRCBWYXlcIixcbiAgICAgIG1lc3NhZ2U6IFwiUGxlYXNlIGVudGVyIGNvbnRhY3QgbnVtYmVyIGZvciByaWRlLlwiLFxuICAgICAgZGVmYXVsdFRleHQ6IFwiXCIsXG4gICAgICBva0J1dHRvblRleHQ6IFwiT2tcIixcbiAgICAgIGNhbmNlbEJ1dHRvblRleHQ6IFwiQ2FuY2VsXCJcbiAgICB9KS50aGVuKChkYXRhKSA9PiB7XG4gICAgICBpZiAoZGF0YS5yZXN1bHQpIHtcbiAgICAgICAgLy8gQ2FsbCB0aGUgYmFja2VuZCB0byByZXNldCB0aGUgcGFzc3dvcmRcbiAgICAgICAgXG4gICAgICAgIHZhciBvYmplbWFpbCA9IHsgZW1haWxBZGRyZXNzOiBkYXRhLnRleHQudG9TdHJpbmcoKS50cmltKCkgfVxuICAgICAgICB2YXIgb2JqUmlkZSA9IHRoaXMuR2V0UmlkZUluZm9ybWF0aW9uKDEsZGF0YS50ZXh0LnRvU3RyaW5nKCkpO1xuICAgICAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLlJpZGVTdGF0dXMsIG9ialJpZGUpLnN1YnNjcmliZShcbiAgICAgICAgICByaWRlID0+IGNvbnNvbGUubG9nKFwic3VjY2Vzc1wiICsgSlNPTi5zdHJpbmdpZnkocmlkZSkpLFxuICAgICAgICAgIGVycm9yID0+IGNvbnNvbGUubG9nKFwiZXJyb3JcIiArIGVycm9yKVxuICAgICAgICApXG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBPbkNhbmNlbCgpIHtcbiAgICB2YXIgb2JqUmlkZSA9IHRoaXMuR2V0UmlkZUluZm9ybWF0aW9uKDAsXCIwMDAwMFwiKTtcblxuICAgIHRoaXMuYmlrZXBvb2xzZXJ2aWNlLlBvc3RTZXJ2aWNlKFNlcnZpY2VVUkwuUmlkZVN0YXR1cywgb2JqUmlkZSkuc3Vic2NyaWJlKFxuICAgICAgcmlkZSA9PiBjb25zb2xlLmxvZyhyaWRlKSxcbiAgICAgIGVycm9yID0+IGNvbnNvbGUubG9nKGVycm9yKVxuICAgIClcbiAgfVxuXG4gIG9uRHJhd2VyQnV0dG9uVGFwKCk6IHZvaWQge1xuICAgIGNvbnN0IHNpZGVEcmF3ZXIgPSA8UmFkU2lkZURyYXdlcj5hcHAuZ2V0Um9vdFZpZXcoKTtcbiAgICBzaWRlRHJhd2VyLnNob3dEcmF3ZXIoKTtcbiAgfVxuXG59XG4iXX0=