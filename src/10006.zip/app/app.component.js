"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var router_2 = require("nativescript-angular/router");
var nativescript_ui_sidedrawer_1 = require("nativescript-ui-sidedrawer");
var operators_1 = require("rxjs/operators");
var app = require("tns-core-modules/application");
var ApplicationSettings = require("application-settings");
var firebase = require("nativescript-plugin-firebase");
var bikepoolservice_1 = require("./shared/bikepoolservice");
var Connectivity = require("tns-core-modules/connectivity");
var dialogs_1 = require("tns-core-modules/ui/dialogs");
var AppComponent = /** @class */ (function () {
    function AppComponent(router, routerExtensions, bikepoolservice, zone) {
        this.router = router;
        this.routerExtensions = routerExtensions;
        this.bikepoolservice = bikepoolservice;
        this.zone = zone;
        this.appLoggedIn = false;
        this.email = "";
        // Use the component constructor to inject services.
    }
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._activatedUrl = "/home";
        this._sideDrawerTransition = new nativescript_ui_sidedrawer_1.SlideInOnTopTransition();
        //this.CheckInternetConnection();
        this.router.events
            .pipe(operators_1.filter(function (event) { return event instanceof router_1.NavigationEnd; }))
            .subscribe(function (event) { return _this.ActivateURL(event); });
        this.connectionType = this.connectionToString(Connectivity.getConnectionType());
        Connectivity.startMonitoring(function (connectionType) {
            _this.zone.run(function () {
                _this.connectionType = _this.connectionToString(connectionType);
                //Toast.makeText(this.connectionType,"20000");
                if (_this.connectionType != '') {
                    dialogs_1.alert({
                        title: "On d Vay",
                        message: _this.connectionType,
                        okButtonText: "Ok"
                    });
                }
            });
        });
    };
    AppComponent.prototype.ActivateURL = function (event) {
        this._activatedUrl = event.urlAfterRedirects;
    };
    Object.defineProperty(AppComponent.prototype, "sideDrawerTransition", {
        get: function () {
            return this._sideDrawerTransition;
        },
        enumerable: true,
        configurable: true
    });
    AppComponent.prototype.isComponentSelected = function (url) {
        if (ApplicationSettings.getString("userid") != null) {
            this.profileImage = ApplicationSettings.getString("profileImageURL");
            this.email = ApplicationSettings.getString("email");
            this.username = ApplicationSettings.getString("username");
        }
        return this._activatedUrl === url;
    };
    AppComponent.prototype.onNavItemTap = function (navItemRoute) {
        this.routerExtensions.navigate([navItemRoute], {
            transition: {
                name: "fade"
            }
        });
        this.closeDrawer();
    };
    AppComponent.prototype.LogoutSuccess = function (success) {
        this.closeDrawer();
        this.loggedIn = false;
        this.username = "";
        this.email = "";
        firebase.logout();
        this.routerExtensions.navigate(["signin"], {
            transition: {
                name: "push"
            }
        });
    };
    AppComponent.prototype.LogoutError = function (error) { };
    AppComponent.prototype.Logout = function () {
        this.closeDrawer();
        this.loggedIn = false;
        this.username = "Welcome Guest!";
        this.email = "";
        firebase.logout();
        ApplicationSettings.remove("userid");
        this.router.navigate(["/signin"]);
    };
    AppComponent.prototype.closeDrawer = function () {
        var sideDrawer = app.getRootView();
        sideDrawer.closeDrawer();
    };
    AppComponent.prototype.connectionToString = function (connectionType) {
        switch (connectionType) {
            case Connectivity.connectionType.none:
                return "Please Check Your Internet Connection";
            default:
                return "";
        }
    };
    AppComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "ns-app",
            templateUrl: "app.component.html"
        }),
        __metadata("design:paramtypes", [router_1.Router, router_2.RouterExtensions,
            bikepoolservice_1.BikePoolService, core_1.NgZone])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBcUU7QUFDckUsMENBQXdEO0FBQ3hELHNEQUErRDtBQUMvRCx5RUFBeUc7QUFDekcsNENBQXdDO0FBQ3hDLGtEQUFvRDtBQUNwRCwwREFBNEQ7QUFDNUQsSUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLDhCQUE4QixDQUFDLENBQUM7QUFFekQsNERBQTBEO0FBRTFELDREQUE4RDtBQUU5RCx1REFBNEQ7QUFTNUQ7SUFVSSxzQkFBb0IsTUFBYyxFQUFVLGdCQUFrQyxFQUNsRSxlQUErQixFQUFTLElBQVk7UUFENUMsV0FBTSxHQUFOLE1BQU0sQ0FBUTtRQUFVLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBa0I7UUFDbEUsb0JBQWUsR0FBZixlQUFlLENBQWdCO1FBQVMsU0FBSSxHQUFKLElBQUksQ0FBUTtRQVJ4RCxnQkFBVyxHQUFZLEtBQUssQ0FBQztRQUk3QixVQUFLLEdBQVUsRUFBRSxDQUFDO1FBS3RCLG9EQUFvRDtJQUN4RCxDQUFDO0lBRUQsK0JBQVEsR0FBUjtRQUFBLGlCQXVCQztRQXRCRyxJQUFJLENBQUMsYUFBYSxHQUFHLE9BQU8sQ0FBQztRQUM3QixJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxtREFBc0IsRUFBRSxDQUFDO1FBQzFELGlDQUFpQztRQUNqQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU07YUFDYixJQUFJLENBQUMsa0JBQU0sQ0FBQyxVQUFDLEtBQVUsSUFBSyxPQUFBLEtBQUssWUFBWSxzQkFBYSxFQUE5QixDQUE4QixDQUFDLENBQUM7YUFDNUQsU0FBUyxDQUFDLFVBQUMsS0FBb0IsSUFBSyxPQUFBLEtBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLEVBQXZCLENBQXVCLENBQUMsQ0FBQztRQUVsRSxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxDQUFDO1FBQ2hGLFlBQVksQ0FBQyxlQUFlLENBQUMsVUFBQSxjQUFjO1lBQ3ZDLEtBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO2dCQUNWLEtBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSSxDQUFDLGtCQUFrQixDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUM5RCw4Q0FBOEM7Z0JBQzlDLElBQUcsS0FBSSxDQUFDLGNBQWMsSUFBSSxFQUFFLEVBQzVCO29CQUNJLGVBQUssQ0FBQzt3QkFDRixLQUFLLEVBQUUsVUFBVTt3QkFDakIsT0FBTyxFQUFFLEtBQUksQ0FBQyxjQUFjO3dCQUM1QixZQUFZLEVBQUUsSUFBSTtxQkFDbkIsQ0FBQyxDQUFBO2lCQUNQO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxrQ0FBVyxHQUFYLFVBQVksS0FBbUI7UUFFM0IsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUMsaUJBQWlCLENBQUM7SUFDakQsQ0FBQztJQUVELHNCQUFJLDhDQUFvQjthQUF4QjtZQUNJLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDO1FBQ3RDLENBQUM7OztPQUFBO0lBRUQsMENBQW1CLEdBQW5CLFVBQW9CLEdBQVc7UUFFM0IsSUFBRyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxFQUFDO1lBQy9DLElBQUksQ0FBQyxZQUFZLEdBQUcsbUJBQW1CLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLENBQUM7WUFDckUsSUFBSSxDQUFDLEtBQUssR0FBRyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDcEQsSUFBSSxDQUFDLFFBQVEsR0FBRyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUM7U0FDN0Q7UUFFRCxPQUFPLElBQUksQ0FBQyxhQUFhLEtBQUssR0FBRyxDQUFDO0lBQ3RDLENBQUM7SUFFRCxtQ0FBWSxHQUFaLFVBQWEsWUFBb0I7UUFDN0IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQzNDLFVBQVUsRUFBRTtnQkFDUixJQUFJLEVBQUUsTUFBTTthQUNmO1NBQ0osQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFFRCxvQ0FBYSxHQUFiLFVBQWMsT0FBTztRQUVqQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDdEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7UUFDaEIsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDO1FBQ2xCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRTtZQUN2QyxVQUFVLEVBQUU7Z0JBQ1IsSUFBSSxFQUFFLE1BQU07YUFDZjtTQUNKLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFRCxrQ0FBVyxHQUFYLFVBQVksS0FBSyxJQUFJLENBQUM7SUFFdEIsNkJBQU0sR0FBTjtRQUNJLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNuQixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztRQUN0QixJQUFJLENBQUMsUUFBUSxHQUFHLGdCQUFnQixDQUFDO1FBQ2pDLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBQ2hCLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNsQixtQkFBbUIsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDckMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFRCxrQ0FBVyxHQUFYO1FBQ0ksSUFBTSxVQUFVLEdBQWtCLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNwRCxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDN0IsQ0FBQztJQUVNLHlDQUFrQixHQUF6QixVQUEwQixjQUFzQjtRQUM1QyxRQUFPLGNBQWMsRUFBRTtZQUNuQixLQUFLLFlBQVksQ0FBQyxjQUFjLENBQUMsSUFBSTtnQkFDakMsT0FBTyx1Q0FBdUMsQ0FBQztZQUNuRDtnQkFDSyxPQUFPLEVBQUUsQ0FBQztTQUNsQjtJQUNMLENBQUM7SUEzR1EsWUFBWTtRQUx4QixnQkFBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFFBQVEsRUFBRSxRQUFRO1lBQ2xCLFdBQVcsRUFBRSxvQkFBb0I7U0FDcEMsQ0FBQzt5Q0FXOEIsZUFBTSxFQUE0Qix5QkFBZ0I7WUFDbEQsaUNBQWUsRUFBZSxhQUFNO09BWHZELFlBQVksQ0E0R3hCO0lBQUQsbUJBQUM7Q0FBQSxBQTVHRCxJQTRHQztBQTVHWSxvQ0FBWSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBWaWV3Q2hpbGQsTmdab25lICB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBOYXZpZ2F0aW9uRW5kLCBSb3V0ZXIgfSBmcm9tIFwiQGFuZ3VsYXIvcm91dGVyXCI7XG5pbXBvcnQgeyBSb3V0ZXJFeHRlbnNpb25zIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgRHJhd2VyVHJhbnNpdGlvbkJhc2UsIFJhZFNpZGVEcmF3ZXIsIFNsaWRlSW5PblRvcFRyYW5zaXRpb24gfSBmcm9tIFwibmF0aXZlc2NyaXB0LXVpLXNpZGVkcmF3ZXJcIjtcbmltcG9ydCB7IGZpbHRlciB9IGZyb20gXCJyeGpzL29wZXJhdG9yc1wiO1xuaW1wb3J0ICogYXMgYXBwIGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL2FwcGxpY2F0aW9uXCI7XG5pbXBvcnQgKiBhcyBBcHBsaWNhdGlvblNldHRpbmdzIGZyb20gXCJhcHBsaWNhdGlvbi1zZXR0aW5nc1wiO1xuY29uc3QgZmlyZWJhc2UgPSByZXF1aXJlKFwibmF0aXZlc2NyaXB0LXBsdWdpbi1maXJlYmFzZVwiKTtcbmltcG9ydCB7IGNvbm5lY3Rpb25UeXBlLCBnZXRDb25uZWN0aW9uVHlwZSwgc3RhcnRNb25pdG9yaW5nLCBzdG9wTW9uaXRvcmluZyB9ZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvY29ubmVjdGl2aXR5XCI7XG5pbXBvcnQgeyBCaWtlUG9vbFNlcnZpY2V9IGZyb20gXCIuL3NoYXJlZC9iaWtlcG9vbHNlcnZpY2VcIjtcbmltcG9ydCB7IFNlcnZpY2VVUkwgfSBmcm9tIFwiLi9zaGFyZWQvc2VydmljZXNcIjtcbmltcG9ydCAqIGFzIENvbm5lY3Rpdml0eSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9jb25uZWN0aXZpdHlcIjtcbmltcG9ydCAqIGFzIFRvYXN0IGZyb20gXCJuYXRpdmVzY3JpcHQtdG9hc3RcIjtcbmltcG9ydCB7IGFsZXJ0LCBwcm9tcHQgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy91aS9kaWFsb2dzXCI7XG5pbXBvcnQgeyBSYWRTaWRlRHJhd2VyQ29tcG9uZW50IH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC11aS1zaWRlZHJhd2VyL2FuZ3VsYXJcIjtcblxuXG5AQ29tcG9uZW50KHtcbiAgICBtb2R1bGVJZDogbW9kdWxlLmlkLFxuICAgIHNlbGVjdG9yOiBcIm5zLWFwcFwiLFxuICAgIHRlbXBsYXRlVXJsOiBcImFwcC5jb21wb25lbnQuaHRtbFwiXG59KVxuZXhwb3J0IGNsYXNzIEFwcENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgcHJpdmF0ZSBfYWN0aXZhdGVkVXJsOiBzdHJpbmc7XG4gICAgcHJpdmF0ZSBfc2lkZURyYXdlclRyYW5zaXRpb246IERyYXdlclRyYW5zaXRpb25CYXNlO1xuICAgIHByaXZhdGUgYXBwTG9nZ2VkSW46IGJvb2xlYW4gPSBmYWxzZTtcbiAgICBwdWJsaWMgY29ubmVjdGlvblR5cGU6IHN0cmluZztcbiAgICBwcml2YXRlIHByb2ZpbGVJbWFnZSA6IGFueTtcbiAgICBwcml2YXRlIHVzZXJuYW1lIDogc3RyaW5nO1xuICAgIHByaXZhdGUgZW1haWwgOiBzdHJpbmc9XCJcIjtcbiAgICBwcml2YXRlIGxvZ2dlZEluIDogYm9vbGVhbjtcbiAgICBcbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJvdXRlcjogUm91dGVyLCBwcml2YXRlIHJvdXRlckV4dGVuc2lvbnM6IFJvdXRlckV4dGVuc2lvbnMsXG4gICAgICAgIHByaXZhdGUgYmlrZXBvb2xzZXJ2aWNlOkJpa2VQb29sU2VydmljZSxwcml2YXRlIHpvbmU6IE5nWm9uZSkge1xuICAgICAgICAvLyBVc2UgdGhlIGNvbXBvbmVudCBjb25zdHJ1Y3RvciB0byBpbmplY3Qgc2VydmljZXMuXG4gICAgfVxuXG4gICAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgICAgIHRoaXMuX2FjdGl2YXRlZFVybCA9IFwiL2hvbWVcIjtcbiAgICAgICAgdGhpcy5fc2lkZURyYXdlclRyYW5zaXRpb24gPSBuZXcgU2xpZGVJbk9uVG9wVHJhbnNpdGlvbigpO1xuICAgICAgICAvL3RoaXMuQ2hlY2tJbnRlcm5ldENvbm5lY3Rpb24oKTtcbiAgICAgICAgdGhpcy5yb3V0ZXIuZXZlbnRzXG4gICAgICAgICAgICAucGlwZShmaWx0ZXIoKGV2ZW50OiBhbnkpID0+IGV2ZW50IGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCkpXG4gICAgICAgICAgICAuc3Vic2NyaWJlKChldmVudDogTmF2aWdhdGlvbkVuZCkgPT4gdGhpcy5BY3RpdmF0ZVVSTChldmVudCkpO1xuXG4gICAgICAgIHRoaXMuY29ubmVjdGlvblR5cGUgPSB0aGlzLmNvbm5lY3Rpb25Ub1N0cmluZyhDb25uZWN0aXZpdHkuZ2V0Q29ubmVjdGlvblR5cGUoKSk7XG4gICAgICAgIENvbm5lY3Rpdml0eS5zdGFydE1vbml0b3JpbmcoY29ubmVjdGlvblR5cGUgPT4ge1xuICAgICAgICAgICAgdGhpcy56b25lLnJ1bigoKSA9PiB7XG4gICAgICAgICAgICAgICAgdGhpcy5jb25uZWN0aW9uVHlwZSA9IHRoaXMuY29ubmVjdGlvblRvU3RyaW5nKGNvbm5lY3Rpb25UeXBlKTtcbiAgICAgICAgICAgICAgICAvL1RvYXN0Lm1ha2VUZXh0KHRoaXMuY29ubmVjdGlvblR5cGUsXCIyMDAwMFwiKTtcbiAgICAgICAgICAgICAgICBpZih0aGlzLmNvbm5lY3Rpb25UeXBlICE9ICcnKVxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgYWxlcnQoe1xuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiT24gZCBWYXlcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IHRoaXMuY29ubmVjdGlvblR5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgICBva0J1dHRvblRleHQ6IFwiT2tcIlxuICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBcbiAgICBBY3RpdmF0ZVVSTChldmVudDpOYXZpZ2F0aW9uRW5kKVxuICAgIHtcbiAgICAgICAgdGhpcy5fYWN0aXZhdGVkVXJsID0gZXZlbnQudXJsQWZ0ZXJSZWRpcmVjdHM7ICAgICAgICBcbiAgICB9XG5cbiAgICBnZXQgc2lkZURyYXdlclRyYW5zaXRpb24oKTogRHJhd2VyVHJhbnNpdGlvbkJhc2Uge1xuICAgICAgICByZXR1cm4gdGhpcy5fc2lkZURyYXdlclRyYW5zaXRpb247XG4gICAgfVxuXG4gICAgaXNDb21wb25lbnRTZWxlY3RlZCh1cmw6IHN0cmluZyk6IGJvb2xlYW4ge1xuXG4gICAgICAgIGlmKEFwcGxpY2F0aW9uU2V0dGluZ3MuZ2V0U3RyaW5nKFwidXNlcmlkXCIpICE9IG51bGwpe1xuICAgICAgICAgICAgdGhpcy5wcm9maWxlSW1hZ2UgPSBBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcInByb2ZpbGVJbWFnZVVSTFwiKTtcbiAgICAgICAgICAgIHRoaXMuZW1haWwgPSBBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcImVtYWlsXCIpO1xuICAgICAgICAgICAgdGhpcy51c2VybmFtZSA9IEFwcGxpY2F0aW9uU2V0dGluZ3MuZ2V0U3RyaW5nKFwidXNlcm5hbWVcIik7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gdGhpcy5fYWN0aXZhdGVkVXJsID09PSB1cmw7XG4gICAgfVxuXG4gICAgb25OYXZJdGVtVGFwKG5hdkl0ZW1Sb3V0ZTogc3RyaW5nKTogdm9pZCB7XG4gICAgICAgIHRoaXMucm91dGVyRXh0ZW5zaW9ucy5uYXZpZ2F0ZShbbmF2SXRlbVJvdXRlXSwge1xuICAgICAgICAgICAgdHJhbnNpdGlvbjoge1xuICAgICAgICAgICAgICAgIG5hbWU6IFwiZmFkZVwiXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLmNsb3NlRHJhd2VyKCk7XG4gICAgfVxuXG4gICAgTG9nb3V0U3VjY2VzcyhzdWNjZXNzKVxuICAgIHtcbiAgICAgICAgdGhpcy5jbG9zZURyYXdlcigpO1xuICAgICAgICB0aGlzLmxvZ2dlZEluID0gZmFsc2U7XG4gICAgICAgIHRoaXMudXNlcm5hbWUgPSBcIlwiO1xuICAgICAgICB0aGlzLmVtYWlsID0gXCJcIjsgICAgICAgIFxuICAgICAgICBmaXJlYmFzZS5sb2dvdXQoKTtcbiAgICAgICAgdGhpcy5yb3V0ZXJFeHRlbnNpb25zLm5hdmlnYXRlKFtcInNpZ25pblwiXSwge1xuICAgICAgICAgICAgdHJhbnNpdGlvbjoge1xuICAgICAgICAgICAgICAgIG5hbWU6IFwicHVzaFwiXG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIExvZ291dEVycm9yKGVycm9yKSB7IH1cblxuICAgIExvZ291dCgpIHtcbiAgICAgICAgdGhpcy5jbG9zZURyYXdlcigpO1xuICAgICAgICB0aGlzLmxvZ2dlZEluID0gZmFsc2U7XG4gICAgICAgIHRoaXMudXNlcm5hbWUgPSBcIldlbGNvbWUgR3Vlc3QhXCI7XG4gICAgICAgIHRoaXMuZW1haWwgPSBcIlwiOyAgICAgICAgXG4gICAgICAgIGZpcmViYXNlLmxvZ291dCgpO1xuICAgICAgICBBcHBsaWNhdGlvblNldHRpbmdzLnJlbW92ZShcInVzZXJpZFwiKTtcbiAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoW1wiL3NpZ25pblwiXSk7ICAgICAgICBcbiAgICB9XG5cbiAgICBjbG9zZURyYXdlcigpe1xuICAgICAgICBjb25zdCBzaWRlRHJhd2VyID0gPFJhZFNpZGVEcmF3ZXI+YXBwLmdldFJvb3RWaWV3KCk7XG4gICAgICAgIHNpZGVEcmF3ZXIuY2xvc2VEcmF3ZXIoKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgY29ubmVjdGlvblRvU3RyaW5nKGNvbm5lY3Rpb25UeXBlOiBudW1iZXIpOiBzdHJpbmcge1xuICAgICAgICBzd2l0Y2goY29ubmVjdGlvblR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgQ29ubmVjdGl2aXR5LmNvbm5lY3Rpb25UeXBlLm5vbmU6XG4gICAgICAgICAgICAgICAgcmV0dXJuIFwiUGxlYXNlIENoZWNrIFlvdXIgSW50ZXJuZXQgQ29ubmVjdGlvblwiOyAgICAgICAgICAgIFxuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgcmV0dXJuIFwiXCI7XG4gICAgICAgIH1cbiAgICB9XG59XG4iXX0=