"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var dialogs_1 = require("tns-core-modules/ui/dialogs");
var app = require("tns-core-modules/application");
var ApplicationSettings = require("application-settings");
var firebase = require("nativescript-plugin-firebase");
var router_1 = require("nativescript-angular/router");
var router_2 = require("@angular/router");
var bikepoolservice_1 = require("../shared/bikepoolservice");
var services_1 = require("../shared/services");
//import { Loader  } from "../shared/loader";
var nativescript_loading_screen_1 = require("nativescript-loading-screen");
var User = /** @class */ (function () {
    function User() {
    }
    return User;
}());
exports.User = User;
var SigninComponent = /** @class */ (function () {
    function SigninComponent(routerExtensions, router, bikepoolservice) {
        this.routerExtensions = routerExtensions;
        this.router = router;
        this.bikepoolservice = bikepoolservice;
        this.isLoggingIn = false;
        this.isAuthenticating = false;
        this.selectedIndex = 1;
        this.loadingScreen = new nativescript_loading_screen_1.LoadingScreen();
        this.isLoggingIn = false;
    }
    SigninComponent.prototype.ngOnInit = function () {
        this.user = new User();
        console.log(ApplicationSettings.getString("userid"));
        if (ApplicationSettings.getString("userid") != null) {
            this.router.navigate(['/home']);
        }
    };
    SigninComponent.prototype.GetUser = function () {
        var _this = this;
        var objUser = { userId: ApplicationSettings.getString("userid") };
        this.bikepoolservice.PostService(services_1.ServiceURL.GetUser, objUser).subscribe(function (user) { return _this.userSuccess(user); }, function (error) { return _this.userError(error); });
    };
    SigninComponent.prototype.userSuccess = function (success) { this.hideLoader(); };
    SigninComponent.prototype.userError = function (error) { this.hideLoader(); };
    SigninComponent.prototype.toggleForm = function () {
        this.clickSignInButton = !this.clickSignInButton;
        this.isLoggingIn = !this.isLoggingIn;
    };
    SigninComponent.prototype.signUpSuccess = function (success) {
        this.hideLoader();
        this.isLoggingIn = true;
    };
    SigninComponent.prototype.signUpError = function (error) {
        this.hideLoader();
    };
    SigninComponent.prototype.loginSuccess = function (success) {
        this.hideLoader();
        var user = success.data.user;
        ApplicationSettings.setString("email", user.email);
        ApplicationSettings.setString("userid", user.uid);
        if (user.name != undefined) {
            ApplicationSettings.setString("username", user.name);
        }
        else {
            ApplicationSettings.remove("username");
        }
        if (user.profileImageURL != undefined) {
            ApplicationSettings.setString("profileImageURL", user.profileImageURL);
        }
        else {
            ApplicationSettings.remove("profileImageURL");
        }
        this.navigateHome();
    };
    SigninComponent.prototype.loginError = function (error) {
        this.isAuthenticating = false;
        this.hideLoader();
        console.log(error);
        dialogs_1.alert({
            title: "On d Vay",
            message: "Please enter correct username/password",
            okButtonText: "Ok"
        });
    };
    SigninComponent.prototype.submit = function () {
        var _this = this;
        this.showLoader();
        // Normal Signup on d vay    
        if (this.isLoggingIn == false) {
            if (this.user.username != undefined && this.user.password != undefined &&
                this.user.email != undefined &&
                this.user.username != '' && this.user.password != '' &&
                this.user.email != '') {
                this.isAuthenticating = true;
                this.isLoggingIn = true;
                this.busy = true;
                var objLogin_1 = {
                    username: this.user.username,
                    email: this.user.email,
                    password: this.user.password,
                    deviceToken: ApplicationSettings.getString("device_token")
                };
                this.bikepoolservice.PostService(services_1.ServiceURL.SignUpOnDVay, objLogin_1).subscribe(function (success) { return _this.signUpSuccess(success); }, function (error) { return _this.signUpError(error); });
            }
            else {
                dialogs_1.alert({
                    title: "On d Vay",
                    message: "Please Enter valid Information to SignUp",
                    okButtonText: "Ok"
                });
            }
        }
        else if (this.user.email != '' && this.user.password != '') {
            this.isAuthenticating = true;
            // normal login on d vay
            if (this.user.email != undefined && this.user.password != undefined
                && this.user.password != '' && this.user.email != '') {
                var objLogin = { email: this.user.email, password: this.user.password };
                this.bikepoolservice.PostService(services_1.ServiceURL.Login, objLogin).subscribe(function (success) { return _this.loginSuccess(success); }, function (error) { return _this.loginError(error); });
            }
            else {
                dialogs_1.alert({
                    title: "On d Vay",
                    message: "Please Enter valid Information to LogIn",
                    okButtonText: "Ok"
                });
            }
        }
    };
    SigninComponent.prototype.hideLoader = function () {
        this.loadingScreen.close();
    };
    SigninComponent.prototype.showLoader = function () {
        this.loadingScreen.show({ message: "Loading..." });
    };
    SigninComponent.prototype.onDrawerButtonTap = function () {
        var sideDrawer = app.getRootView();
        sideDrawer.showDrawer();
    };
    SigninComponent.prototype.googleresult = function (result) {
        var _this = this;
        this.isLoggingIn = true;
        this.showLoader();
        ApplicationSettings.setString("profileImage", result.profileImageURL);
        ApplicationSettings.setString("email", result.email);
        ApplicationSettings.setString("username", result.name);
        var objGoogleLogin = {
            userid: result.uid,
            deviceToken: ApplicationSettings.getString("device_token"),
            username: result.name,
            email: result.email,
            profilePhoto: result.profileImageURL
        };
        this.bikepoolservice.PostService(services_1.ServiceURL.CreateWithSocialLogin, objGoogleLogin).subscribe(function (user) { return _this.createusersuccess(user); }, function (error) { return _this.createusererror(error); });
    };
    SigninComponent.prototype.createusersuccess = function (user) {
        this.hideLoader();
        this.navigateHome();
    };
    SigninComponent.prototype.createusererror = function (error) {
        this.hideLoader();
        dialogs_1.alert({
            title: "On d Vay",
            message: error,
            okButtonText: "Ok"
        });
    };
    SigninComponent.prototype.googleerror = function (error) {
        console.log(error);
    };
    SigninComponent.prototype.submitGoogle = function () {
        var _this = this;
        firebase.login({ type: firebase.LoginType.GOOGLE }).
            then(function (googleresult) { return _this.googleresult(googleresult); }, function (googleerror) { return _this.googleerror(googleerror); });
    };
    SigninComponent.prototype.fbresult = function (success) {
        var _this = this;
        this.isLoggingIn = true;
        ApplicationSettings.setString("profileImage", success.profileImageURL);
        ApplicationSettings.setString("email", success.email);
        ApplicationSettings.setString("username", success.name);
        var objFBLogin = {
            userid: success.uid,
            deviceToken: ApplicationSettings.getString("device_token"),
            username: success.name,
            email: success.email,
            profilePhoto: success.profileImageURL
        };
        this.bikepoolservice.PostService(services_1.ServiceURL.CreateWithSocialLogin, objFBLogin).subscribe(function (user) { return _this.createusersuccess(user); }, function (error) { return _this.createusererror(error); });
    };
    SigninComponent.prototype.fberror = function (error) {
        var formatErrorMessage = error.replace('com.google.firebase.auth.FirebaseAuthUserCollisionException:', "");
        dialogs_1.alert({
            title: "On d Vay",
            message: formatErrorMessage,
            okButtonText: "Ok"
        });
    };
    SigninComponent.prototype.submitFB = function () {
        var _this = this;
        firebase.login({
            type: firebase.LoginType.FACEBOOK,
            facebookOptions: {
                scope: ['public_profile', 'email']
            }
        })
            .then(function (success) { return _this.fbresult(success); }, function (error) { return _this.fberror(error); });
    };
    SigninComponent.prototype.onchange = function (args) {
        console.log("Drop Down selected index changed from " + args.oldIndex + " to " + args.newIndex);
    };
    SigninComponent.prototype.onopen = function () { };
    SigninComponent.prototype.onclose = function () { };
    SigninComponent.prototype.navigateHome = function () {
        this.routerExtensions.navigate(["/home"], {
            transition: {
                name: "fade"
            }
        });
    };
    SigninComponent.prototype.successForgotPwd = function (success) {
        dialogs_1.alert({
            title: "On d Vay",
            message: "Your password was successfully reset. Please check your email for instructions on choosing a new password.",
            okButtonText: "Ok"
        });
    };
    SigninComponent.prototype.errorForgotPwd = function (error) {
        console.log(error);
    };
    SigninComponent.prototype.forgotPassword = function () {
        var _this = this;
        dialogs_1.prompt({
            title: "Forgot Password",
            message: "Enter the email address you used to register for On d Vay to reset your password.",
            defaultText: "",
            okButtonText: "Ok",
            cancelButtonText: "Cancel"
        }).then(function (data) {
            if (data.result) {
                // Call the backend to reset the password
                var objemail = { emailAddress: data.text.toString().trim() };
                _this.bikepoolservice.PostService(services_1.ServiceURL.ResetPassword, objemail).subscribe(function (success) { return _this.successForgotPwd(success); }, function (error) { return _this.errorForgotPwd(error); });
            }
        });
    };
    SigninComponent = __decorate([
        core_1.Component({
            selector: 'SignIn',
            templateUrl: './signin.component.html',
            styleUrls: ['./signin.component.css'],
            moduleId: module.id
        }),
        __metadata("design:paramtypes", [router_1.RouterExtensions,
            router_2.Router,
            bikepoolservice_1.BikePoolService])
    ], SigninComponent);
    return SigninComponent;
}());
exports.SigninComponent = SigninComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2lnbmluLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInNpZ25pbi5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBc0c7QUFDdEcsdURBQTREO0FBSTVELGtEQUFvRDtBQUNwRCwwREFBNEQ7QUFDNUQsSUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLDhCQUE4QixDQUFDLENBQUM7QUFDekQsc0RBQStEO0FBQy9ELDBDQUF3RDtBQUN4RCw2REFBMkQ7QUFDM0QsK0NBQStDO0FBQy9DLDZDQUE2QztBQUM3QywyRUFBNEQ7QUFFNUQ7SUFBQTtJQU1BLENBQUM7SUFBRCxXQUFDO0FBQUQsQ0FBQyxBQU5ELElBTUM7QUFOWSxvQkFBSTtBQWNqQjtJQWNFLHlCQUFvQixnQkFBa0MsRUFDNUMsTUFBYyxFQUNkLGVBQWdDO1FBRnRCLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBa0I7UUFDNUMsV0FBTSxHQUFOLE1BQU0sQ0FBUTtRQUNkLG9CQUFlLEdBQWYsZUFBZSxDQUFpQjtRQVgxQyxnQkFBVyxHQUFHLEtBQUssQ0FBQztRQUNwQixxQkFBZ0IsR0FBRyxLQUFLLENBQUM7UUFFbEIsa0JBQWEsR0FBRyxDQUFDLENBQUM7UUFTckIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLDJDQUFhLEVBQUUsQ0FBQztRQUN6QyxJQUFJLENBQUMsV0FBVyxHQUFFLEtBQUssQ0FBQztJQUM1QixDQUFDO0lBRUQsa0NBQVEsR0FBUjtRQUNFLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUN2QixPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQ3JELElBQUcsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksRUFBQztZQUNqRCxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7U0FDakM7SUFDSCxDQUFDO0lBRUQsaUNBQU8sR0FBUDtRQUFBLGlCQU1DO1FBTEMsSUFBSSxPQUFPLEdBQUcsRUFBQyxNQUFNLEVBQUcsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxFQUFDLENBQUM7UUFDakUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxPQUFPLEVBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUNwRSxVQUFBLElBQUksSUFBSSxPQUFBLEtBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQXRCLENBQXNCLEVBQzlCLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBckIsQ0FBcUIsQ0FDL0IsQ0FBQTtJQUNILENBQUM7SUFFRCxxQ0FBVyxHQUFYLFVBQVksT0FBTyxJQUFLLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFFNUMsbUNBQVMsR0FBVCxVQUFVLEtBQUssSUFBRyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBRSxDQUFDO0lBRXZDLG9DQUFVLEdBQVY7UUFDRSxJQUFJLENBQUMsaUJBQWlCLEdBQUcsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7UUFDakQsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7SUFDdkMsQ0FBQztJQUVELHVDQUFhLEdBQWIsVUFBYyxPQUFPO1FBQ25CLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztJQUMxQixDQUFDO0lBRUQscUNBQVcsR0FBWCxVQUFZLEtBQUs7UUFDZixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVELHNDQUFZLEdBQVosVUFBYSxPQUFPO1FBQ2xCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLElBQUksR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUM3QixtQkFBbUIsQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNuRCxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNsRCxJQUFHLElBQUksQ0FBQyxJQUFJLElBQUksU0FBUyxFQUFDO1lBQ3hCLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1NBQ3JEO2FBQ0c7WUFDRixtQkFBbUIsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7U0FDeEM7UUFFRCxJQUFHLElBQUksQ0FBQyxlQUFlLElBQUksU0FBUyxFQUFDO1lBQ25DLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsRUFBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7U0FDdkU7YUFDRztZQUNGLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1NBQy9DO1FBRUQsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ3RCLENBQUM7SUFFRCxvQ0FBVSxHQUFWLFVBQVcsS0FBSztRQUNkLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7UUFDOUIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2xCLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbkIsZUFBSyxDQUFDO1lBQ0osS0FBSyxFQUFFLFVBQVU7WUFDakIsT0FBTyxFQUFFLHdDQUF3QztZQUNqRCxZQUFZLEVBQUUsSUFBSTtTQUNuQixDQUFDLENBQUE7SUFDSixDQUFDO0lBSUQsZ0NBQU0sR0FBTjtRQUFBLGlCQWtEQztRQWpEQyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsNkJBQTZCO1FBQzdCLElBQUksSUFBSSxDQUFDLFdBQVcsSUFBSSxLQUFLLEVBQUU7WUFDN0IsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksU0FBUztnQkFDcEUsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksU0FBUztnQkFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLEVBQUU7Z0JBQ3JELElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLEVBQUUsRUFBRTtnQkFDdkIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztnQkFDN0IsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7Z0JBQ3hCLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO2dCQUNqQixJQUFJLFVBQVEsR0FBRztvQkFDYixRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRO29CQUM1QixLQUFLLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLO29CQUN0QixRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRO29CQUM1QixXQUFXLEVBQUUsbUJBQW1CLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQztpQkFDM0QsQ0FBQTtnQkFDRCxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxxQkFBVSxDQUFDLFlBQVksRUFBRSxVQUFRLENBQUMsQ0FBQyxTQUFTLENBQzNFLFVBQUEsT0FBTyxJQUFJLE9BQUEsS0FBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsRUFBM0IsQ0FBMkIsRUFDdEMsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUF2QixDQUF1QixDQUNqQyxDQUFBO2FBQ0Y7aUJBQ0c7Z0JBQ0YsZUFBSyxDQUFDO29CQUNKLEtBQUssRUFBRSxVQUFVO29CQUNqQixPQUFPLEVBQUUsMENBQTBDO29CQUNuRCxZQUFZLEVBQUUsSUFBSTtpQkFDbkIsQ0FBQyxDQUFBO2FBQ0g7U0FDRjthQUNJLElBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFJLEVBQUUsRUFBRTtZQUN6RCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO1lBQzdCLHdCQUF3QjtZQUN4QixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBSSxTQUFTO21CQUM5RCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLElBQUksRUFBRSxFQUFFO2dCQUN0RCxJQUFJLFFBQVEsR0FBRyxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDeEUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUNwRSxVQUFBLE9BQU8sSUFBSSxPQUFBLEtBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEVBQTFCLENBQTBCLEVBQ3JDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsRUFBdEIsQ0FBc0IsQ0FDaEMsQ0FBQTthQUNGO2lCQUVEO2dCQUNFLGVBQUssQ0FBQztvQkFDSixLQUFLLEVBQUUsVUFBVTtvQkFDakIsT0FBTyxFQUFFLHlDQUF5QztvQkFDbEQsWUFBWSxFQUFFLElBQUk7aUJBQ25CLENBQUMsQ0FBQTthQUNIO1NBQ0Y7SUFDSCxDQUFDO0lBRUQsb0NBQVUsR0FBVjtRQUNFLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLENBQUM7SUFDN0IsQ0FBQztJQUVELG9DQUFVLEdBQVY7UUFDRSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUMsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRCwyQ0FBaUIsR0FBakI7UUFDRSxJQUFNLFVBQVUsR0FBa0IsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3BELFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsc0NBQVksR0FBWixVQUFhLE1BQU07UUFBbkIsaUJBbUJDO1FBbEJDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixtQkFBbUIsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUN0RSxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNyRCxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV2RCxJQUFJLGNBQWMsR0FBRztZQUNuQixNQUFNLEVBQUUsTUFBTSxDQUFDLEdBQUc7WUFDbEIsV0FBVyxFQUFFLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUM7WUFDMUQsUUFBUSxFQUFFLE1BQU0sQ0FBQyxJQUFJO1lBQ3JCLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSztZQUNuQixZQUFZLEVBQUUsTUFBTSxDQUFDLGVBQWU7U0FDckMsQ0FBQTtRQUVELElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLHFCQUFVLENBQUMscUJBQXFCLEVBQUUsY0FBYyxDQUFDLENBQUMsU0FBUyxDQUMxRixVQUFBLElBQUksSUFBSSxPQUFBLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsRUFBNUIsQ0FBNEIsRUFDcEMsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxFQUEzQixDQUEyQixDQUNyQyxDQUFBO0lBQ0gsQ0FBQztJQUVELDJDQUFpQixHQUFqQixVQUFrQixJQUFJO1FBQ3BCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVELHlDQUFlLEdBQWYsVUFBZ0IsS0FBSztRQUNuQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsZUFBSyxDQUFDO1lBQ0osS0FBSyxFQUFFLFVBQVU7WUFDakIsT0FBTyxFQUFFLEtBQUs7WUFDZCxZQUFZLEVBQUUsSUFBSTtTQUNuQixDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQscUNBQVcsR0FBWCxVQUFZLEtBQUs7UUFDZixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3JCLENBQUM7SUFFRCxzQ0FBWSxHQUFaO1FBQUEsaUJBSUM7UUFIQyxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDakQsSUFBSSxDQUFDLFVBQUEsWUFBWSxJQUFJLE9BQUEsS0FBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsRUFBL0IsQ0FBK0IsRUFDcEQsVUFBQSxXQUFXLElBQUksT0FBQSxLQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxFQUE3QixDQUE2QixDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUVELGtDQUFRLEdBQVIsVUFBUyxPQUFPO1FBQWhCLGlCQW1CQztRQWxCQyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztRQUV4QixtQkFBbUIsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLE9BQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUN2RSxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN0RCxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV4RCxJQUFJLFVBQVUsR0FBRztZQUNmLE1BQU0sRUFBRSxPQUFPLENBQUMsR0FBRztZQUNuQixXQUFXLEVBQUUsbUJBQW1CLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQztZQUMxRCxRQUFRLEVBQUUsT0FBTyxDQUFDLElBQUk7WUFDdEIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLO1lBQ3BCLFlBQVksRUFBRSxPQUFPLENBQUMsZUFBZTtTQUN0QyxDQUFBO1FBRUQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxxQkFBcUIsRUFBRSxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQ3RGLFVBQUEsSUFBSSxJQUFJLE9BQUEsS0FBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxFQUE1QixDQUE0QixFQUNwQyxVQUFBLEtBQUssSUFBSSxPQUFBLEtBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLEVBQTNCLENBQTJCLENBQ3JDLENBQUE7SUFDSCxDQUFDO0lBRUQsaUNBQU8sR0FBUCxVQUFRLEtBQUs7UUFDWCxJQUFJLGtCQUFrQixHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsOERBQThELEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDM0csZUFBSyxDQUFDO1lBQ0osS0FBSyxFQUFFLFVBQVU7WUFDakIsT0FBTyxFQUFFLGtCQUFrQjtZQUMzQixZQUFZLEVBQUUsSUFBSTtTQUNuQixDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsa0NBQVEsR0FBUjtRQUFBLGlCQVdDO1FBVkMsUUFBUSxDQUFDLEtBQUssQ0FBQztZQUNiLElBQUksRUFBRSxRQUFRLENBQUMsU0FBUyxDQUFDLFFBQVE7WUFDakMsZUFBZSxFQUFFO2dCQUNmLEtBQUssRUFBRSxDQUFDLGdCQUFnQixFQUFFLE9BQU8sQ0FBQzthQUNuQztTQUNGLENBQUM7YUFDQyxJQUFJLENBQ0wsVUFBQSxPQUFPLElBQUksT0FBQSxLQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUF0QixDQUFzQixFQUNqQyxVQUFBLEtBQUssSUFBSSxPQUFBLEtBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQW5CLENBQW1CLENBQzNCLENBQUE7SUFDTCxDQUFDO0lBRU0sa0NBQVEsR0FBZixVQUFnQixJQUFtQztRQUNqRCxPQUFPLENBQUMsR0FBRyxDQUFDLDJDQUF5QyxJQUFJLENBQUMsUUFBUSxZQUFPLElBQUksQ0FBQyxRQUFVLENBQUMsQ0FBQztJQUM1RixDQUFDO0lBRU0sZ0NBQU0sR0FBYixjQUFtQixDQUFDO0lBRWIsaUNBQU8sR0FBZCxjQUFvQixDQUFDO0lBRXJCLHNDQUFZLEdBQVo7UUFDRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDeEMsVUFBVSxFQUFFO2dCQUNWLElBQUksRUFBRSxNQUFNO2FBQ2I7U0FDRixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsMENBQWdCLEdBQWhCLFVBQWlCLE9BQU87UUFDdEIsZUFBSyxDQUFDO1lBQ0osS0FBSyxFQUFFLFVBQVU7WUFDakIsT0FBTyxFQUFFLDRHQUE0RztZQUNySCxZQUFZLEVBQUUsSUFBSTtTQUNuQixDQUFDLENBQUE7SUFDSixDQUFDO0lBRUQsd0NBQWMsR0FBZCxVQUFlLEtBQUs7UUFDbEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNyQixDQUFDO0lBRUQsd0NBQWMsR0FBZDtRQUFBLGlCQWlCQztRQWhCQyxnQkFBTSxDQUFDO1lBQ0wsS0FBSyxFQUFFLGlCQUFpQjtZQUN4QixPQUFPLEVBQUUsbUZBQW1GO1lBQzVGLFdBQVcsRUFBRSxFQUFFO1lBQ2YsWUFBWSxFQUFFLElBQUk7WUFDbEIsZ0JBQWdCLEVBQUUsUUFBUTtTQUMzQixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsSUFBSTtZQUNYLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDZix5Q0FBeUM7Z0JBQ3pDLElBQUksUUFBUSxHQUFHLEVBQUUsWUFBWSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQTtnQkFDNUQsS0FBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUM1RSxVQUFBLE9BQU8sSUFBSSxPQUFBLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsRUFBOUIsQ0FBOEIsRUFDekMsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUExQixDQUEwQixDQUNwQyxDQUFBO2FBQ0Y7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFoU1UsZUFBZTtRQU4zQixnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLFFBQVE7WUFDbEIsV0FBVyxFQUFFLHlCQUF5QjtZQUN0QyxTQUFTLEVBQUUsQ0FBQyx3QkFBd0IsQ0FBQztZQUNyQyxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7U0FDcEIsQ0FBQzt5Q0Flc0MseUJBQWdCO1lBQ3BDLGVBQU07WUFDRyxpQ0FBZTtPQWhCL0IsZUFBZSxDQWlTM0I7SUFBRCxzQkFBQztDQUFBLEFBalNELElBaVNDO0FBalNZLDBDQUFlIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIEluamVjdGFibGUsIFZpZXdDaGlsZCwgTmdab25lLCBEb0NoZWNrLCBFbGVtZW50UmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XHJcbmltcG9ydCB7IGFsZXJ0LCBwcm9tcHQgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy91aS9kaWFsb2dzXCI7XHJcbmltcG9ydCB7IFJhZFNpZGVEcmF3ZXIgfSBmcm9tIFwibmF0aXZlc2NyaXB0LXVpLXNpZGVkcmF3ZXJcIjtcclxuXHJcbmltcG9ydCB7IFNlbGVjdGVkSW5kZXhDaGFuZ2VkRXZlbnREYXRhIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1kcm9wLWRvd25cIjtcclxuaW1wb3J0ICogYXMgYXBwIGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL2FwcGxpY2F0aW9uXCI7XHJcbmltcG9ydCAqIGFzIEFwcGxpY2F0aW9uU2V0dGluZ3MgZnJvbSBcImFwcGxpY2F0aW9uLXNldHRpbmdzXCI7XHJcbmNvbnN0IGZpcmViYXNlID0gcmVxdWlyZShcIm5hdGl2ZXNjcmlwdC1wbHVnaW4tZmlyZWJhc2VcIik7XHJcbmltcG9ydCB7IFJvdXRlckV4dGVuc2lvbnMgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvcm91dGVyXCI7XHJcbmltcG9ydCB7IE5hdmlnYXRpb25FbmQsIFJvdXRlciB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcclxuaW1wb3J0IHsgQmlrZVBvb2xTZXJ2aWNlIH0gZnJvbSBcIi4uL3NoYXJlZC9iaWtlcG9vbHNlcnZpY2VcIlxyXG5pbXBvcnQgeyBTZXJ2aWNlVVJMIH0gZnJvbSBcIi4uL3NoYXJlZC9zZXJ2aWNlc1wiXHJcbi8vaW1wb3J0IHsgTG9hZGVyICB9IGZyb20gXCIuLi9zaGFyZWQvbG9hZGVyXCI7XHJcbmltcG9ydCB7IExvYWRpbmdTY3JlZW4gfSBmcm9tICduYXRpdmVzY3JpcHQtbG9hZGluZy1zY3JlZW4nO1xyXG5cclxuZXhwb3J0IGNsYXNzIFVzZXIge1xyXG4gIHVzZXJuYW1lOiBzdHJpbmdcclxuICBwYXNzd29yZDogc3RyaW5nXHJcbiAgY29uZmlybXBhc3N3b3JkOiBzdHJpbmdcclxuICBlbWFpbDogc3RyaW5nO1xyXG4gIGRldmljZVRva2VuOiBzdHJpbmc7XHJcbn1cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnU2lnbkluJyxcclxuICB0ZW1wbGF0ZVVybDogJy4vc2lnbmluLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi9zaWduaW4uY29tcG9uZW50LmNzcyddLFxyXG4gIG1vZHVsZUlkOiBtb2R1bGUuaWRcclxufSlcclxuZXhwb3J0IGNsYXNzIFNpZ25pbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIHByaXZhdGUgbG9hZGluZ1NjcmVlbjogTG9hZGluZ1NjcmVlbjtcclxuICBvcHRpb25zOiBhbnk7XHJcbiAgdGVzdDogc3RyaW5nO1xyXG4gIGlzTG9nZ2luZ0luID0gZmFsc2U7XHJcbiAgaXNBdXRoZW50aWNhdGluZyA9IGZhbHNlO1xyXG4gIHB1YmxpYyBpbnB1dDogYW55O1xyXG4gIHB1YmxpYyBzZWxlY3RlZEluZGV4ID0gMTtcclxuICBwdWJsaWMgaXRlbXM6IEFycmF5PHN0cmluZz47XHJcbiAgcHVibGljIGJpa2VzOiBBcnJheTxzdHJpbmc+O1xyXG4gIHB1YmxpYyB1c2VyOiBVc2VyO1xyXG4gIHB1YmxpYyBjbGlja1NpZ25JbkJ1dHRvbjogYm9vbGVhbjtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSByb3V0ZXJFeHRlbnNpb25zOiBSb3V0ZXJFeHRlbnNpb25zLFxyXG4gICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlcixcclxuICAgIHByaXZhdGUgYmlrZXBvb2xzZXJ2aWNlOiBCaWtlUG9vbFNlcnZpY2UpIHtcclxuICAgICAgdGhpcy5sb2FkaW5nU2NyZWVuID0gbmV3IExvYWRpbmdTY3JlZW4oKTsgICAgICBcclxuICAgICAgdGhpcy5pc0xvZ2dpbmdJbiA9ZmFsc2U7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpIHsgICAgICAgICAgICBcclxuICAgIHRoaXMudXNlciA9IG5ldyBVc2VyKCk7XHJcbiAgICBjb25zb2xlLmxvZyhBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcInVzZXJpZFwiKSk7XHJcbiAgICBpZihBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcInVzZXJpZFwiKSAhPSBudWxsKXtcclxuICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoWycvaG9tZSddKTtcclxuICAgIH0gICAgXHJcbiAgfVxyXG5cclxuICBHZXRVc2VyKCl7XHJcbiAgICB2YXIgb2JqVXNlciA9IHt1c2VySWQgOiBBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcInVzZXJpZFwiKX07XHJcbiAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLkdldFVzZXIsb2JqVXNlcikuc3Vic2NyaWJlKFxyXG4gICAgICB1c2VyID0+IHRoaXMudXNlclN1Y2Nlc3ModXNlciksXHJcbiAgICAgIGVycm9yID0+IHRoaXMudXNlckVycm9yKGVycm9yKVxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgdXNlclN1Y2Nlc3Moc3VjY2VzcykgIHsgdGhpcy5oaWRlTG9hZGVyKCk7IH1cclxuXHJcbiAgdXNlckVycm9yKGVycm9yKXsgdGhpcy5oaWRlTG9hZGVyKCk7ICB9XHJcblxyXG4gIHRvZ2dsZUZvcm0oKSB7XHJcbiAgICB0aGlzLmNsaWNrU2lnbkluQnV0dG9uID0gIXRoaXMuY2xpY2tTaWduSW5CdXR0b247XHJcbiAgICB0aGlzLmlzTG9nZ2luZ0luID0gIXRoaXMuaXNMb2dnaW5nSW47XHJcbiAgfVxyXG5cclxuICBzaWduVXBTdWNjZXNzKHN1Y2Nlc3MpIHsgICAgXHJcbiAgICB0aGlzLmhpZGVMb2FkZXIoKTsgICAgXHJcbiAgICB0aGlzLmlzTG9nZ2luZ0luID0gdHJ1ZTtcclxuICB9XHJcblxyXG4gIHNpZ25VcEVycm9yKGVycm9yKSB7XHJcbiAgICB0aGlzLmhpZGVMb2FkZXIoKTtcclxuICB9XHJcblxyXG4gIGxvZ2luU3VjY2VzcyhzdWNjZXNzKSB7ICAgIFxyXG4gICAgdGhpcy5oaWRlTG9hZGVyKCk7XHJcbiAgICBsZXQgdXNlciA9IHN1Y2Nlc3MuZGF0YS51c2VyO1xyXG4gICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJlbWFpbFwiLCB1c2VyLmVtYWlsKTtcclxuICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwidXNlcmlkXCIsIHVzZXIudWlkKTtcclxuICAgIGlmKHVzZXIubmFtZSAhPSB1bmRlZmluZWQpe1xyXG4gICAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcInVzZXJuYW1lXCIsdXNlci5uYW1lKTtcclxuICAgIH1cclxuICAgIGVsc2V7XHJcbiAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3MucmVtb3ZlKFwidXNlcm5hbWVcIik7XHJcbiAgICB9XHJcblxyXG4gICAgaWYodXNlci5wcm9maWxlSW1hZ2VVUkwgIT0gdW5kZWZpbmVkKXtcclxuICAgICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJwcm9maWxlSW1hZ2VVUkxcIix1c2VyLnByb2ZpbGVJbWFnZVVSTCk7XHJcbiAgICB9XHJcbiAgICBlbHNle1xyXG4gICAgICBBcHBsaWNhdGlvblNldHRpbmdzLnJlbW92ZShcInByb2ZpbGVJbWFnZVVSTFwiKTtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLm5hdmlnYXRlSG9tZSgpO1xyXG4gIH1cclxuXHJcbiAgbG9naW5FcnJvcihlcnJvcikge1xyXG4gICAgdGhpcy5pc0F1dGhlbnRpY2F0aW5nID0gZmFsc2U7XHJcbiAgICB0aGlzLmhpZGVMb2FkZXIoKTtcclxuICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgIGFsZXJ0KHtcclxuICAgICAgdGl0bGU6IFwiT24gZCBWYXlcIixcclxuICAgICAgbWVzc2FnZTogXCJQbGVhc2UgZW50ZXIgY29ycmVjdCB1c2VybmFtZS9wYXNzd29yZFwiLFxyXG4gICAgICBva0J1dHRvblRleHQ6IFwiT2tcIlxyXG4gICAgfSlcclxuICB9XHJcblxyXG4gIGJ1c3k6IGJvb2xlYW47XHJcblxyXG4gIHN1Ym1pdCgpIHtcclxuICAgIHRoaXMuc2hvd0xvYWRlcigpO1xyXG4gICAgLy8gTm9ybWFsIFNpZ251cCBvbiBkIHZheSAgICBcclxuICAgIGlmICh0aGlzLmlzTG9nZ2luZ0luID09IGZhbHNlKSB7ICAgICAgXHJcbiAgICAgIGlmICh0aGlzLnVzZXIudXNlcm5hbWUgIT0gdW5kZWZpbmVkICYmIHRoaXMudXNlci5wYXNzd29yZCAhPSB1bmRlZmluZWQgJiZcclxuICAgICAgICB0aGlzLnVzZXIuZW1haWwgIT0gdW5kZWZpbmVkICYmXHJcbiAgICAgICAgIHRoaXMudXNlci51c2VybmFtZSAhPSAnJyAmJiB0aGlzLnVzZXIucGFzc3dvcmQgIT0gJycgJiZcclxuICAgICAgICB0aGlzLnVzZXIuZW1haWwgIT0gJycpIHtcclxuICAgICAgICB0aGlzLmlzQXV0aGVudGljYXRpbmcgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuaXNMb2dnaW5nSW4gPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuYnVzeSA9IHRydWU7XHJcbiAgICAgICAgbGV0IG9iakxvZ2luID0ge1xyXG4gICAgICAgICAgdXNlcm5hbWU6IHRoaXMudXNlci51c2VybmFtZSxcclxuICAgICAgICAgIGVtYWlsOiB0aGlzLnVzZXIuZW1haWwsXHJcbiAgICAgICAgICBwYXNzd29yZDogdGhpcy51c2VyLnBhc3N3b3JkLFxyXG4gICAgICAgICAgZGV2aWNlVG9rZW46IEFwcGxpY2F0aW9uU2V0dGluZ3MuZ2V0U3RyaW5nKFwiZGV2aWNlX3Rva2VuXCIpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuYmlrZXBvb2xzZXJ2aWNlLlBvc3RTZXJ2aWNlKFNlcnZpY2VVUkwuU2lnblVwT25EVmF5LCBvYmpMb2dpbikuc3Vic2NyaWJlKFxyXG4gICAgICAgICAgc3VjY2VzcyA9PiB0aGlzLnNpZ25VcFN1Y2Nlc3Moc3VjY2VzcyksXHJcbiAgICAgICAgICBlcnJvciA9PiB0aGlzLnNpZ25VcEVycm9yKGVycm9yKVxyXG4gICAgICAgIClcclxuICAgICAgfVxyXG4gICAgICBlbHNle1xyXG4gICAgICAgIGFsZXJ0KHtcclxuICAgICAgICAgIHRpdGxlOiBcIk9uIGQgVmF5XCIsXHJcbiAgICAgICAgICBtZXNzYWdlOiBcIlBsZWFzZSBFbnRlciB2YWxpZCBJbmZvcm1hdGlvbiB0byBTaWduVXBcIixcclxuICAgICAgICAgIG9rQnV0dG9uVGV4dDogXCJPa1wiXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgZWxzZSBpZih0aGlzLnVzZXIuZW1haWwgIT0gJycgJiYgdGhpcy51c2VyLnBhc3N3b3JkICE9ICcnKSB7XHJcbiAgICAgIHRoaXMuaXNBdXRoZW50aWNhdGluZyA9IHRydWU7ICAgICAgXHJcbiAgICAgIC8vIG5vcm1hbCBsb2dpbiBvbiBkIHZheVxyXG4gICAgICBpZiAodGhpcy51c2VyLmVtYWlsICE9IHVuZGVmaW5lZCAmJiB0aGlzLnVzZXIucGFzc3dvcmQgIT0gdW5kZWZpbmVkIFxyXG4gICAgICAgICYmIHRoaXMudXNlci5wYXNzd29yZCAhPSAnJyAmJiB0aGlzLnVzZXIuZW1haWwgIT0gJycpIHtcclxuICAgICAgICB2YXIgb2JqTG9naW4gPSB7IGVtYWlsOiB0aGlzLnVzZXIuZW1haWwsIHBhc3N3b3JkOiB0aGlzLnVzZXIucGFzc3dvcmQgfTsgICAgICAgIFxyXG4gICAgICAgIHRoaXMuYmlrZXBvb2xzZXJ2aWNlLlBvc3RTZXJ2aWNlKFNlcnZpY2VVUkwuTG9naW4sIG9iakxvZ2luKS5zdWJzY3JpYmUoXHJcbiAgICAgICAgICBzdWNjZXNzID0+IHRoaXMubG9naW5TdWNjZXNzKHN1Y2Nlc3MpLFxyXG4gICAgICAgICAgZXJyb3IgPT4gdGhpcy5sb2dpbkVycm9yKGVycm9yKVxyXG4gICAgICAgIClcclxuICAgICAgfVxyXG4gICAgICBlbHNlXHJcbiAgICAgIHtcclxuICAgICAgICBhbGVydCh7XHJcbiAgICAgICAgICB0aXRsZTogXCJPbiBkIFZheVwiLFxyXG4gICAgICAgICAgbWVzc2FnZTogXCJQbGVhc2UgRW50ZXIgdmFsaWQgSW5mb3JtYXRpb24gdG8gTG9nSW5cIixcclxuICAgICAgICAgIG9rQnV0dG9uVGV4dDogXCJPa1wiXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgaGlkZUxvYWRlcigpeyAgICBcclxuICAgIHRoaXMubG9hZGluZ1NjcmVlbi5jbG9zZSgpO1xyXG4gIH1cclxuXHJcbiAgc2hvd0xvYWRlcigpeyAgICBcclxuICAgIHRoaXMubG9hZGluZ1NjcmVlbi5zaG93KHttZXNzYWdlOiBcIkxvYWRpbmcuLi5cIn0pO1xyXG4gIH1cclxuXHJcbiAgb25EcmF3ZXJCdXR0b25UYXAoKTogdm9pZCB7XHJcbiAgICBjb25zdCBzaWRlRHJhd2VyID0gPFJhZFNpZGVEcmF3ZXI+YXBwLmdldFJvb3RWaWV3KCk7XHJcbiAgICBzaWRlRHJhd2VyLnNob3dEcmF3ZXIoKTtcclxuICB9XHJcblxyXG4gIGdvb2dsZXJlc3VsdChyZXN1bHQpIHtcclxuICAgIHRoaXMuaXNMb2dnaW5nSW4gPSB0cnVlO1xyXG4gICAgdGhpcy5zaG93TG9hZGVyKCk7ICAgIFxyXG4gICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJwcm9maWxlSW1hZ2VcIiwgcmVzdWx0LnByb2ZpbGVJbWFnZVVSTCk7XHJcbiAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcImVtYWlsXCIsIHJlc3VsdC5lbWFpbCk7XHJcbiAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcInVzZXJuYW1lXCIsIHJlc3VsdC5uYW1lKTtcclxuXHJcbiAgICBsZXQgb2JqR29vZ2xlTG9naW4gPSB7XHJcbiAgICAgIHVzZXJpZDogcmVzdWx0LnVpZCxcclxuICAgICAgZGV2aWNlVG9rZW46IEFwcGxpY2F0aW9uU2V0dGluZ3MuZ2V0U3RyaW5nKFwiZGV2aWNlX3Rva2VuXCIpLFxyXG4gICAgICB1c2VybmFtZTogcmVzdWx0Lm5hbWUsXHJcbiAgICAgIGVtYWlsOiByZXN1bHQuZW1haWwsXHJcbiAgICAgIHByb2ZpbGVQaG90bzogcmVzdWx0LnByb2ZpbGVJbWFnZVVSTFxyXG4gICAgfVxyXG5cclxuICAgIHRoaXMuYmlrZXBvb2xzZXJ2aWNlLlBvc3RTZXJ2aWNlKFNlcnZpY2VVUkwuQ3JlYXRlV2l0aFNvY2lhbExvZ2luLCBvYmpHb29nbGVMb2dpbikuc3Vic2NyaWJlKFxyXG4gICAgICB1c2VyID0+IHRoaXMuY3JlYXRldXNlcnN1Y2Nlc3ModXNlciksXHJcbiAgICAgIGVycm9yID0+IHRoaXMuY3JlYXRldXNlcmVycm9yKGVycm9yKVxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgY3JlYXRldXNlcnN1Y2Nlc3ModXNlcikgeyAgICBcclxuICAgIHRoaXMuaGlkZUxvYWRlcigpO1xyXG4gICAgdGhpcy5uYXZpZ2F0ZUhvbWUoKTtcclxuICB9XHJcblxyXG4gIGNyZWF0ZXVzZXJlcnJvcihlcnJvcikgeyAgICBcclxuICAgIHRoaXMuaGlkZUxvYWRlcigpO1xyXG4gICAgYWxlcnQoe1xyXG4gICAgICB0aXRsZTogXCJPbiBkIFZheVwiLFxyXG4gICAgICBtZXNzYWdlOiBlcnJvcixcclxuICAgICAgb2tCdXR0b25UZXh0OiBcIk9rXCJcclxuICAgIH0pXHJcbiAgfVxyXG5cclxuICBnb29nbGVlcnJvcihlcnJvcikge1xyXG4gICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gIH1cclxuXHJcbiAgc3VibWl0R29vZ2xlKCkge1xyXG4gICAgZmlyZWJhc2UubG9naW4oeyB0eXBlOiBmaXJlYmFzZS5Mb2dpblR5cGUuR09PR0xFIH0pLlxyXG4gICAgICB0aGVuKGdvb2dsZXJlc3VsdCA9PiB0aGlzLmdvb2dsZXJlc3VsdChnb29nbGVyZXN1bHQpLFxyXG4gICAgICBnb29nbGVlcnJvciA9PiB0aGlzLmdvb2dsZWVycm9yKGdvb2dsZWVycm9yKSk7XHJcbiAgfVxyXG5cclxuICBmYnJlc3VsdChzdWNjZXNzKSB7XHJcbiAgICB0aGlzLmlzTG9nZ2luZ0luID0gdHJ1ZTtcclxuXHJcbiAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcInByb2ZpbGVJbWFnZVwiLCBzdWNjZXNzLnByb2ZpbGVJbWFnZVVSTCk7XHJcbiAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcImVtYWlsXCIsIHN1Y2Nlc3MuZW1haWwpO1xyXG4gICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJ1c2VybmFtZVwiLCBzdWNjZXNzLm5hbWUpO1xyXG5cclxuICAgIGxldCBvYmpGQkxvZ2luID0ge1xyXG4gICAgICB1c2VyaWQ6IHN1Y2Nlc3MudWlkLFxyXG4gICAgICBkZXZpY2VUb2tlbjogQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJkZXZpY2VfdG9rZW5cIiksXHJcbiAgICAgIHVzZXJuYW1lOiBzdWNjZXNzLm5hbWUsXHJcbiAgICAgIGVtYWlsOiBzdWNjZXNzLmVtYWlsLFxyXG4gICAgICBwcm9maWxlUGhvdG86IHN1Y2Nlc3MucHJvZmlsZUltYWdlVVJMXHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5iaWtlcG9vbHNlcnZpY2UuUG9zdFNlcnZpY2UoU2VydmljZVVSTC5DcmVhdGVXaXRoU29jaWFsTG9naW4sIG9iakZCTG9naW4pLnN1YnNjcmliZShcclxuICAgICAgdXNlciA9PiB0aGlzLmNyZWF0ZXVzZXJzdWNjZXNzKHVzZXIpLFxyXG4gICAgICBlcnJvciA9PiB0aGlzLmNyZWF0ZXVzZXJlcnJvcihlcnJvcilcclxuICAgIClcclxuICB9XHJcblxyXG4gIGZiZXJyb3IoZXJyb3IpIHtcclxuICAgIGxldCBmb3JtYXRFcnJvck1lc3NhZ2UgPSBlcnJvci5yZXBsYWNlKCdjb20uZ29vZ2xlLmZpcmViYXNlLmF1dGguRmlyZWJhc2VBdXRoVXNlckNvbGxpc2lvbkV4Y2VwdGlvbjonLCBcIlwiKTtcclxuICAgIGFsZXJ0KHtcclxuICAgICAgdGl0bGU6IFwiT24gZCBWYXlcIixcclxuICAgICAgbWVzc2FnZTogZm9ybWF0RXJyb3JNZXNzYWdlLFxyXG4gICAgICBva0J1dHRvblRleHQ6IFwiT2tcIlxyXG4gICAgfSlcclxuICB9XHJcblxyXG4gIHN1Ym1pdEZCKCkge1xyXG4gICAgZmlyZWJhc2UubG9naW4oe1xyXG4gICAgICB0eXBlOiBmaXJlYmFzZS5Mb2dpblR5cGUuRkFDRUJPT0ssXHJcbiAgICAgIGZhY2Vib29rT3B0aW9uczoge1xyXG4gICAgICAgIHNjb3BlOiBbJ3B1YmxpY19wcm9maWxlJywgJ2VtYWlsJ11cclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgICAgLnRoZW4oXHJcbiAgICAgIHN1Y2Nlc3MgPT4gdGhpcy5mYnJlc3VsdChzdWNjZXNzKSxcclxuICAgICAgZXJyb3IgPT4gdGhpcy5mYmVycm9yKGVycm9yKVxyXG4gICAgICApXHJcbiAgfVxyXG5cclxuICBwdWJsaWMgb25jaGFuZ2UoYXJnczogU2VsZWN0ZWRJbmRleENoYW5nZWRFdmVudERhdGEpIHtcclxuICAgIGNvbnNvbGUubG9nKGBEcm9wIERvd24gc2VsZWN0ZWQgaW5kZXggY2hhbmdlZCBmcm9tICR7YXJncy5vbGRJbmRleH0gdG8gJHthcmdzLm5ld0luZGV4fWApO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIG9ub3BlbigpIHsgIH1cclxuXHJcbiAgcHVibGljIG9uY2xvc2UoKSB7ICB9XHJcblxyXG4gIG5hdmlnYXRlSG9tZSgpIHtcclxuICAgIHRoaXMucm91dGVyRXh0ZW5zaW9ucy5uYXZpZ2F0ZShbXCIvaG9tZVwiXSwge1xyXG4gICAgICB0cmFuc2l0aW9uOiB7XHJcbiAgICAgICAgbmFtZTogXCJmYWRlXCJcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBzdWNjZXNzRm9yZ290UHdkKHN1Y2Nlc3MpIHtcclxuICAgIGFsZXJ0KHtcclxuICAgICAgdGl0bGU6IFwiT24gZCBWYXlcIixcclxuICAgICAgbWVzc2FnZTogXCJZb3VyIHBhc3N3b3JkIHdhcyBzdWNjZXNzZnVsbHkgcmVzZXQuIFBsZWFzZSBjaGVjayB5b3VyIGVtYWlsIGZvciBpbnN0cnVjdGlvbnMgb24gY2hvb3NpbmcgYSBuZXcgcGFzc3dvcmQuXCIsXHJcbiAgICAgIG9rQnV0dG9uVGV4dDogXCJPa1wiXHJcbiAgICB9KVxyXG4gIH1cclxuXHJcbiAgZXJyb3JGb3Jnb3RQd2QoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICB9XHJcblxyXG4gIGZvcmdvdFBhc3N3b3JkKCkge1xyXG4gICAgcHJvbXB0KHtcclxuICAgICAgdGl0bGU6IFwiRm9yZ290IFBhc3N3b3JkXCIsXHJcbiAgICAgIG1lc3NhZ2U6IFwiRW50ZXIgdGhlIGVtYWlsIGFkZHJlc3MgeW91IHVzZWQgdG8gcmVnaXN0ZXIgZm9yIE9uIGQgVmF5IHRvIHJlc2V0IHlvdXIgcGFzc3dvcmQuXCIsXHJcbiAgICAgIGRlZmF1bHRUZXh0OiBcIlwiLFxyXG4gICAgICBva0J1dHRvblRleHQ6IFwiT2tcIixcclxuICAgICAgY2FuY2VsQnV0dG9uVGV4dDogXCJDYW5jZWxcIlxyXG4gICAgfSkudGhlbigoZGF0YSkgPT4ge1xyXG4gICAgICBpZiAoZGF0YS5yZXN1bHQpIHtcclxuICAgICAgICAvLyBDYWxsIHRoZSBiYWNrZW5kIHRvIHJlc2V0IHRoZSBwYXNzd29yZFxyXG4gICAgICAgIHZhciBvYmplbWFpbCA9IHsgZW1haWxBZGRyZXNzOiBkYXRhLnRleHQudG9TdHJpbmcoKS50cmltKCkgfVxyXG4gICAgICAgIHRoaXMuYmlrZXBvb2xzZXJ2aWNlLlBvc3RTZXJ2aWNlKFNlcnZpY2VVUkwuUmVzZXRQYXNzd29yZCwgb2JqZW1haWwpLnN1YnNjcmliZShcclxuICAgICAgICAgIHN1Y2Nlc3MgPT4gdGhpcy5zdWNjZXNzRm9yZ290UHdkKHN1Y2Nlc3MpLFxyXG4gICAgICAgICAgZXJyb3IgPT4gdGhpcy5lcnJvckZvcmdvdFB3ZChlcnJvcilcclxuICAgICAgICApXHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxufVxyXG4iXX0=