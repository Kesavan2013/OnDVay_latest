"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var app = require("tns-core-modules/application");
var bikepoolservice_1 = require("../shared/bikepoolservice");
var services_1 = require("../shared/services");
var ApplicationSettings = require("application-settings");
var Geolocation = require("nativescript-geolocation");
var nativescript_loading_screen_1 = require("nativescript-loading-screen");
var dialogs_1 = require("tns-core-modules/ui/dialogs");
var RidersItem = /** @class */ (function () {
    function RidersItem(name, distance, status, userid, devicetoken, profilePhoto) {
        this.name = name;
        this.distance = distance;
        this.status = status;
        this.userid = userid;
        this.devicetoken = devicetoken;
        this.profilePhoto = profilePhoto;
    }
    return RidersItem;
}());
var RiderListComponent = /** @class */ (function () {
    function RiderListComponent(bikepoolservice) {
        this.bikepoolservice = bikepoolservice;
    }
    RiderListComponent.prototype.RidersListSuccess = function (riders) {
        for (var ride = 0; ride < riders.Data.length; ride++) {
            if (riders.Data[ride].userid != ApplicationSettings.getString("userid")) {
                var distance = this.CalculateDistance(riders.Data[ride].latitude, riders.Data[ride].longitude);
                var rideDistance = isNaN(distance) ? "Less than a Km" : distance.toString();
                this.dataItems.push(new RidersItem(riders.Data[ride].username, rideDistance.toString(), riders.Data[ride].status, riders.Data[ride].userid, riders.Data[ride].deviceToken, riders.Data[ride].profilePhoto));
            }
        }
        if (this.dataItems.length <= 0) {
            this.noRidersAvail = true;
        }
        this.hideLoader();
    };
    RiderListComponent.prototype.CalculateDistance = function (lat, long) {
        var locationFrom = new Geolocation.Location();
        locationFrom.latitude = parseFloat(ApplicationSettings.getString("fromlat"));
        locationFrom.longitude = parseFloat(ApplicationSettings.getString("fromlong"));
        var locationTo = new Geolocation.Location();
        locationTo.latitude = parseFloat(lat);
        locationTo.longitude = parseFloat(long);
        var distance = Geolocation.distance(locationFrom, locationTo);
        return (distance / 1000).toFixed(2).toString() + "kms";
    };
    RiderListComponent.prototype.RiderListError = function (error) {
        this.showLoader = false;
        this.hideLoader();
    };
    RiderListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.loadingScreen = new nativescript_loading_screen_1.LoadingScreen();
        this.dataItems = [];
        this.showLoader = true;
        this.LoaderShow();
        this.bikepoolservice.PostService(services_1.ServiceURL.RideUsers, null).subscribe(function (riders) { return _this.RidersListSuccess(riders); }, function (error) { return _this.RiderListError(error); });
    };
    RiderListComponent.prototype.hideLoader = function () {
        //this.loader.hide();
        this.loadingScreen.close();
    };
    RiderListComponent.prototype.LoaderShow = function () {
        //this.loader.show(this.options);
        this.loadingScreen.show({
            message: "Loading..."
        });
    };
    RiderListComponent.prototype.onDrawerButtonTap = function () {
        var sideDrawer = app.getRootView();
        sideDrawer.showDrawer();
    };
    RiderListComponent.prototype.onItemTap = function (args) {
        var _this = this;
        var selectedRider = this.dataItems[args.index];
        var objRideStatus = {
            userid: selectedRider.userid,
            rideStartTime: ApplicationSettings.getString("ridetime"),
            rideDistance: ApplicationSettings.getString("ridedistance"),
            currentLocation: ApplicationSettings.getString("currentlocation"),
            destinationLocation: ApplicationSettings.getString("tolocation"),
            deviceToken: selectedRider.devicetoken,
        };
        this.LoaderShow();
        this.bikepoolservice.PostService(services_1.ServiceURL.RequestForRide, objRideStatus).subscribe(function (success) { return _this.RideStatusSuccess(success); }, function (error) { return _this.RideStatusError(error); });
    };
    RiderListComponent.prototype.RideStatusSuccess = function (response) {
        this.hideLoader();
        dialogs_1.alert({
            title: "On d Vay",
            message: "Request has been placed for ride",
            okButtonText: "Ok"
        });
    };
    RiderListComponent.prototype.RideStatusError = function (error) {
        this.hideLoader();
    };
    RiderListComponent.prototype.onRiderItemTap = function (item) { };
    RiderListComponent.prototype.onSetupItemView = function (args) {
        args.view.context.third = (args.index % 3 === 0);
    };
    RiderListComponent = __decorate([
        core_1.Component({
            selector: 'ns-riderslist',
            templateUrl: './riderslist.component.html',
            moduleId: module.id,
        }),
        __metadata("design:paramtypes", [bikepoolservice_1.BikePoolService])
    ], RiderListComponent);
    return RiderListComponent;
}());
exports.RiderListComponent = RiderListComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmlkZXJzbGlzdC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJyaWRlcnNsaXN0LmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQUVsRCxrREFBb0Q7QUFFcEQsNkRBQTJEO0FBQzNELCtDQUFnRDtBQUNoRCwwREFBNEQ7QUFDNUQsc0RBQXdEO0FBQ3hELDJFQUE0RDtBQUM1RCx1REFBNEQ7QUFFNUQ7SUFDRSxvQkFBbUIsSUFBWSxFQUN0QixRQUFnQixFQUFTLE1BQWMsRUFBUyxNQUFjLEVBQzlELFdBQWtCLEVBQVEsWUFBbUI7UUFGbkMsU0FBSSxHQUFKLElBQUksQ0FBUTtRQUN0QixhQUFRLEdBQVIsUUFBUSxDQUFRO1FBQVMsV0FBTSxHQUFOLE1BQU0sQ0FBUTtRQUFTLFdBQU0sR0FBTixNQUFNLENBQVE7UUFDOUQsZ0JBQVcsR0FBWCxXQUFXLENBQU87UUFBUSxpQkFBWSxHQUFaLFlBQVksQ0FBTztJQUFJLENBQUM7SUFDN0QsaUJBQUM7QUFBRCxDQUFDLEFBSkQsSUFJQztBQU9EO0lBZ0RFLDRCQUFvQixlQUFnQztRQUFoQyxvQkFBZSxHQUFmLGVBQWUsQ0FBaUI7SUFDcEQsQ0FBQztJQXhDRCw4Q0FBaUIsR0FBakIsVUFBa0IsTUFBTTtRQUV0QixLQUFLLElBQUksSUFBSSxHQUFHLENBQUMsRUFBRSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDcEQsSUFBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sSUFBSSxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLEVBQ3RFO2dCQUNFLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFBO2dCQUM5RixJQUFJLFlBQVksR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUM7Z0JBQzVFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxRQUFRLEVBQUUsRUFDckYsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQ2xELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxFQUM3QixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUE7YUFDbEM7U0FDRjtRQUVELElBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUM3QjtZQUNFLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1NBQzNCO1FBRUQsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFRCw4Q0FBaUIsR0FBakIsVUFBa0IsR0FBRyxFQUFFLElBQUk7UUFDekIsSUFBSSxZQUFZLEdBQUcsSUFBSSxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDOUMsWUFBWSxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7UUFDN0UsWUFBWSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7UUFFL0UsSUFBSSxVQUFVLEdBQUcsSUFBSSxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDNUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDdEMsVUFBVSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFeEMsSUFBSSxRQUFRLEdBQUcsV0FBVyxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFDOUQsT0FBTyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxFQUFFLEdBQUcsS0FBSyxDQUFDO0lBQ3pELENBQUM7SUFFRCwyQ0FBYyxHQUFkLFVBQWUsS0FBSztRQUNsQixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUN4QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUlELHFDQUFRLEdBQVI7UUFBQSxpQkFTQztRQVJDLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSwyQ0FBYSxFQUFFLENBQUM7UUFDekMsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUM7UUFDcEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7UUFDdkIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2QsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUNwRSxVQUFBLE1BQU0sSUFBSSxPQUFBLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsRUFBOUIsQ0FBOEIsRUFDeEMsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUExQixDQUEwQixDQUNwQyxDQUFBO0lBQ1AsQ0FBQztJQUVELHVDQUFVLEdBQVY7UUFDRSxxQkFBcUI7UUFDckIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUMvQixDQUFDO0lBRUQsdUNBQVUsR0FBVjtRQUNJLGlDQUFpQztRQUNqQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQztZQUNwQixPQUFPLEVBQUUsWUFBWTtTQUN4QixDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUMsOENBQWlCLEdBQWpCO1FBQ0UsSUFBTSxVQUFVLEdBQWtCLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNwRCxVQUFVLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVELHNDQUFTLEdBQVQsVUFBVSxJQUFJO1FBQWQsaUJBbUJDO1FBbEJDLElBQUksYUFBYSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRS9DLElBQUksYUFBYSxHQUNqQjtZQUNFLE1BQU0sRUFBRyxhQUFhLENBQUMsTUFBTTtZQUM3QixhQUFhLEVBQUcsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQztZQUN6RCxZQUFZLEVBQUcsbUJBQW1CLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQztZQUM1RCxlQUFlLEVBQUcsbUJBQW1CLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDO1lBQ2xFLG1CQUFtQixFQUFHLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUM7WUFDakUsV0FBVyxFQUFHLGFBQWEsQ0FBQyxXQUFXO1NBQ3hDLENBQUE7UUFFRCxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFFbEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxjQUFjLEVBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUNqRixVQUFBLE9BQU8sSUFBRyxPQUFBLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsRUFBL0IsQ0FBK0IsRUFDekMsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxFQUEzQixDQUEyQixDQUNyQyxDQUFBO0lBQ0gsQ0FBQztJQUVELDhDQUFpQixHQUFqQixVQUFrQixRQUFRO1FBQ3hCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixlQUFLLENBQUM7WUFDSixLQUFLLEVBQUUsVUFBVTtZQUNqQixPQUFPLEVBQUUsa0NBQWtDO1lBQzNDLFlBQVksRUFBRSxJQUFJO1NBQ25CLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCw0Q0FBZSxHQUFmLFVBQWdCLEtBQUs7UUFDbkIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFRCwyQ0FBYyxHQUFkLFVBQWUsSUFBZ0IsSUFBRyxDQUFDO0lBRW5DLDRDQUFlLEdBQWYsVUFBZ0IsSUFBdUI7UUFDckMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7SUFDbkQsQ0FBQztJQXJIVSxrQkFBa0I7UUFMOUIsZ0JBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxlQUFlO1lBQ3pCLFdBQVcsRUFBRSw2QkFBNkI7WUFDMUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1NBQ3BCLENBQUM7eUNBaURxQyxpQ0FBZTtPQWhEekMsa0JBQWtCLENBc0g5QjtJQUFELHlCQUFDO0NBQUEsQUF0SEQsSUFzSEM7QUF0SFksZ0RBQWtCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJhZFNpZGVEcmF3ZXIgfSBmcm9tIFwibmF0aXZlc2NyaXB0LXVpLXNpZGVkcmF3ZXJcIjtcbmltcG9ydCAqIGFzIGFwcCBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9hcHBsaWNhdGlvblwiO1xuaW1wb3J0IHsgU2V0dXBJdGVtVmlld0FyZ3MgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvZGlyZWN0aXZlc1wiO1xuaW1wb3J0IHsgQmlrZVBvb2xTZXJ2aWNlIH0gZnJvbSBcIi4uL3NoYXJlZC9iaWtlcG9vbHNlcnZpY2VcIlxuaW1wb3J0IHsgU2VydmljZVVSTCB9IGZyb20gXCIuLi9zaGFyZWQvc2VydmljZXNcIjtcbmltcG9ydCAqIGFzIEFwcGxpY2F0aW9uU2V0dGluZ3MgZnJvbSBcImFwcGxpY2F0aW9uLXNldHRpbmdzXCI7XG5pbXBvcnQgKiBhcyBHZW9sb2NhdGlvbiBmcm9tIFwibmF0aXZlc2NyaXB0LWdlb2xvY2F0aW9uXCI7XG5pbXBvcnQgeyBMb2FkaW5nU2NyZWVuIH0gZnJvbSAnbmF0aXZlc2NyaXB0LWxvYWRpbmctc2NyZWVuJztcbmltcG9ydCB7IGFsZXJ0LCBwcm9tcHQgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy91aS9kaWFsb2dzXCI7XG5cbmNsYXNzIFJpZGVyc0l0ZW0ge1xuICBjb25zdHJ1Y3RvcihwdWJsaWMgbmFtZTogc3RyaW5nLFxuICAgIHB1YmxpYyBkaXN0YW5jZTogc3RyaW5nLCBwdWJsaWMgc3RhdHVzOiBzdHJpbmcsIHB1YmxpYyB1c2VyaWQ6IHN0cmluZyxcbiAgICBwdWJsaWMgZGV2aWNldG9rZW46c3RyaW5nLHB1YmxpYyBwcm9maWxlUGhvdG86c3RyaW5nKSB7IH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbnMtcmlkZXJzbGlzdCcsXG4gIHRlbXBsYXRlVXJsOiAnLi9yaWRlcnNsaXN0LmNvbXBvbmVudC5odG1sJyxcbiAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcbn0pXG5leHBvcnQgY2xhc3MgUmlkZXJMaXN0Q29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcblxuICBwcml2YXRlIGxvYWRpbmdTY3JlZW46IExvYWRpbmdTY3JlZW47XG4gIHB1YmxpYyBkYXRhSXRlbXM6IEFycmF5PFJpZGVyc0l0ZW0+O1xuICBmcm9tTGF0OiBzdHJpbmc7XG4gIGZyb21Mb25nOiBzdHJpbmc7XG4gIHNob3dMb2FkZXI6Ym9vbGVhbjtcbiAgbm9SaWRlcnNBdmFpbCA6IGJvb2xlYW47XG5cbiAgUmlkZXJzTGlzdFN1Y2Nlc3MocmlkZXJzKSB7XG4gICAgXG4gICAgZm9yIChsZXQgcmlkZSA9IDA7IHJpZGUgPCByaWRlcnMuRGF0YS5sZW5ndGg7IHJpZGUrKykge1xuICAgICAgaWYocmlkZXJzLkRhdGFbcmlkZV0udXNlcmlkICE9IEFwcGxpY2F0aW9uU2V0dGluZ3MuZ2V0U3RyaW5nKFwidXNlcmlkXCIpKVxuICAgICAge1xuICAgICAgICBsZXQgZGlzdGFuY2UgPSB0aGlzLkNhbGN1bGF0ZURpc3RhbmNlKHJpZGVycy5EYXRhW3JpZGVdLmxhdGl0dWRlLCByaWRlcnMuRGF0YVtyaWRlXS5sb25naXR1ZGUpXG4gICAgICAgIGxldCByaWRlRGlzdGFuY2UgPSBpc05hTihkaXN0YW5jZSkgPyBcIkxlc3MgdGhhbiBhIEttXCIgOiBkaXN0YW5jZS50b1N0cmluZygpO1xuICAgICAgICB0aGlzLmRhdGFJdGVtcy5wdXNoKG5ldyBSaWRlcnNJdGVtKHJpZGVycy5EYXRhW3JpZGVdLnVzZXJuYW1lLCByaWRlRGlzdGFuY2UudG9TdHJpbmcoKSxcbiAgICAgICAgIHJpZGVycy5EYXRhW3JpZGVdLnN0YXR1cywgcmlkZXJzLkRhdGFbcmlkZV0udXNlcmlkLFxuICAgICAgICAgcmlkZXJzLkRhdGFbcmlkZV0uZGV2aWNlVG9rZW4sXG4gICAgICAgICByaWRlcnMuRGF0YVtyaWRlXS5wcm9maWxlUGhvdG8pKVxuICAgICAgfVxuICAgIH1cblxuICAgIGlmKHRoaXMuZGF0YUl0ZW1zLmxlbmd0aCA8PSAwKVxuICAgIHtcbiAgICAgIHRoaXMubm9SaWRlcnNBdmFpbCA9IHRydWU7XG4gICAgfVxuXG4gICAgdGhpcy5oaWRlTG9hZGVyKCk7XG4gIH1cblxuICBDYWxjdWxhdGVEaXN0YW5jZShsYXQsIGxvbmcpOiBhbnkge1xuICAgIGxldCBsb2NhdGlvbkZyb20gPSBuZXcgR2VvbG9jYXRpb24uTG9jYXRpb24oKTtcbiAgICBsb2NhdGlvbkZyb20ubGF0aXR1ZGUgPSBwYXJzZUZsb2F0KEFwcGxpY2F0aW9uU2V0dGluZ3MuZ2V0U3RyaW5nKFwiZnJvbWxhdFwiKSk7XG4gICAgbG9jYXRpb25Gcm9tLmxvbmdpdHVkZSA9IHBhcnNlRmxvYXQoQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJmcm9tbG9uZ1wiKSk7XG5cbiAgICBsZXQgbG9jYXRpb25UbyA9IG5ldyBHZW9sb2NhdGlvbi5Mb2NhdGlvbigpO1xuICAgIGxvY2F0aW9uVG8ubGF0aXR1ZGUgPSBwYXJzZUZsb2F0KGxhdCk7XG4gICAgbG9jYXRpb25Uby5sb25naXR1ZGUgPSBwYXJzZUZsb2F0KGxvbmcpO1xuXG4gICAgbGV0IGRpc3RhbmNlID0gR2VvbG9jYXRpb24uZGlzdGFuY2UobG9jYXRpb25Gcm9tLCBsb2NhdGlvblRvKTtcbiAgICByZXR1cm4gKGRpc3RhbmNlIC8gMTAwMCkudG9GaXhlZCgyKS50b1N0cmluZygpICsgXCJrbXNcIjtcbiAgfVxuXG4gIFJpZGVyTGlzdEVycm9yKGVycm9yKSB7XG4gICAgdGhpcy5zaG93TG9hZGVyID0gZmFsc2U7XG4gICAgdGhpcy5oaWRlTG9hZGVyKCk7XG4gIH1cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBiaWtlcG9vbHNlcnZpY2U6IEJpa2VQb29sU2VydmljZSkgeyAgICBcbiAgfVxuXG4gIG5nT25Jbml0KCkge1xuICAgIHRoaXMubG9hZGluZ1NjcmVlbiA9IG5ldyBMb2FkaW5nU2NyZWVuKCk7XG4gICAgdGhpcy5kYXRhSXRlbXMgPSBbXTtcbiAgICB0aGlzLnNob3dMb2FkZXIgPSB0cnVlO1xuICAgIHRoaXMuTG9hZGVyU2hvdygpO1xuICAgICAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLlJpZGVVc2VycywgbnVsbCkuc3Vic2NyaWJlKFxuICAgICAgICAgIHJpZGVycyA9PiB0aGlzLlJpZGVyc0xpc3RTdWNjZXNzKHJpZGVycyksXG4gICAgICAgICAgZXJyb3IgPT4gdGhpcy5SaWRlckxpc3RFcnJvcihlcnJvcilcbiAgICAgICAgKVxuICB9XG5cbiAgaGlkZUxvYWRlcigpIHtcbiAgICAvL3RoaXMubG9hZGVyLmhpZGUoKTtcbiAgICB0aGlzLmxvYWRpbmdTY3JlZW4uY2xvc2UoKTtcbn1cblxuTG9hZGVyU2hvdygpIHtcbiAgICAvL3RoaXMubG9hZGVyLnNob3codGhpcy5vcHRpb25zKTtcbiAgICB0aGlzLmxvYWRpbmdTY3JlZW4uc2hvdyh7XG4gICAgICAgIG1lc3NhZ2U6IFwiTG9hZGluZy4uLlwiXG4gICAgfSk7XG59XG5cbiAgb25EcmF3ZXJCdXR0b25UYXAoKTogdm9pZCB7XG4gICAgY29uc3Qgc2lkZURyYXdlciA9IDxSYWRTaWRlRHJhd2VyPmFwcC5nZXRSb290VmlldygpO1xuICAgIHNpZGVEcmF3ZXIuc2hvd0RyYXdlcigpO1xuICB9XG5cbiAgb25JdGVtVGFwKGFyZ3MpIHtcbiAgICBsZXQgc2VsZWN0ZWRSaWRlciA9IHRoaXMuZGF0YUl0ZW1zW2FyZ3MuaW5kZXhdO1xuICAgIFxuICAgIGxldCBvYmpSaWRlU3RhdHVzID1cbiAgICB7XG4gICAgICB1c2VyaWQgOiBzZWxlY3RlZFJpZGVyLnVzZXJpZCxcbiAgICAgIHJpZGVTdGFydFRpbWUgOiBBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcInJpZGV0aW1lXCIpLFxuICAgICAgcmlkZURpc3RhbmNlIDogQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJyaWRlZGlzdGFuY2VcIiksXG4gICAgICBjdXJyZW50TG9jYXRpb24gOiBBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcImN1cnJlbnRsb2NhdGlvblwiKSxcbiAgICAgIGRlc3RpbmF0aW9uTG9jYXRpb24gOiBBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcInRvbG9jYXRpb25cIiksXG4gICAgICBkZXZpY2VUb2tlbiA6IHNlbGVjdGVkUmlkZXIuZGV2aWNldG9rZW4sICAgICAgXG4gICAgfVxuXG4gICAgdGhpcy5Mb2FkZXJTaG93KCk7XG5cbiAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLlJlcXVlc3RGb3JSaWRlLG9ialJpZGVTdGF0dXMpLnN1YnNjcmliZShcbiAgICAgIHN1Y2Nlc3MgPT50aGlzLlJpZGVTdGF0dXNTdWNjZXNzKHN1Y2Nlc3MpLFxuICAgICAgZXJyb3IgPT4gdGhpcy5SaWRlU3RhdHVzRXJyb3IoZXJyb3IpXG4gICAgKVxuICB9XG5cbiAgUmlkZVN0YXR1c1N1Y2Nlc3MocmVzcG9uc2Upe1xuICAgIHRoaXMuaGlkZUxvYWRlcigpO1xuICAgIGFsZXJ0KHtcbiAgICAgIHRpdGxlOiBcIk9uIGQgVmF5XCIsXG4gICAgICBtZXNzYWdlOiBcIlJlcXVlc3QgaGFzIGJlZW4gcGxhY2VkIGZvciByaWRlXCIsXG4gICAgICBva0J1dHRvblRleHQ6IFwiT2tcIlxuICAgIH0pXG4gIH1cblxuICBSaWRlU3RhdHVzRXJyb3IoZXJyb3Ipe1xuICAgIHRoaXMuaGlkZUxvYWRlcigpO1xuICB9XG5cbiAgb25SaWRlckl0ZW1UYXAoaXRlbTogUmlkZXJzSXRlbSkge31cblxuICBvblNldHVwSXRlbVZpZXcoYXJnczogU2V0dXBJdGVtVmlld0FyZ3MpIHtcbiAgICBhcmdzLnZpZXcuY29udGV4dC50aGlyZCA9IChhcmdzLmluZGV4ICUgMyA9PT0gMCk7XG4gIH1cbn1cbiJdfQ==