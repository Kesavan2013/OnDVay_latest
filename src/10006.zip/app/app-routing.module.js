"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("nativescript-angular/router");
var routes = [
    { path: "", redirectTo: "/signin", pathMatch: "full" },
    { path: "home", loadChildren: "~/app/home/home.module#HomeModule" },
    { path: "myrides", loadChildren: "~/app/myrides/myrides.module#MyridesModule" },
    { path: "rideinfo", loadChildren: "~/app/rideinfo/rideinfo.module#RideInfoModule" },
    { path: "signin", loadChildren: "~/app/signin/signin.module#SigninModule" },
    { path: "riderslist", loadChildren: "~/app/riderslist/riderslist.module#RidersListModule" },
    { path: "configureride", loadChildren: "~/app/configureride/configureride.module#ConfigureRideModule" }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        core_1.NgModule({
            imports: [router_1.NativeScriptRouterModule.forRoot(routes)],
            exports: [router_1.NativeScriptRouterModule]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());
exports.AppRoutingModule = AppRoutingModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLXJvdXRpbmcubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYXBwLXJvdXRpbmcubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQXlDO0FBRXpDLHNEQUF1RTtBQUV2RSxJQUFNLE1BQU0sR0FBVztJQUNuQixFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsVUFBVSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFO0lBQ3RELEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsbUNBQW1DLEVBQUU7SUFDbkUsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSw0Q0FBNEMsRUFBRTtJQUMvRSxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsWUFBWSxFQUFFLCtDQUErQyxFQUFFO0lBQ25GLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUseUNBQXlDLEVBQUU7SUFDM0UsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFLFlBQVksRUFBRSxxREFBcUQsRUFBRTtJQUMzRixFQUFFLElBQUksRUFBRyxlQUFlLEVBQUMsWUFBWSxFQUFDLDhEQUE4RCxFQUFDO0NBQ3hHLENBQUM7QUFNRjtJQUFBO0lBQWdDLENBQUM7SUFBcEIsZ0JBQWdCO1FBSjVCLGVBQVEsQ0FBQztZQUNOLE9BQU8sRUFBRSxDQUFDLGlDQUF3QixDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNuRCxPQUFPLEVBQUUsQ0FBQyxpQ0FBd0IsQ0FBQztTQUN0QyxDQUFDO09BQ1csZ0JBQWdCLENBQUk7SUFBRCx1QkFBQztDQUFBLEFBQWpDLElBQWlDO0FBQXBCLDRDQUFnQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IFJvdXRlcyB9IGZyb20gXCJAYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IE5hdGl2ZVNjcmlwdFJvdXRlck1vZHVsZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9yb3V0ZXJcIjtcblxuY29uc3Qgcm91dGVzOiBSb3V0ZXMgPSBbXG4gICAgeyBwYXRoOiBcIlwiLCByZWRpcmVjdFRvOiBcIi9zaWduaW5cIiwgcGF0aE1hdGNoOiBcImZ1bGxcIiB9LFxuICAgIHsgcGF0aDogXCJob21lXCIsIGxvYWRDaGlsZHJlbjogXCJ+L2FwcC9ob21lL2hvbWUubW9kdWxlI0hvbWVNb2R1bGVcIiB9LFxuICAgIHsgcGF0aDogXCJteXJpZGVzXCIsIGxvYWRDaGlsZHJlbjogXCJ+L2FwcC9teXJpZGVzL215cmlkZXMubW9kdWxlI015cmlkZXNNb2R1bGVcIiB9LFxuICAgIHsgcGF0aDogXCJyaWRlaW5mb1wiLCBsb2FkQ2hpbGRyZW46IFwifi9hcHAvcmlkZWluZm8vcmlkZWluZm8ubW9kdWxlI1JpZGVJbmZvTW9kdWxlXCIgfSwgICAgXG4gICAgeyBwYXRoOiBcInNpZ25pblwiLCBsb2FkQ2hpbGRyZW46IFwifi9hcHAvc2lnbmluL3NpZ25pbi5tb2R1bGUjU2lnbmluTW9kdWxlXCIgfSxcbiAgICB7IHBhdGg6IFwicmlkZXJzbGlzdFwiLCBsb2FkQ2hpbGRyZW46IFwifi9hcHAvcmlkZXJzbGlzdC9yaWRlcnNsaXN0Lm1vZHVsZSNSaWRlcnNMaXN0TW9kdWxlXCIgfSxcbiAgICB7IHBhdGggOiBcImNvbmZpZ3VyZXJpZGVcIixsb2FkQ2hpbGRyZW46XCJ+L2FwcC9jb25maWd1cmVyaWRlL2NvbmZpZ3VyZXJpZGUubW9kdWxlI0NvbmZpZ3VyZVJpZGVNb2R1bGVcIn1cbl07XG5cbkBOZ01vZHVsZSh7XG4gICAgaW1wb3J0czogW05hdGl2ZVNjcmlwdFJvdXRlck1vZHVsZS5mb3JSb290KHJvdXRlcyldLFxuICAgIGV4cG9ydHM6IFtOYXRpdmVTY3JpcHRSb3V0ZXJNb2R1bGVdXG59KVxuZXhwb3J0IGNsYXNzIEFwcFJvdXRpbmdNb2R1bGUgeyB9XG4iXX0=