"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var app = require("tns-core-modules/application");
var bikepoolservice_1 = require("../shared/bikepoolservice");
var services_1 = require("../shared/services");
var ApplicationSettings = require("application-settings");
var nativescript_loading_screen_1 = require("nativescript-loading-screen");
var RideHistory = /** @class */ (function () {
    function RideHistory(DropLocation, PickLocation, StartTime, VehicleTypeText, rideTaken) {
        this.DropLocation = DropLocation;
        this.PickLocation = PickLocation;
        this.StartTime = StartTime;
        this.VehicleTypeText = VehicleTypeText;
        this.rideTaken = rideTaken;
    }
    return RideHistory;
}());
var MyridesComponent = /** @class */ (function () {
    function MyridesComponent(bikepoolservice) {
        this.bikepoolservice = bikepoolservice;
    }
    MyridesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.rideHistoryItem = [];
        this.loadingScreen = new nativescript_loading_screen_1.LoadingScreen();
        console.log(ApplicationSettings.getString("userid"));
        var objUser = { userid: ApplicationSettings.getString("userid") };
        this.showLoader = true;
        this.LoaderShow();
        this.bikepoolservice.PostService(services_1.ServiceURL.GetMyRide, objUser).subscribe(function (success) { return _this.riderList(success); }, function (error) { return _this.riderListError(error); });
    };
    MyridesComponent.prototype.riderList = function (riders) {
        this.showLoader = false;
        this.hideLoader();
        var objRides = riders.rides;
        console.log(objRides);
        if (objRides.length > 0) {
            for (var i = 0; i <= objRides.length; i++) {
                var ridehistory = new RideHistory(objRides[i].DropLocation, objRides[i].PickLocation, objRides[i].StartTime, objRides[i].VehicleTypeText, objRides[i].rideTaken = (objRides[i].offerRide == true) ? "Ride Offered" : "Ride Requested");
                this.rideHistoryItem.push(ridehistory);
            }
        }
    };
    MyridesComponent.prototype.riderListError = function (error) {
        this.showLoader = false;
        this.hideLoader();
        console.log("error" + error);
    };
    MyridesComponent.prototype.onDrawerButtonTap = function () {
        var sideDrawer = app.getRootView();
        sideDrawer.showDrawer();
    };
    MyridesComponent.prototype.hideLoader = function () {
        //this.loader.hide();
        this.loadingScreen.close();
    };
    MyridesComponent.prototype.LoaderShow = function () {
        //this.loader.show(this.options);
        this.loadingScreen.show({
            message: "Loading..."
        });
    };
    MyridesComponent = __decorate([
        core_1.Component({
            selector: 'ns-myrides',
            templateUrl: './myrides.component.html',
            styleUrls: ['./myrides.component.css'],
            moduleId: module.id,
        }),
        __metadata("design:paramtypes", [bikepoolservice_1.BikePoolService])
    ], MyridesComponent);
    return MyridesComponent;
}());
exports.MyridesComponent = MyridesComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXlyaWRlcy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJteXJpZGVzLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQUVsRCxrREFBb0Q7QUFDcEQsNkRBQTREO0FBQzVELCtDQUFnRDtBQUNoRCwwREFBNEQ7QUFDNUQsMkVBQTREO0FBRTVEO0lBQ0UscUJBQW1CLFlBQW9CLEVBQVMsWUFBb0IsRUFBUyxTQUFpQixFQUNyRixlQUF1QixFQUFRLFNBQWdCO1FBRHJDLGlCQUFZLEdBQVosWUFBWSxDQUFRO1FBQVMsaUJBQVksR0FBWixZQUFZLENBQVE7UUFBUyxjQUFTLEdBQVQsU0FBUyxDQUFRO1FBQ3JGLG9CQUFlLEdBQWYsZUFBZSxDQUFRO1FBQVEsY0FBUyxHQUFULFNBQVMsQ0FBTztJQUFJLENBQUM7SUFDL0Qsa0JBQUM7QUFBRCxDQUFDLEFBSEQsSUFHQztBQVFEO0lBS0UsMEJBQW9CLGVBQWdDO1FBQWhDLG9CQUFlLEdBQWYsZUFBZSxDQUFpQjtJQUFJLENBQUM7SUFFekQsbUNBQVEsR0FBUjtRQUFBLGlCQVdDO1FBVkMsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFDMUIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLDJDQUFhLEVBQUUsQ0FBQztRQUN6QyxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQ3JELElBQUksT0FBTyxHQUFHLEVBQUUsTUFBTSxFQUFFLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFBO1FBQ2pFLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNsQixJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxxQkFBVSxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQ3ZFLFVBQUEsT0FBTyxJQUFJLE9BQUEsS0FBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsRUFBdkIsQ0FBdUIsRUFDbEMsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxFQUExQixDQUEwQixDQUNwQyxDQUFBO0lBQ0gsQ0FBQztJQUVELG9DQUFTLEdBQVQsVUFBVSxNQUFNO1FBQ2QsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7UUFDeEIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ2xCLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDNUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN0QixJQUFJLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1lBQ3ZCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUN6QyxJQUFJLFdBQVcsR0FBRyxJQUFJLFdBQVcsQ0FDL0IsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksRUFDeEIsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksRUFDeEIsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFDckIsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsRUFDM0IsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQzVGLENBQUE7Z0JBQ0QsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7YUFDeEM7U0FDRjtJQUNILENBQUM7SUFFRCx5Q0FBYyxHQUFkLFVBQWUsS0FBSztRQUNsQixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUN4QixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVELDRDQUFpQixHQUFqQjtRQUNFLElBQU0sVUFBVSxHQUFrQixHQUFHLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEQsVUFBVSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFSCxxQ0FBVSxHQUFWO1FBQ0kscUJBQXFCO1FBQ3JCLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxFQUFFLENBQUM7SUFDL0IsQ0FBQztJQUVELHFDQUFVLEdBQVY7UUFDSSxpQ0FBaUM7UUFDakMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUM7WUFDcEIsT0FBTyxFQUFFLFlBQVk7U0FDeEIsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQTVEWSxnQkFBZ0I7UUFONUIsZ0JBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxZQUFZO1lBQ3RCLFdBQVcsRUFBRSwwQkFBMEI7WUFDdkMsU0FBUyxFQUFFLENBQUMseUJBQXlCLENBQUM7WUFDdEMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1NBQ3BCLENBQUM7eUNBTXFDLGlDQUFlO09BTHpDLGdCQUFnQixDQThENUI7SUFBRCx1QkFBQztDQUFBLEFBOURELElBOERDO0FBOURZLDRDQUFnQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBSYWRTaWRlRHJhd2VyIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC11aS1zaWRlZHJhd2VyXCI7XG5pbXBvcnQgKiBhcyBhcHAgZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvYXBwbGljYXRpb25cIjtcbmltcG9ydCB7IEJpa2VQb29sU2VydmljZSB9IGZyb20gXCIuLi9zaGFyZWQvYmlrZXBvb2xzZXJ2aWNlXCI7XG5pbXBvcnQgeyBTZXJ2aWNlVVJMIH0gZnJvbSBcIi4uL3NoYXJlZC9zZXJ2aWNlc1wiO1xuaW1wb3J0ICogYXMgQXBwbGljYXRpb25TZXR0aW5ncyBmcm9tIFwiYXBwbGljYXRpb24tc2V0dGluZ3NcIjtcbmltcG9ydCB7IExvYWRpbmdTY3JlZW4gfSBmcm9tICduYXRpdmVzY3JpcHQtbG9hZGluZy1zY3JlZW4nO1xuXG5jbGFzcyBSaWRlSGlzdG9yeSB7XG4gIGNvbnN0cnVjdG9yKHB1YmxpYyBEcm9wTG9jYXRpb246IHN0cmluZywgcHVibGljIFBpY2tMb2NhdGlvbjogc3RyaW5nLCBwdWJsaWMgU3RhcnRUaW1lOiBzdHJpbmcsXG4gICAgcHVibGljIFZlaGljbGVUeXBlVGV4dDogc3RyaW5nLHB1YmxpYyByaWRlVGFrZW46c3RyaW5nKSB7IH1cbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbnMtbXlyaWRlcycsXG4gIHRlbXBsYXRlVXJsOiAnLi9teXJpZGVzLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vbXlyaWRlcy5jb21wb25lbnQuY3NzJ10sXG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXG59KVxuZXhwb3J0IGNsYXNzIE15cmlkZXNDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuXG4gIHB1YmxpYyByaWRlSGlzdG9yeUl0ZW06IEFycmF5PFJpZGVIaXN0b3J5PjtcbiAgcHJpdmF0ZSBsb2FkaW5nU2NyZWVuOiBMb2FkaW5nU2NyZWVuO1xuICBzaG93TG9hZGVyOiBib29sZWFuO1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGJpa2Vwb29sc2VydmljZTogQmlrZVBvb2xTZXJ2aWNlKSB7IH1cblxuICBuZ09uSW5pdCgpIHtcbiAgICB0aGlzLnJpZGVIaXN0b3J5SXRlbSA9IFtdO1xuICAgIHRoaXMubG9hZGluZ1NjcmVlbiA9IG5ldyBMb2FkaW5nU2NyZWVuKCk7XG4gICAgY29uc29sZS5sb2coQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJ1c2VyaWRcIikpO1xuICAgIHZhciBvYmpVc2VyID0geyB1c2VyaWQ6IEFwcGxpY2F0aW9uU2V0dGluZ3MuZ2V0U3RyaW5nKFwidXNlcmlkXCIpIH1cbiAgICB0aGlzLnNob3dMb2FkZXIgPSB0cnVlO1xuICAgIHRoaXMuTG9hZGVyU2hvdygpO1xuICAgIHRoaXMuYmlrZXBvb2xzZXJ2aWNlLlBvc3RTZXJ2aWNlKFNlcnZpY2VVUkwuR2V0TXlSaWRlLCBvYmpVc2VyKS5zdWJzY3JpYmUoXG4gICAgICBzdWNjZXNzID0+IHRoaXMucmlkZXJMaXN0KHN1Y2Nlc3MpLFxuICAgICAgZXJyb3IgPT4gdGhpcy5yaWRlckxpc3RFcnJvcihlcnJvcilcbiAgICApXG4gIH1cblxuICByaWRlckxpc3QocmlkZXJzKSB7XG4gICAgdGhpcy5zaG93TG9hZGVyID0gZmFsc2U7XG4gICAgdGhpcy5oaWRlTG9hZGVyKCk7XG4gICAgbGV0IG9ialJpZGVzID0gcmlkZXJzLnJpZGVzO1xuICAgIGNvbnNvbGUubG9nKG9ialJpZGVzKTtcbiAgICBpZiAob2JqUmlkZXMubGVuZ3RoID4gMCkge1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPD0gb2JqUmlkZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgbGV0IHJpZGVoaXN0b3J5ID0gbmV3IFJpZGVIaXN0b3J5KFxuICAgICAgICAgIG9ialJpZGVzW2ldLkRyb3BMb2NhdGlvbixcbiAgICAgICAgICBvYmpSaWRlc1tpXS5QaWNrTG9jYXRpb24sXG4gICAgICAgICAgb2JqUmlkZXNbaV0uU3RhcnRUaW1lLFxuICAgICAgICAgIG9ialJpZGVzW2ldLlZlaGljbGVUeXBlVGV4dCxcbiAgICAgICAgICBvYmpSaWRlc1tpXS5yaWRlVGFrZW4gPSAob2JqUmlkZXNbaV0ub2ZmZXJSaWRlID09IHRydWUpID8gXCJSaWRlIE9mZmVyZWRcIiA6IFwiUmlkZSBSZXF1ZXN0ZWRcIlxuICAgICAgICApXG4gICAgICAgIHRoaXMucmlkZUhpc3RvcnlJdGVtLnB1c2gocmlkZWhpc3RvcnkpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJpZGVyTGlzdEVycm9yKGVycm9yKSB7XG4gICAgdGhpcy5zaG93TG9hZGVyID0gZmFsc2U7XG4gICAgdGhpcy5oaWRlTG9hZGVyKCk7XG4gICAgY29uc29sZS5sb2coXCJlcnJvclwiICsgZXJyb3IpO1xuICB9XG5cbiAgb25EcmF3ZXJCdXR0b25UYXAoKTogdm9pZCB7XG4gICAgY29uc3Qgc2lkZURyYXdlciA9IDxSYWRTaWRlRHJhd2VyPmFwcC5nZXRSb290VmlldygpO1xuICAgIHNpZGVEcmF3ZXIuc2hvd0RyYXdlcigpO1xuICB9XG5cbmhpZGVMb2FkZXIoKSB7XG4gICAgLy90aGlzLmxvYWRlci5oaWRlKCk7XG4gICAgdGhpcy5sb2FkaW5nU2NyZWVuLmNsb3NlKCk7XG59XG5cbkxvYWRlclNob3coKSB7XG4gICAgLy90aGlzLmxvYWRlci5zaG93KHRoaXMub3B0aW9ucyk7XG4gICAgdGhpcy5sb2FkaW5nU2NyZWVuLnNob3coe1xuICAgICAgICBtZXNzYWdlOiBcIkxvYWRpbmcuLi5cIlxuICAgIH0pO1xufVxuXG59XG4iXX0=