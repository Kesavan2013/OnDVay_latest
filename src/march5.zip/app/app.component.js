"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var router_2 = require("nativescript-angular/router");
var nativescript_ui_sidedrawer_1 = require("nativescript-ui-sidedrawer");
var operators_1 = require("rxjs/operators");
var app = require("tns-core-modules/application");
var ApplicationSettings = require("application-settings");
var firebase = require("nativescript-plugin-firebase");
var bikepoolservice_1 = require("./shared/bikepoolservice");
var Connectivity = require("tns-core-modules/connectivity");
var dialogs_1 = require("tns-core-modules/ui/dialogs");
var AppComponent = /** @class */ (function () {
    function AppComponent(router, routerExtensions, bikepoolservice, zone) {
        this.router = router;
        this.routerExtensions = routerExtensions;
        this.bikepoolservice = bikepoolservice;
        this.zone = zone;
        this.appLoggedIn = false;
        // Use the component constructor to inject services.
    }
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._activatedUrl = "/home";
        this._sideDrawerTransition = new nativescript_ui_sidedrawer_1.SlideInOnTopTransition();
        //this.CheckInternetConnection();
        this.router.events
            .pipe(operators_1.filter(function (event) { return event instanceof router_1.NavigationEnd; }))
            .subscribe(function (event) { return _this.ActivateURL(event); });
        if (ApplicationSettings.getString("userid") != null) {
            this.loggedIn = true;
        }
        this.connectionType = this.connectionToString(Connectivity.getConnectionType());
        Connectivity.startMonitoring(function (connectionType) {
            _this.zone.run(function () {
                _this.connectionType = _this.connectionToString(connectionType);
                //Toast.makeText(this.connectionType,"20000");
                if (_this.connectionType != '') {
                    dialogs_1.alert({
                        title: "On d Vay",
                        message: _this.connectionType,
                        okButtonText: "Ok"
                    });
                }
            });
        });
    };
    AppComponent.prototype.connectionToString = function (connectionType) {
        switch (connectionType) {
            case Connectivity.connectionType.none:
                return "Please Check Your Internet Connection";
            // case Connectivity.connectionType.wifi:
            //     return "Connected to WiFi!";
            // case Connectivity.connectionType.mobile:
            //     return "Connected to Cellular!";
            default:
                return "";
        }
    };
    AppComponent.prototype.ActivateURL = function (event) {
        this._activatedUrl = event.urlAfterRedirects;
        if (ApplicationSettings.getString("userid") != null) {
            this.loggedIn = true;
            this.profileImage = ApplicationSettings.getString("profileImage");
            this.email = ApplicationSettings.getString("email");
            this.username = ApplicationSettings.getString("username");
        }
        else {
            this.loggedIn = false;
            this.username = "Welcome Guest!";
            this.email = "";
            ApplicationSettings.remove("profileImage");
            ApplicationSettings.remove("email");
            ApplicationSettings.remove("username");
        }
    };
    Object.defineProperty(AppComponent.prototype, "sideDrawerTransition", {
        get: function () {
            return this._sideDrawerTransition;
        },
        enumerable: true,
        configurable: true
    });
    AppComponent.prototype.isComponentSelected = function (url) {
        return this._activatedUrl === url;
    };
    AppComponent.prototype.onNavItemTap = function (navItemRoute) {
        this.routerExtensions.navigate([navItemRoute], {
            transition: {
                name: "fade"
            }
        });
        var sideDrawer = app.getRootView();
        sideDrawer.closeDrawer();
    };
    AppComponent.prototype.LogoutSuccess = function (success) {
        this.loggedIn = false;
        this.username = "Welcome Guest!";
        this.email = "";
        firebase.logout();
        this.routerExtensions.navigate(["signin"], {
            transition: {
                name: "fade"
            }
        });
    };
    AppComponent.prototype.LogoutError = function (error) {
    };
    AppComponent.prototype.Logout = function () {
        this.loggedIn = false;
        this.username = "Welcome Guest!";
        this.email = "";
        firebase.logout();
        this.routerExtensions.navigate(["signin"], {
            transition: {
                name: "fade"
            }
        });
        // var objUserId = {userid : ApplicationSettings.getString("userid")};
        // this.bikepoolservice.PostService(ServiceURL.DeleteLogOutUser,objUserId).subscribe(
        //     success => this.LogoutSuccess(success),
        //     error => this.LogoutError(error)
        // )
    };
    AppComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: "ns-app",
            templateUrl: "app.component.html"
        }),
        __metadata("design:paramtypes", [router_1.Router, router_2.RouterExtensions,
            bikepoolservice_1.BikePoolService, core_1.NgZone])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBcUU7QUFDckUsMENBQXdEO0FBQ3hELHNEQUErRDtBQUMvRCx5RUFBeUc7QUFDekcsNENBQXdDO0FBQ3hDLGtEQUFvRDtBQUNwRCwwREFBNEQ7QUFDNUQsSUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLDhCQUE4QixDQUFDLENBQUM7QUFFekQsNERBQTBEO0FBRTFELDREQUE4RDtBQUU5RCx1REFBNEQ7QUFPNUQ7SUFNSSxzQkFBb0IsTUFBYyxFQUFVLGdCQUFrQyxFQUNsRSxlQUErQixFQUFTLElBQVk7UUFENUMsV0FBTSxHQUFOLE1BQU0sQ0FBUTtRQUFVLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBa0I7UUFDbEUsb0JBQWUsR0FBZixlQUFlLENBQWdCO1FBQVMsU0FBSSxHQUFKLElBQUksQ0FBUTtRQUpoRSxnQkFBVyxHQUFZLEtBQUssQ0FBQztRQUt6QixvREFBb0Q7SUFDeEQsQ0FBQztJQUVELCtCQUFRLEdBQVI7UUFBQSxpQkEyQkM7UUExQkcsSUFBSSxDQUFDLGFBQWEsR0FBRyxPQUFPLENBQUM7UUFDN0IsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksbURBQXNCLEVBQUUsQ0FBQztRQUMxRCxpQ0FBaUM7UUFDakMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNO2FBQ2IsSUFBSSxDQUFDLGtCQUFNLENBQUMsVUFBQyxLQUFVLElBQUssT0FBQSxLQUFLLFlBQVksc0JBQWEsRUFBOUIsQ0FBOEIsQ0FBQyxDQUFDO2FBQzVELFNBQVMsQ0FBQyxVQUFDLEtBQW9CLElBQUssT0FBQSxLQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUF2QixDQUF1QixDQUFDLENBQUM7UUFFbEUsSUFBSSxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxFQUFFO1lBQ2pELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1NBQ3hCO1FBRUQsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQztRQUNoRixZQUFZLENBQUMsZUFBZSxDQUFDLFVBQUEsY0FBYztZQUN2QyxLQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztnQkFDVixLQUFJLENBQUMsY0FBYyxHQUFHLEtBQUksQ0FBQyxrQkFBa0IsQ0FBQyxjQUFjLENBQUMsQ0FBQztnQkFDOUQsOENBQThDO2dCQUM5QyxJQUFHLEtBQUksQ0FBQyxjQUFjLElBQUksRUFBRSxFQUM1QjtvQkFDSSxlQUFLLENBQUM7d0JBQ0YsS0FBSyxFQUFFLFVBQVU7d0JBQ2pCLE9BQU8sRUFBRSxLQUFJLENBQUMsY0FBYzt3QkFDNUIsWUFBWSxFQUFFLElBQUk7cUJBQ25CLENBQUMsQ0FBQTtpQkFDUDtZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU0seUNBQWtCLEdBQXpCLFVBQTBCLGNBQXNCO1FBQzVDLFFBQU8sY0FBYyxFQUFFO1lBQ25CLEtBQUssWUFBWSxDQUFDLGNBQWMsQ0FBQyxJQUFJO2dCQUNqQyxPQUFPLHVDQUF1QyxDQUFDO1lBQ25ELHlDQUF5QztZQUN6QyxtQ0FBbUM7WUFDbkMsMkNBQTJDO1lBQzNDLHVDQUF1QztZQUN2QztnQkFDSyxPQUFPLEVBQUUsQ0FBQztTQUNsQjtJQUNMLENBQUM7SUF3QkQsa0NBQVcsR0FBWCxVQUFZLEtBQW1CO1FBRTNCLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDLGlCQUFpQixDQUFDO1FBRTdDLElBQUcsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksRUFDbEQ7WUFDSSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztZQUNyQixJQUFJLENBQUMsWUFBWSxHQUFHLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUNsRSxJQUFJLENBQUMsS0FBSyxHQUFHLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNwRCxJQUFJLENBQUMsUUFBUSxHQUFHLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUM3RDthQUNHO1lBQ0EsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7WUFDdEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxnQkFBZ0IsQ0FBQztZQUNqQyxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztZQUVoQixtQkFBbUIsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDM0MsbUJBQW1CLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3BDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUMxQztJQUVMLENBQUM7SUFFRCxzQkFBSSw4Q0FBb0I7YUFBeEI7WUFDSSxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztRQUN0QyxDQUFDOzs7T0FBQTtJQUVELDBDQUFtQixHQUFuQixVQUFvQixHQUFXO1FBQzNCLE9BQU8sSUFBSSxDQUFDLGFBQWEsS0FBSyxHQUFHLENBQUM7SUFDdEMsQ0FBQztJQUVELG1DQUFZLEdBQVosVUFBYSxZQUFvQjtRQUM3QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUMsWUFBWSxDQUFDLEVBQUU7WUFDM0MsVUFBVSxFQUFFO2dCQUNSLElBQUksRUFBRSxNQUFNO2FBQ2Y7U0FDSixDQUFDLENBQUM7UUFFSCxJQUFNLFVBQVUsR0FBa0IsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3BELFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUM3QixDQUFDO0lBRUQsb0NBQWEsR0FBYixVQUFjLE9BQU87UUFFakIsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDdEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxnQkFBZ0IsQ0FBQztRQUNqQyxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNoQixRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3ZDLFVBQVUsRUFBRTtnQkFDUixJQUFJLEVBQUUsTUFBTTthQUNmO1NBQ0osQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELGtDQUFXLEdBQVgsVUFBWSxLQUFLO0lBR2pCLENBQUM7SUFFRCw2QkFBTSxHQUFOO1FBRUksSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDdEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxnQkFBZ0IsQ0FBQztRQUNqQyxJQUFJLENBQUMsS0FBSyxHQUFHLEVBQUUsQ0FBQztRQUNoQixRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDbEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ3ZDLFVBQVUsRUFBRTtnQkFDUixJQUFJLEVBQUUsTUFBTTthQUNmO1NBQ0osQ0FBQyxDQUFDO1FBRUgsc0VBQXNFO1FBQ3RFLHFGQUFxRjtRQUNyRiw4Q0FBOEM7UUFDOUMsdUNBQXVDO1FBQ3ZDLElBQUk7SUFDUixDQUFDO0lBeEpRLFlBQVk7UUFMeEIsZ0JBQVMsQ0FBQztZQUNQLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixRQUFRLEVBQUUsUUFBUTtZQUNsQixXQUFXLEVBQUUsb0JBQW9CO1NBQ3BDLENBQUM7eUNBTzhCLGVBQU0sRUFBNEIseUJBQWdCO1lBQ2xELGlDQUFlLEVBQWUsYUFBTTtPQVB2RCxZQUFZLENBeUp4QjtJQUFELG1CQUFDO0NBQUEsQUF6SkQsSUF5SkM7QUF6Slksb0NBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgVmlld0NoaWxkLE5nWm9uZSAgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgTmF2aWdhdGlvbkVuZCwgUm91dGVyIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuaW1wb3J0IHsgUm91dGVyRXh0ZW5zaW9ucyB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9yb3V0ZXJcIjtcbmltcG9ydCB7IERyYXdlclRyYW5zaXRpb25CYXNlLCBSYWRTaWRlRHJhd2VyLCBTbGlkZUluT25Ub3BUcmFuc2l0aW9uIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC11aS1zaWRlZHJhd2VyXCI7XG5pbXBvcnQgeyBmaWx0ZXIgfSBmcm9tIFwicnhqcy9vcGVyYXRvcnNcIjtcbmltcG9ydCAqIGFzIGFwcCBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9hcHBsaWNhdGlvblwiO1xuaW1wb3J0ICogYXMgQXBwbGljYXRpb25TZXR0aW5ncyBmcm9tIFwiYXBwbGljYXRpb24tc2V0dGluZ3NcIjtcbmNvbnN0IGZpcmViYXNlID0gcmVxdWlyZShcIm5hdGl2ZXNjcmlwdC1wbHVnaW4tZmlyZWJhc2VcIik7XG5pbXBvcnQgeyBjb25uZWN0aW9uVHlwZSwgZ2V0Q29ubmVjdGlvblR5cGUsIHN0YXJ0TW9uaXRvcmluZywgc3RvcE1vbml0b3JpbmcgfWZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL2Nvbm5lY3Rpdml0eVwiO1xuaW1wb3J0IHsgQmlrZVBvb2xTZXJ2aWNlfSBmcm9tIFwiLi9zaGFyZWQvYmlrZXBvb2xzZXJ2aWNlXCI7XG5pbXBvcnQgeyBTZXJ2aWNlVVJMIH0gZnJvbSBcIi4vc2hhcmVkL3NlcnZpY2VzXCI7XG5pbXBvcnQgKiBhcyBDb25uZWN0aXZpdHkgZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvY29ubmVjdGl2aXR5XCI7XG5pbXBvcnQgKiBhcyBUb2FzdCBmcm9tIFwibmF0aXZlc2NyaXB0LXRvYXN0XCI7XG5pbXBvcnQgeyBhbGVydCwgcHJvbXB0IH0gZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvdWkvZGlhbG9nc1wiO1xuXG5AQ29tcG9uZW50KHtcbiAgICBtb2R1bGVJZDogbW9kdWxlLmlkLFxuICAgIHNlbGVjdG9yOiBcIm5zLWFwcFwiLFxuICAgIHRlbXBsYXRlVXJsOiBcImFwcC5jb21wb25lbnQuaHRtbFwiXG59KVxuZXhwb3J0IGNsYXNzIEFwcENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgcHJpdmF0ZSBfYWN0aXZhdGVkVXJsOiBzdHJpbmc7XG4gICAgcHJpdmF0ZSBfc2lkZURyYXdlclRyYW5zaXRpb246IERyYXdlclRyYW5zaXRpb25CYXNlO1xuICAgIGFwcExvZ2dlZEluOiBib29sZWFuID0gZmFsc2U7XG4gICAgcHVibGljIGNvbm5lY3Rpb25UeXBlOiBzdHJpbmc7XG4gICAgXG4gICAgY29uc3RydWN0b3IocHJpdmF0ZSByb3V0ZXI6IFJvdXRlciwgcHJpdmF0ZSByb3V0ZXJFeHRlbnNpb25zOiBSb3V0ZXJFeHRlbnNpb25zLFxuICAgICAgICBwcml2YXRlIGJpa2Vwb29sc2VydmljZTpCaWtlUG9vbFNlcnZpY2UscHJpdmF0ZSB6b25lOiBOZ1pvbmUpIHtcbiAgICAgICAgLy8gVXNlIHRoZSBjb21wb25lbnQgY29uc3RydWN0b3IgdG8gaW5qZWN0IHNlcnZpY2VzLlxuICAgIH1cblxuICAgIG5nT25Jbml0KCk6IHZvaWQge1xuICAgICAgICB0aGlzLl9hY3RpdmF0ZWRVcmwgPSBcIi9ob21lXCI7XG4gICAgICAgIHRoaXMuX3NpZGVEcmF3ZXJUcmFuc2l0aW9uID0gbmV3IFNsaWRlSW5PblRvcFRyYW5zaXRpb24oKTtcbiAgICAgICAgLy90aGlzLkNoZWNrSW50ZXJuZXRDb25uZWN0aW9uKCk7XG4gICAgICAgIHRoaXMucm91dGVyLmV2ZW50c1xuICAgICAgICAgICAgLnBpcGUoZmlsdGVyKChldmVudDogYW55KSA9PiBldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpKVxuICAgICAgICAgICAgLnN1YnNjcmliZSgoZXZlbnQ6IE5hdmlnYXRpb25FbmQpID0+IHRoaXMuQWN0aXZhdGVVUkwoZXZlbnQpKTtcblxuICAgICAgICBpZiAoQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJ1c2VyaWRcIikgIT0gbnVsbCkge1xuICAgICAgICAgICAgdGhpcy5sb2dnZWRJbiA9IHRydWU7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLmNvbm5lY3Rpb25UeXBlID0gdGhpcy5jb25uZWN0aW9uVG9TdHJpbmcoQ29ubmVjdGl2aXR5LmdldENvbm5lY3Rpb25UeXBlKCkpO1xuICAgICAgICBDb25uZWN0aXZpdHkuc3RhcnRNb25pdG9yaW5nKGNvbm5lY3Rpb25UeXBlID0+IHtcbiAgICAgICAgICAgIHRoaXMuem9uZS5ydW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuY29ubmVjdGlvblR5cGUgPSB0aGlzLmNvbm5lY3Rpb25Ub1N0cmluZyhjb25uZWN0aW9uVHlwZSk7XG4gICAgICAgICAgICAgICAgLy9Ub2FzdC5tYWtlVGV4dCh0aGlzLmNvbm5lY3Rpb25UeXBlLFwiMjAwMDBcIik7XG4gICAgICAgICAgICAgICAgaWYodGhpcy5jb25uZWN0aW9uVHlwZSAhPSAnJylcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGFsZXJ0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBcIk9uIGQgVmF5XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiB0aGlzLmNvbm5lY3Rpb25UeXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgb2tCdXR0b25UZXh0OiBcIk9rXCJcbiAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwdWJsaWMgY29ubmVjdGlvblRvU3RyaW5nKGNvbm5lY3Rpb25UeXBlOiBudW1iZXIpOiBzdHJpbmcge1xuICAgICAgICBzd2l0Y2goY29ubmVjdGlvblR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgQ29ubmVjdGl2aXR5LmNvbm5lY3Rpb25UeXBlLm5vbmU6XG4gICAgICAgICAgICAgICAgcmV0dXJuIFwiUGxlYXNlIENoZWNrIFlvdXIgSW50ZXJuZXQgQ29ubmVjdGlvblwiO1xuICAgICAgICAgICAgLy8gY2FzZSBDb25uZWN0aXZpdHkuY29ubmVjdGlvblR5cGUud2lmaTpcbiAgICAgICAgICAgIC8vICAgICByZXR1cm4gXCJDb25uZWN0ZWQgdG8gV2lGaSFcIjtcbiAgICAgICAgICAgIC8vIGNhc2UgQ29ubmVjdGl2aXR5LmNvbm5lY3Rpb25UeXBlLm1vYmlsZTpcbiAgICAgICAgICAgIC8vICAgICByZXR1cm4gXCJDb25uZWN0ZWQgdG8gQ2VsbHVsYXIhXCI7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICByZXR1cm4gXCJcIjtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8vIENoZWNrSW50ZXJuZXRDb25uZWN0aW9uKCl7XG4gICAgLy8gICAgIGNvbm5lY3Rpdml0eU1vZHVsZS5zdGFydE1vbml0b3JpbmcoKG5ld0Nvbm5lY3Rpb25UeXBlKSA9PiB7XG4gICAgLy8gICAgICAgICBzd2l0Y2ggKG5ld0Nvbm5lY3Rpb25UeXBlKSB7XG4gICAgLy8gICAgICAgICAgICAgY2FzZSBjb25uZWN0aXZpdHlNb2R1bGUuY29ubmVjdGlvblR5cGUubm9uZTpcbiAgICAvLyAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDb25uZWN0aW9uIHR5cGUgY2hhbmdlZCB0byBub25lLlwiKTtcbiAgICAvLyAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgLy8gICAgICAgICAgICAgY2FzZSBjb25uZWN0aXZpdHlNb2R1bGUuY29ubmVjdGlvblR5cGUud2lmaTpcbiAgICAvLyAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJDb25uZWN0aW9uIHR5cGUgY2hhbmdlZCB0byBXaUZpLlwiKTtcbiAgICAvLyAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgLy8gICAgICAgICAgICAgY2FzZSBjb25uZWN0aXZpdHlNb2R1bGUuY29ubmVjdGlvblR5cGUubW9iaWxlOlxuICAgIC8vICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNvbm5lY3Rpb24gdHlwZSBjaGFuZ2VkIHRvIG1vYmlsZS5cIik7XG4gICAgLy8gICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgIC8vICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgLy8gICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgIC8vICAgICAgICAgfVxuICAgIC8vICAgICB9KTtcbiAgICAvLyB9XG5cbiAgICBwcm9maWxlSW1hZ2UgOiBhbnk7XG4gICAgdXNlcm5hbWUgOiBzdHJpbmc7XG4gICAgZW1haWwgOiBzdHJpbmc7XG4gICAgbG9nZ2VkSW4gOiBib29sZWFuO1xuICAgIEFjdGl2YXRlVVJMKGV2ZW50Ok5hdmlnYXRpb25FbmQpXG4gICAge1xuICAgICAgICB0aGlzLl9hY3RpdmF0ZWRVcmwgPSBldmVudC51cmxBZnRlclJlZGlyZWN0cztcblxuICAgICAgICBpZihBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcInVzZXJpZFwiKSAhPSBudWxsKVxuICAgICAgICB7XG4gICAgICAgICAgICB0aGlzLmxvZ2dlZEluID0gdHJ1ZTtcbiAgICAgICAgICAgIHRoaXMucHJvZmlsZUltYWdlID0gQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJwcm9maWxlSW1hZ2VcIik7XG4gICAgICAgICAgICB0aGlzLmVtYWlsID0gQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJlbWFpbFwiKTtcbiAgICAgICAgICAgIHRoaXMudXNlcm5hbWUgPSBBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcInVzZXJuYW1lXCIpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2V7XG4gICAgICAgICAgICB0aGlzLmxvZ2dlZEluID0gZmFsc2U7XG4gICAgICAgICAgICB0aGlzLnVzZXJuYW1lID0gXCJXZWxjb21lIEd1ZXN0IVwiO1xuICAgICAgICAgICAgdGhpcy5lbWFpbCA9IFwiXCI7XG5cbiAgICAgICAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3MucmVtb3ZlKFwicHJvZmlsZUltYWdlXCIpO1xuICAgICAgICAgICAgQXBwbGljYXRpb25TZXR0aW5ncy5yZW1vdmUoXCJlbWFpbFwiKTtcbiAgICAgICAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3MucmVtb3ZlKFwidXNlcm5hbWVcIik7XG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgfVxuXG4gICAgZ2V0IHNpZGVEcmF3ZXJUcmFuc2l0aW9uKCk6IERyYXdlclRyYW5zaXRpb25CYXNlIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NpZGVEcmF3ZXJUcmFuc2l0aW9uO1xuICAgIH1cblxuICAgIGlzQ29tcG9uZW50U2VsZWN0ZWQodXJsOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2FjdGl2YXRlZFVybCA9PT0gdXJsO1xuICAgIH1cblxuICAgIG9uTmF2SXRlbVRhcChuYXZJdGVtUm91dGU6IHN0cmluZyk6IHZvaWQge1xuICAgICAgICB0aGlzLnJvdXRlckV4dGVuc2lvbnMubmF2aWdhdGUoW25hdkl0ZW1Sb3V0ZV0sIHtcbiAgICAgICAgICAgIHRyYW5zaXRpb246IHtcbiAgICAgICAgICAgICAgICBuYW1lOiBcImZhZGVcIlxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICBjb25zdCBzaWRlRHJhd2VyID0gPFJhZFNpZGVEcmF3ZXI+YXBwLmdldFJvb3RWaWV3KCk7XG4gICAgICAgIHNpZGVEcmF3ZXIuY2xvc2VEcmF3ZXIoKTtcbiAgICB9XG5cbiAgICBMb2dvdXRTdWNjZXNzKHN1Y2Nlc3MpXG4gICAge1xuICAgICAgICB0aGlzLmxvZ2dlZEluID0gZmFsc2U7XG4gICAgICAgIHRoaXMudXNlcm5hbWUgPSBcIldlbGNvbWUgR3Vlc3QhXCI7XG4gICAgICAgIHRoaXMuZW1haWwgPSBcIlwiOyAgICAgICAgXG4gICAgICAgIGZpcmViYXNlLmxvZ291dCgpO1xuICAgICAgICB0aGlzLnJvdXRlckV4dGVuc2lvbnMubmF2aWdhdGUoW1wic2lnbmluXCJdLCB7XG4gICAgICAgICAgICB0cmFuc2l0aW9uOiB7XG4gICAgICAgICAgICAgICAgbmFtZTogXCJmYWRlXCJcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgTG9nb3V0RXJyb3IoZXJyb3IpXG4gICAge1xuXG4gICAgfVxuXG4gICAgTG9nb3V0KCkge1xuXG4gICAgICAgIHRoaXMubG9nZ2VkSW4gPSBmYWxzZTtcbiAgICAgICAgdGhpcy51c2VybmFtZSA9IFwiV2VsY29tZSBHdWVzdCFcIjtcbiAgICAgICAgdGhpcy5lbWFpbCA9IFwiXCI7ICAgICAgICBcbiAgICAgICAgZmlyZWJhc2UubG9nb3V0KCk7XG4gICAgICAgIHRoaXMucm91dGVyRXh0ZW5zaW9ucy5uYXZpZ2F0ZShbXCJzaWduaW5cIl0sIHtcbiAgICAgICAgICAgIHRyYW5zaXRpb246IHtcbiAgICAgICAgICAgICAgICBuYW1lOiBcImZhZGVcIlxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICAvLyB2YXIgb2JqVXNlcklkID0ge3VzZXJpZCA6IEFwcGxpY2F0aW9uU2V0dGluZ3MuZ2V0U3RyaW5nKFwidXNlcmlkXCIpfTtcbiAgICAgICAgLy8gdGhpcy5iaWtlcG9vbHNlcnZpY2UuUG9zdFNlcnZpY2UoU2VydmljZVVSTC5EZWxldGVMb2dPdXRVc2VyLG9ialVzZXJJZCkuc3Vic2NyaWJlKFxuICAgICAgICAvLyAgICAgc3VjY2VzcyA9PiB0aGlzLkxvZ291dFN1Y2Nlc3Moc3VjY2VzcyksXG4gICAgICAgIC8vICAgICBlcnJvciA9PiB0aGlzLkxvZ291dEVycm9yKGVycm9yKVxuICAgICAgICAvLyApXG4gICAgfVxufVxuIl19