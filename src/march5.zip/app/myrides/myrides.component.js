"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var app = require("tns-core-modules/application");
var bikepoolservice_1 = require("../shared/bikepoolservice");
var services_1 = require("../shared/services");
var ApplicationSettings = require("application-settings");
var RideHistory = /** @class */ (function () {
    function RideHistory(rideTime, rideDistance, rideFromLocation, rideToLocation) {
        this.rideTime = rideTime;
        this.rideDistance = rideDistance;
        this.rideFromLocation = rideFromLocation;
        this.rideToLocation = rideToLocation;
    }
    return RideHistory;
}());
var MyridesComponent = /** @class */ (function () {
    function MyridesComponent(bikepoolservice) {
        this.bikepoolservice = bikepoolservice;
    }
    MyridesComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.rideHistoryItem = [];
        var objUser = { userid: ApplicationSettings.getString("userid") };
        this.bikepoolservice.PostService(services_1.ServiceURL.GetMyRide, objUser).subscribe(function (success) { return _this.riderList(success); }, function (error) { return _this.riderListError(error); });
    };
    MyridesComponent.prototype.riderList = function (riders) {
        var objRides = riders.rides;
        for (var i = 0; i <= objRides.length; i++) {
            var ridehistory = new RideHistory(objRides[i].rideStartTime, objRides[i].rideDistance, objRides[i].rideFromLocation, objRides[i].rideToLocation);
            this.rideHistoryItem.push(ridehistory);
        }
    };
    MyridesComponent.prototype.riderListError = function (error) {
        console.log("error" + error);
    };
    MyridesComponent.prototype.onDrawerButtonTap = function () {
        var sideDrawer = app.getRootView();
        sideDrawer.showDrawer();
    };
    MyridesComponent = __decorate([
        core_1.Component({
            selector: 'ns-myrides',
            templateUrl: './myrides.component.html',
            styleUrls: ['./myrides.component.css'],
            moduleId: module.id,
        }),
        __metadata("design:paramtypes", [bikepoolservice_1.BikePoolService])
    ], MyridesComponent);
    return MyridesComponent;
}());
exports.MyridesComponent = MyridesComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXlyaWRlcy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJteXJpZGVzLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQUVsRCxrREFBb0Q7QUFDcEQsNkRBQTREO0FBQzVELCtDQUFnRDtBQUNoRCwwREFBNEQ7QUFFNUQ7SUFFRSxxQkFBbUIsUUFBZ0IsRUFBUyxZQUFvQixFQUFTLGdCQUF3QixFQUN4RixjQUFzQjtRQURaLGFBQVEsR0FBUixRQUFRLENBQVE7UUFBUyxpQkFBWSxHQUFaLFlBQVksQ0FBUTtRQUFTLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBUTtRQUN4RixtQkFBYyxHQUFkLGNBQWMsQ0FBUTtJQUFFLENBQUM7SUFDcEMsa0JBQUM7QUFBRCxDQUFDLEFBSkQsSUFJQztBQVFEO0lBR0UsMEJBQW9CLGVBQStCO1FBQS9CLG9CQUFlLEdBQWYsZUFBZSxDQUFnQjtJQUFJLENBQUM7SUFFeEQsbUNBQVEsR0FBUjtRQUFBLGlCQVFDO1FBUEMsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFDMUIsSUFBSSxPQUFPLEdBQUcsRUFBQyxNQUFNLEVBQUUsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxFQUFDLENBQUE7UUFFL0QsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxTQUFTLEVBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUN0RSxVQUFBLE9BQU8sSUFBSSxPQUFBLEtBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEVBQXZCLENBQXVCLEVBQ2xDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBMUIsQ0FBMEIsQ0FDcEMsQ0FBQTtJQUNILENBQUM7SUFFRCxvQ0FBUyxHQUFULFVBQVUsTUFBTTtRQUVkLElBQUksUUFBUSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFFNUIsS0FBSSxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxNQUFNLEVBQUMsQ0FBQyxFQUFFLEVBQ3ZDO1lBQ0ksSUFBSSxXQUFXLEdBQUcsSUFBSSxXQUFXLENBQy9CLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLEVBQ3pCLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLEVBQ3hCLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsRUFDNUIsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FDekIsQ0FBQTtZQUVELElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQzVDO0lBQ0gsQ0FBQztJQUVELHlDQUFjLEdBQWQsVUFBZSxLQUFLO1FBRWxCLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFFRCw0Q0FBaUIsR0FBakI7UUFDRSxJQUFNLFVBQVUsR0FBa0IsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3BELFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBeENVLGdCQUFnQjtRQU41QixnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLFlBQVk7WUFDdEIsV0FBVyxFQUFFLDBCQUEwQjtZQUN2QyxTQUFTLEVBQUUsQ0FBQyx5QkFBeUIsQ0FBQztZQUN0QyxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7U0FDcEIsQ0FBQzt5Q0FJb0MsaUNBQWU7T0FIeEMsZ0JBQWdCLENBMEM1QjtJQUFELHVCQUFDO0NBQUEsQUExQ0QsSUEwQ0M7QUExQ1ksNENBQWdCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFJhZFNpZGVEcmF3ZXIgfSBmcm9tIFwibmF0aXZlc2NyaXB0LXVpLXNpZGVkcmF3ZXJcIjtcbmltcG9ydCAqIGFzIGFwcCBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9hcHBsaWNhdGlvblwiO1xuaW1wb3J0IHsgQmlrZVBvb2xTZXJ2aWNlIH0gZnJvbSBcIi4uL3NoYXJlZC9iaWtlcG9vbHNlcnZpY2VcIjtcbmltcG9ydCB7IFNlcnZpY2VVUkwgfSBmcm9tIFwiLi4vc2hhcmVkL3NlcnZpY2VzXCI7XG5pbXBvcnQgKiBhcyBBcHBsaWNhdGlvblNldHRpbmdzIGZyb20gXCJhcHBsaWNhdGlvbi1zZXR0aW5nc1wiO1xuXG5jbGFzcyBSaWRlSGlzdG9yeVxue1xuICBjb25zdHJ1Y3RvcihwdWJsaWMgcmlkZVRpbWU6IHN0cmluZywgcHVibGljIHJpZGVEaXN0YW5jZTogc3RyaW5nLCBwdWJsaWMgcmlkZUZyb21Mb2NhdGlvbjogc3RyaW5nLFxuICAgIHB1YmxpYyByaWRlVG9Mb2NhdGlvbjogc3RyaW5nKXt9XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ25zLW15cmlkZXMnLFxuICB0ZW1wbGF0ZVVybDogJy4vbXlyaWRlcy5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL215cmlkZXMuY29tcG9uZW50LmNzcyddLFxuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxufSlcbmV4cG9ydCBjbGFzcyBNeXJpZGVzQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcblxuICBwdWJsaWMgcmlkZUhpc3RvcnlJdGVtIDogQXJyYXk8UmlkZUhpc3Rvcnk+O1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGJpa2Vwb29sc2VydmljZTpCaWtlUG9vbFNlcnZpY2UpIHsgfVxuXG4gIG5nT25Jbml0KCkge1xuICAgIHRoaXMucmlkZUhpc3RvcnlJdGVtID0gW107XG4gICAgdmFyIG9ialVzZXIgPSB7dXNlcmlkIDpBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcInVzZXJpZFwiKX1cbiAgICBcbiAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLkdldE15UmlkZSxvYmpVc2VyKS5zdWJzY3JpYmUoXG4gICAgICBzdWNjZXNzID0+IHRoaXMucmlkZXJMaXN0KHN1Y2Nlc3MpLFxuICAgICAgZXJyb3IgPT4gdGhpcy5yaWRlckxpc3RFcnJvcihlcnJvcilcbiAgICApXG4gIH1cblxuICByaWRlckxpc3QocmlkZXJzKVxuICB7XG4gICAgbGV0IG9ialJpZGVzID0gcmlkZXJzLnJpZGVzO1xuXG4gICAgZm9yKGxldCBpID0gMDsgaSA8PSBvYmpSaWRlcy5sZW5ndGg7aSsrKVxuICAgIHtcbiAgICAgICAgbGV0IHJpZGVoaXN0b3J5ID0gbmV3IFJpZGVIaXN0b3J5KFxuICAgICAgICAgIG9ialJpZGVzW2ldLnJpZGVTdGFydFRpbWUsXG4gICAgICAgICAgb2JqUmlkZXNbaV0ucmlkZURpc3RhbmNlLFxuICAgICAgICAgIG9ialJpZGVzW2ldLnJpZGVGcm9tTG9jYXRpb24sXG4gICAgICAgICAgb2JqUmlkZXNbaV0ucmlkZVRvTG9jYXRpb25cbiAgICAgICAgICApXG5cbiAgICAgICAgICB0aGlzLnJpZGVIaXN0b3J5SXRlbS5wdXNoKHJpZGVoaXN0b3J5KTtcbiAgICB9XG4gIH1cblxuICByaWRlckxpc3RFcnJvcihlcnJvcilcbiAge1xuICAgIGNvbnNvbGUubG9nKFwiZXJyb3JcIiArIGVycm9yKTtcbiAgfVxuXG4gIG9uRHJhd2VyQnV0dG9uVGFwKCk6IHZvaWQge1xuICAgIGNvbnN0IHNpZGVEcmF3ZXIgPSA8UmFkU2lkZURyYXdlcj5hcHAuZ2V0Um9vdFZpZXcoKTtcbiAgICBzaWRlRHJhd2VyLnNob3dEcmF3ZXIoKTtcbiAgfVxuXG59XG4iXX0=