"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var ServiceURL;
(function (ServiceURL) {
    ServiceURL[ServiceURL["searchLocation"] = 1] = "searchLocation";
    ServiceURL["RideStatus"] = "/RideStatus";
    ServiceURL["UpdateUserLocation"] = "RideUpdateUserLocation";
    ServiceURL["RequestForRide"] = "/RequestForRide";
    ServiceURL["GetMyRide"] = "/GetMyRide";
    ServiceURL["RideUsers"] = "/RideUsers";
    ServiceURL["ResetPassword"] = "/ResetPassword";
    ServiceURL["CreateWithSocialLogin"] = "/CreateWithSocialLogin";
    ServiceURL["SignUpOnDVay"] = "/SignInWithUserPwd";
    ServiceURL["Login"] = "/SignIn";
    ServiceURL["DeleteLogOutUser"] = "/DeleteLogOutUser";
    ServiceURL["RideUpdateUserLocation"] = "/RideUpdateUserLocation";
})(ServiceURL = exports.ServiceURL || (exports.ServiceURL = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJzZXJ2aWNlcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLElBQVksVUFhWDtBQWJELFdBQVksVUFBVTtJQUNsQiwrREFBa0IsQ0FBQTtJQUNsQix3Q0FBMEIsQ0FBQTtJQUMxQiwyREFBNkMsQ0FBQTtJQUM3QyxnREFBa0MsQ0FBQTtJQUNsQyxzQ0FBd0IsQ0FBQTtJQUN4QixzQ0FBd0IsQ0FBQTtJQUN4Qiw4Q0FBZ0MsQ0FBQTtJQUNoQyw4REFBZ0QsQ0FBQTtJQUNoRCxpREFBbUMsQ0FBQTtJQUNuQywrQkFBaUIsQ0FBQTtJQUNqQixvREFBc0MsQ0FBQTtJQUN0QyxnRUFBa0QsQ0FBQTtBQUN0RCxDQUFDLEVBYlcsVUFBVSxHQUFWLGtCQUFVLEtBQVYsa0JBQVUsUUFhckIiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZW51bSBTZXJ2aWNlVVJMIHtcclxuICAgIHNlYXJjaExvY2F0aW9uID0gMSxcclxuICAgIFJpZGVTdGF0dXMgPSBcIi9SaWRlU3RhdHVzXCIsXHJcbiAgICBVcGRhdGVVc2VyTG9jYXRpb24gPSBcIlJpZGVVcGRhdGVVc2VyTG9jYXRpb25cIixcclxuICAgIFJlcXVlc3RGb3JSaWRlID0gXCIvUmVxdWVzdEZvclJpZGVcIiwgICAgXHJcbiAgICBHZXRNeVJpZGUgPSBcIi9HZXRNeVJpZGVcIixcclxuICAgIFJpZGVVc2VycyA9IFwiL1JpZGVVc2Vyc1wiLFxyXG4gICAgUmVzZXRQYXNzd29yZCA9IFwiL1Jlc2V0UGFzc3dvcmRcIixcclxuICAgIENyZWF0ZVdpdGhTb2NpYWxMb2dpbiA9IFwiL0NyZWF0ZVdpdGhTb2NpYWxMb2dpblwiLFxyXG4gICAgU2lnblVwT25EVmF5ID0gXCIvU2lnbkluV2l0aFVzZXJQd2RcIixcclxuICAgIExvZ2luID0gXCIvU2lnbkluXCIsXHJcbiAgICBEZWxldGVMb2dPdXRVc2VyID0gXCIvRGVsZXRlTG9nT3V0VXNlclwiLFxyXG4gICAgUmlkZVVwZGF0ZVVzZXJMb2NhdGlvbiA9IFwiL1JpZGVVcGRhdGVVc2VyTG9jYXRpb25cIlxyXG59Il19