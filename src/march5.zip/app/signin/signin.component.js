"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var dialogs_1 = require("tns-core-modules/ui/dialogs");
var app = require("tns-core-modules/application");
var ApplicationSettings = require("application-settings");
var firebase = require("nativescript-plugin-firebase");
var router_1 = require("nativescript-angular/router");
var bikepoolservice_1 = require("../shared/bikepoolservice");
var services_1 = require("../shared/services");
var User = /** @class */ (function () {
    function User() {
    }
    return User;
}());
exports.User = User;
var SigninComponent = /** @class */ (function () {
    function SigninComponent(routerExtensions, bikepoolservice) {
        this.routerExtensions = routerExtensions;
        this.bikepoolservice = bikepoolservice;
        this.isLoggingIn = false;
        this.isAuthenticating = false;
        this.selectedIndex = 1;
    }
    SigninComponent.prototype.ngOnInit = function () {
        this.isLoggingIn = false;
        this.user = new User();
    };
    SigninComponent.prototype.toggleForm = function () {
        this.isLoggingIn = !this.isLoggingIn;
    };
    SigninComponent.prototype.signUpSuccess = function (success) {
        console.log("loginsuccess" + success);
        this.isLoggingIn = true;
    };
    SigninComponent.prototype.signUpError = function (error) {
        console.log("loginsuccess" + error);
        this.isAuthenticating = false;
    };
    SigninComponent.prototype.loginSuccess = function (success) {
        var user = success.data.user;
        ApplicationSettings.setString("email", user.email);
        ApplicationSettings.setString("userid", user.uid);
        this.navigateHome();
    };
    SigninComponent.prototype.loginError = function (error) {
    };
    SigninComponent.prototype.submit = function () {
        var _this = this;
        // Normal Signup on d vay    
        if (this.isLoggingIn == false) {
            this.isAuthenticating = true;
            this.isLoggingIn = true;
            var objLogin_1 = {
                username: this.user.username,
                email: this.user.email,
                password: this.user.password,
                deviceToken: ApplicationSettings.getString("device_token")
            };
            this.bikepoolservice.PostService(services_1.ServiceURL.SignUpOnDVay, objLogin_1).subscribe(function (success) { return _this.signUpSuccess(success); }, function (error) { return _this.signUpError(error); });
        }
        else {
            // normal login on d vay
            var objLogin = { email: this.user.email, password: this.user.password };
            this.bikepoolservice.PostService(services_1.ServiceURL.Login, objLogin).subscribe(function (success) { return _this.loginSuccess(success); }, function (error) { return _this.loginError(error); });
        }
    };
    SigninComponent.prototype.onDrawerButtonTap = function () {
        var sideDrawer = app.getRootView();
        sideDrawer.showDrawer();
    };
    SigninComponent.prototype.googleresult = function (result) {
        var _this = this;
        this.isLoggingIn = true;
        ApplicationSettings.setString("profileImage", result.profileImageURL);
        ApplicationSettings.setString("email", result.email);
        ApplicationSettings.setString("username", result.name);
        var objGoogleLogin = {
            userid: result.uid,
            deviceToken: ApplicationSettings.getString("device_token"),
            username: result.name,
            email: result.email,
            profilePhoto: result.profileImageURL
        };
        this.bikepoolservice.PostService(services_1.ServiceURL.CreateWithSocialLogin, objGoogleLogin).subscribe(function (user) { return _this.createusersuccess(user); }, function (error) { return _this.createusererror(error); });
    };
    SigninComponent.prototype.createusersuccess = function (user) {
        console.log("createusersuccess" + user);
        this.navigateHome();
    };
    SigninComponent.prototype.createusererror = function (error) {
        console.log("createusererror" + error);
    };
    SigninComponent.prototype.googleerror = function (error) {
        console.log(error);
    };
    SigninComponent.prototype.submitGoogle = function () {
        var _this = this;
        firebase.login({ type: firebase.LoginType.GOOGLE }).
            then(function (googleresult) { return _this.googleresult(googleresult); }, function (googleerror) { return _this.googleerror(googleerror); });
    };
    SigninComponent.prototype.fbresult = function (success) {
        var _this = this;
        this.isLoggingIn = true;
        ApplicationSettings.setString("profileImage", success.profileImageURL);
        ApplicationSettings.setString("email", success.email);
        ApplicationSettings.setString("username", success.name);
        var objFBLogin = {
            userid: success.uid,
            deviceToken: ApplicationSettings.getString("device_token"),
            username: success.name,
            email: success.email,
            profilePhoto: success.profileImageURL
        };
        this.bikepoolservice.PostService(services_1.ServiceURL.CreateWithSocialLogin, objFBLogin).subscribe(function (user) { return _this.createusersuccess(user); }, function (error) { return _this.createusererror(error); });
    };
    SigninComponent.prototype.fberror = function (error) {
        var formatErrorMessage = error.replace('com.google.firebase.auth.FirebaseAuthUserCollisionException:', "");
        dialogs_1.alert({
            title: "On d Vay",
            message: formatErrorMessage,
            okButtonText: "Ok"
        });
    };
    SigninComponent.prototype.submitFB = function () {
        var _this = this;
        firebase.login({ type: firebase.LoginType.FACEBOOK,
            facebookOptions: {
                scope: ['public_profile', 'email']
            }
        })
            .then(function (success) { return _this.fbresult(success); }, function (error) { return _this.fberror(error); });
    };
    SigninComponent.prototype.onchange = function (args) {
        console.log("Drop Down selected index changed from " + args.oldIndex + " to " + args.newIndex);
    };
    SigninComponent.prototype.onopen = function () {
        console.log("Drop Down opened.");
    };
    SigninComponent.prototype.onclose = function () {
        console.log("Drop Down closed.");
    };
    SigninComponent.prototype.navigateHome = function () {
        this.routerExtensions.navigate(["home"], {
            transition: {
                name: "fade"
            }
        });
    };
    SigninComponent.prototype.successForgotPwd = function (success) {
        console.log(success);
        dialogs_1.alert({
            title: "On d Vay",
            message: "Your password was successfully reset. Please check your email for instructions on choosing a new password.",
            okButtonText: "Ok"
        });
    };
    SigninComponent.prototype.errorForgotPwd = function (error) {
        console.log(error);
    };
    SigninComponent.prototype.forgotPassword = function () {
        var _this = this;
        dialogs_1.prompt({
            title: "Forgot Password",
            message: "Enter the email address you used to register for On d Vay to reset your password.",
            defaultText: "",
            okButtonText: "Ok",
            cancelButtonText: "Cancel"
        }).then(function (data) {
            if (data.result) {
                // Call the backend to reset the password
                var objemail = { emailAddress: data.text.toString().trim() };
                _this.bikepoolservice.PostService(services_1.ServiceURL.ResetPassword, objemail).subscribe(function (success) { return _this.successForgotPwd(success); }, function (error) { return _this.errorForgotPwd(error); });
            }
        });
    };
    SigninComponent = __decorate([
        core_1.Component({
            selector: 'SignIn',
            templateUrl: './signin.component.html',
            styleUrls: ['./signin.component.css'],
            moduleId: module.id
        }),
        __metadata("design:paramtypes", [router_1.RouterExtensions,
            bikepoolservice_1.BikePoolService])
    ], SigninComponent);
    return SigninComponent;
}());
exports.SigninComponent = SigninComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2lnbmluLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInNpZ25pbi5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxzQ0FBb0c7QUFDcEcsdURBQTREO0FBSTVELGtEQUFvRDtBQUNwRCwwREFBNEQ7QUFDNUQsSUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLDhCQUE4QixDQUFDLENBQUM7QUFDekQsc0RBQStEO0FBQy9ELDZEQUEwRDtBQUMxRCwrQ0FBK0M7QUFFL0M7SUFBQTtJQU1BLENBQUM7SUFBRCxXQUFDO0FBQUQsQ0FBQyxBQU5ELElBTUM7QUFOWSxvQkFBSTtBQWNqQjtJQVdFLHlCQUFvQixnQkFBa0MsRUFDNUMsZUFBK0I7UUFEckIscUJBQWdCLEdBQWhCLGdCQUFnQixDQUFrQjtRQUM1QyxvQkFBZSxHQUFmLGVBQWUsQ0FBZ0I7UUFUekMsZ0JBQVcsR0FBRyxLQUFLLENBQUM7UUFDcEIscUJBQWdCLEdBQUcsS0FBSyxDQUFDO1FBRWxCLGtCQUFhLEdBQUcsQ0FBQyxDQUFDO0lBT3pCLENBQUM7SUFFRCxrQ0FBUSxHQUFSO1FBQ0UsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7UUFDekIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFRCxvQ0FBVSxHQUFWO1FBQ0UsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7SUFDdkMsQ0FBQztJQUVELHVDQUFhLEdBQWIsVUFBYyxPQUFPO1FBRW5CLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxHQUFHLE9BQU8sQ0FBQyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO0lBQzFCLENBQUM7SUFFRCxxQ0FBVyxHQUFYLFVBQVksS0FBSztRQUVmLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUM7SUFDaEMsQ0FBQztJQUVELHNDQUFZLEdBQVosVUFBYSxPQUFPO1FBRWxCLElBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQzdCLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2xELG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2pELElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQsb0NBQVUsR0FBVixVQUFXLEtBQUs7SUFHaEIsQ0FBQztJQUVELGdDQUFNLEdBQU47UUFBQSxpQkEyQkM7UUExQkMsNkJBQTZCO1FBQzdCLElBQUcsSUFBSSxDQUFDLFdBQVcsSUFBSSxLQUFLLEVBQzVCO1lBQ0UsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztZQUM3QixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztZQUV4QixJQUFJLFVBQVEsR0FBQztnQkFDWCxRQUFRLEVBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRO2dCQUM3QixLQUFLLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLO2dCQUN0QixRQUFRLEVBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRO2dCQUMzQixXQUFXLEVBQUUsbUJBQW1CLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQzthQUMzRCxDQUFBO1lBQ0QsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxZQUFZLEVBQUMsVUFBUSxDQUFDLENBQUMsU0FBUyxDQUMxRSxVQUFBLE9BQU8sSUFBSSxPQUFBLEtBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEVBQTNCLENBQTJCLEVBQ3RDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBdkIsQ0FBdUIsQ0FDakMsQ0FBQTtTQUNGO2FBRUQ7WUFDRSx3QkFBd0I7WUFDeEIsSUFBSSxRQUFRLEdBQUcsRUFBQyxLQUFLLEVBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUMsUUFBUSxFQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFDLENBQUM7WUFDbkUsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxLQUFLLEVBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUNuRSxVQUFBLE9BQU8sSUFBSSxPQUFBLEtBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLEVBQTFCLENBQTBCLEVBQ3JDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsRUFBdEIsQ0FBc0IsQ0FDaEMsQ0FBQTtTQUNGO0lBQ0gsQ0FBQztJQUVELDJDQUFpQixHQUFqQjtRQUNFLElBQU0sVUFBVSxHQUFrQixHQUFHLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEQsVUFBVSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFRCxzQ0FBWSxHQUFaLFVBQWEsTUFBTTtRQUFuQixpQkFvQkM7UUFsQkMsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7UUFFeEIsbUJBQW1CLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBQyxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDckUsbUJBQW1CLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDcEQsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFdEQsSUFBSSxjQUFjLEdBQUc7WUFDbkIsTUFBTSxFQUFFLE1BQU0sQ0FBQyxHQUFHO1lBQ2xCLFdBQVcsRUFBRyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDO1lBQzNELFFBQVEsRUFBRyxNQUFNLENBQUMsSUFBSTtZQUN0QixLQUFLLEVBQUcsTUFBTSxDQUFDLEtBQUs7WUFDcEIsWUFBWSxFQUFHLE1BQU0sQ0FBQyxlQUFlO1NBQ3RDLENBQUE7UUFFRCxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxxQkFBVSxDQUFDLHFCQUFxQixFQUFDLGNBQWMsQ0FBQyxDQUFDLFNBQVMsQ0FDekYsVUFBQSxJQUFJLElBQUksT0FBQSxLQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLEVBQTVCLENBQTRCLEVBQ3BDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsRUFBM0IsQ0FBMkIsQ0FDckMsQ0FBQTtJQUNILENBQUM7SUFFRCwyQ0FBaUIsR0FBakIsVUFBa0IsSUFBSTtRQUVwQixPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQseUNBQWUsR0FBZixVQUFnQixLQUFLO1FBRW5CLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDLENBQUM7SUFDekMsQ0FBQztJQUdELHFDQUFXLEdBQVgsVUFBWSxLQUFLO1FBRWYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNyQixDQUFDO0lBRUQsc0NBQVksR0FBWjtRQUFBLGlCQUlDO1FBSEMsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFDLElBQUksRUFBQyxRQUFRLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBQyxDQUFDO1lBQ2hELElBQUksQ0FBQyxVQUFBLFlBQVksSUFBSSxPQUFBLEtBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLEVBQS9CLENBQStCLEVBQ3BELFVBQUEsV0FBVyxJQUFJLE9BQUEsS0FBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsRUFBN0IsQ0FBNkIsQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFFRCxrQ0FBUSxHQUFSLFVBQVMsT0FBTztRQUFoQixpQkFvQkM7UUFsQkMsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7UUFFdEIsbUJBQW1CLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDdEUsbUJBQW1CLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDckQsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFdkQsSUFBSSxVQUFVLEdBQUc7WUFDZixNQUFNLEVBQUUsT0FBTyxDQUFDLEdBQUc7WUFDbkIsV0FBVyxFQUFHLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUM7WUFDM0QsUUFBUSxFQUFHLE9BQU8sQ0FBQyxJQUFJO1lBQ3ZCLEtBQUssRUFBRyxPQUFPLENBQUMsS0FBSztZQUNyQixZQUFZLEVBQUcsT0FBTyxDQUFDLGVBQWU7U0FDdkMsQ0FBQTtRQUVELElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLHFCQUFVLENBQUMscUJBQXFCLEVBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUNyRixVQUFBLElBQUksSUFBSSxPQUFBLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsRUFBNUIsQ0FBNEIsRUFDcEMsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxFQUEzQixDQUEyQixDQUNyQyxDQUFBO0lBQ0wsQ0FBQztJQUVELGlDQUFPLEdBQVAsVUFBUSxLQUFLO1FBRVgsSUFBSSxrQkFBa0IsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLDhEQUE4RCxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzNHLGVBQUssQ0FBQztZQUNKLEtBQUssRUFBRSxVQUFVO1lBQ2pCLE9BQU8sRUFBRSxrQkFBa0I7WUFDM0IsWUFBWSxFQUFFLElBQUk7U0FDbkIsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVELGtDQUFRLEdBQVI7UUFBQSxpQkFVQztRQVRDLFFBQVEsQ0FBQyxLQUFLLENBQUMsRUFBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxRQUFRO1lBQy9DLGVBQWUsRUFBQztnQkFDZCxLQUFLLEVBQUcsQ0FBQyxnQkFBZ0IsRUFBQyxPQUFPLENBQUM7YUFDbkM7U0FDRixDQUFDO2FBQ0QsSUFBSSxDQUNILFVBQUEsT0FBTyxJQUFJLE9BQUEsS0FBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBdEIsQ0FBc0IsRUFDakMsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFuQixDQUFtQixDQUM3QixDQUFBO0lBQ0gsQ0FBQztJQUVNLGtDQUFRLEdBQWYsVUFBZ0IsSUFBbUM7UUFDakQsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQ0FBeUMsSUFBSSxDQUFDLFFBQVEsWUFBTyxJQUFJLENBQUMsUUFBVSxDQUFDLENBQUM7SUFDNUYsQ0FBQztJQUVNLGdDQUFNLEdBQWI7UUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUVNLGlDQUFPLEdBQWQ7UUFDRSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUVELHNDQUFZLEdBQVo7UUFDRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDdkMsVUFBVSxFQUFFO2dCQUNWLElBQUksRUFBRSxNQUFNO2FBQ2I7U0FDRixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsMENBQWdCLEdBQWhCLFVBQWlCLE9BQU87UUFFdEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNyQixlQUFLLENBQUM7WUFDSixLQUFLLEVBQUUsVUFBVTtZQUNqQixPQUFPLEVBQUUsNEdBQTRHO1lBQ3JILFlBQVksRUFBRSxJQUFJO1NBQ25CLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCx3Q0FBYyxHQUFkLFVBQWUsS0FBSztRQUVsQixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3JCLENBQUM7SUFFRCx3Q0FBYyxHQUFkO1FBQUEsaUJBaUJDO1FBaEJDLGdCQUFNLENBQUM7WUFDTCxLQUFLLEVBQUUsaUJBQWlCO1lBQ3hCLE9BQU8sRUFBRSxtRkFBbUY7WUFDNUYsV0FBVyxFQUFFLEVBQUU7WUFDZixZQUFZLEVBQUUsSUFBSTtZQUNsQixnQkFBZ0IsRUFBRSxRQUFRO1NBQzNCLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQyxJQUFJO1lBQ1gsSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFO2dCQUNmLHlDQUF5QztnQkFDekMsSUFBSSxRQUFRLEdBQUcsRUFBQyxZQUFZLEVBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxJQUFJLEVBQUUsRUFBQyxDQUFBO2dCQUMzRCxLQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxxQkFBVSxDQUFDLGFBQWEsRUFBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQzNFLFVBQUEsT0FBTyxJQUFJLE9BQUEsS0FBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxFQUE5QixDQUE4QixFQUN6QyxVQUFBLEtBQUssSUFBSSxPQUFBLEtBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLEVBQTFCLENBQTBCLENBQ3BDLENBQUE7YUFDRjtRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQWhPVSxlQUFlO1FBTjNCLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsUUFBUTtZQUNsQixXQUFXLEVBQUUseUJBQXlCO1lBQ3RDLFNBQVMsRUFBRSxDQUFDLHdCQUF3QixDQUFDO1lBQ3JDLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtTQUNwQixDQUFDO3lDQVlzQyx5QkFBZ0I7WUFDNUIsaUNBQWU7T0FaOUIsZUFBZSxDQWtPM0I7SUFBRCxzQkFBQztDQUFBLEFBbE9ELElBa09DO0FBbE9ZLDBDQUFlIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIEluamVjdGFibGUsIFZpZXdDaGlsZCxOZ1pvbmUsRG9DaGVjaywgRWxlbWVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xyXG5pbXBvcnQgeyBhbGVydCwgcHJvbXB0IH0gZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvdWkvZGlhbG9nc1wiO1xyXG5pbXBvcnQgeyBSYWRTaWRlRHJhd2VyIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC11aS1zaWRlZHJhd2VyXCI7XHJcblxyXG5pbXBvcnQgeyBTZWxlY3RlZEluZGV4Q2hhbmdlZEV2ZW50RGF0YSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtZHJvcC1kb3duXCI7XHJcbmltcG9ydCAqIGFzIGFwcCBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9hcHBsaWNhdGlvblwiO1xyXG5pbXBvcnQgKiBhcyBBcHBsaWNhdGlvblNldHRpbmdzIGZyb20gXCJhcHBsaWNhdGlvbi1zZXR0aW5nc1wiO1xyXG5jb25zdCBmaXJlYmFzZSA9IHJlcXVpcmUoXCJuYXRpdmVzY3JpcHQtcGx1Z2luLWZpcmViYXNlXCIpO1xyXG5pbXBvcnQgeyBSb3V0ZXJFeHRlbnNpb25zIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL3JvdXRlclwiO1xyXG5pbXBvcnQgeyBCaWtlUG9vbFNlcnZpY2V9IGZyb20gXCIuLi9zaGFyZWQvYmlrZXBvb2xzZXJ2aWNlXCJcclxuaW1wb3J0IHsgU2VydmljZVVSTCB9IGZyb20gXCIuLi9zaGFyZWQvc2VydmljZXNcIlxyXG5cclxuZXhwb3J0IGNsYXNzIFVzZXIge1xyXG4gIHVzZXJuYW1lOiBzdHJpbmdcclxuICBwYXNzd29yZDogc3RyaW5nXHJcbiAgY29uZmlybXBhc3N3b3JkOiBzdHJpbmdcclxuICBlbWFpbDogc3RyaW5nO1xyXG4gIGRldmljZVRva2VuOiBzdHJpbmc7XHJcbn1cclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiAnU2lnbkluJyxcclxuICB0ZW1wbGF0ZVVybDogJy4vc2lnbmluLmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnLi9zaWduaW4uY29tcG9uZW50LmNzcyddLFxyXG4gIG1vZHVsZUlkOiBtb2R1bGUuaWRcclxufSlcclxuZXhwb3J0IGNsYXNzIFNpZ25pbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcblxyXG4gIHRlc3Q6IHN0cmluZztcclxuICBpc0xvZ2dpbmdJbiA9IGZhbHNlO1xyXG4gIGlzQXV0aGVudGljYXRpbmcgPSBmYWxzZTtcclxuICBwdWJsaWMgaW5wdXQ6IGFueTtcclxuICBwdWJsaWMgc2VsZWN0ZWRJbmRleCA9IDE7XHJcbiAgcHVibGljIGl0ZW1zOiBBcnJheTxzdHJpbmc+O1xyXG4gIHB1YmxpYyBiaWtlczogQXJyYXk8c3RyaW5nPjtcclxuICBwdWJsaWMgdXNlcjogVXNlcjtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSByb3V0ZXJFeHRlbnNpb25zOiBSb3V0ZXJFeHRlbnNpb25zLFxyXG4gICAgcHJpdmF0ZSBiaWtlcG9vbHNlcnZpY2U6QmlrZVBvb2xTZXJ2aWNlKSB7XHJcbiAgfVxyXG5cclxuICBuZ09uSW5pdCgpIHtcclxuICAgIHRoaXMuaXNMb2dnaW5nSW4gPSBmYWxzZTtcclxuICAgIHRoaXMudXNlciA9IG5ldyBVc2VyKCk7XHJcbiAgfVxyXG5cclxuICB0b2dnbGVGb3JtKCkge1xyXG4gICAgdGhpcy5pc0xvZ2dpbmdJbiA9ICF0aGlzLmlzTG9nZ2luZ0luO1xyXG4gIH1cclxuXHJcbiAgc2lnblVwU3VjY2VzcyhzdWNjZXNzKVxyXG4gIHtcclxuICAgIGNvbnNvbGUubG9nKFwibG9naW5zdWNjZXNzXCIgKyBzdWNjZXNzKTtcclxuICAgIHRoaXMuaXNMb2dnaW5nSW4gPSB0cnVlO1xyXG4gIH1cclxuXHJcbiAgc2lnblVwRXJyb3IoZXJyb3IpXHJcbiAge1xyXG4gICAgY29uc29sZS5sb2coXCJsb2dpbnN1Y2Nlc3NcIiArIGVycm9yKTtcclxuICAgIHRoaXMuaXNBdXRoZW50aWNhdGluZyA9IGZhbHNlO1xyXG4gIH1cclxuXHJcbiAgbG9naW5TdWNjZXNzKHN1Y2Nlc3MpXHJcbiAge1xyXG4gICAgbGV0IHVzZXIgPSBzdWNjZXNzLmRhdGEudXNlcjtcclxuICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwiZW1haWxcIix1c2VyLmVtYWlsKTtcclxuICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwidXNlcmlkXCIsdXNlci51aWQpOyAgICBcclxuICAgIHRoaXMubmF2aWdhdGVIb21lKCk7XHJcbiAgfVxyXG5cclxuICBsb2dpbkVycm9yKGVycm9yKVxyXG4gIHtcclxuXHJcbiAgfVxyXG5cclxuICBzdWJtaXQoKSB7XHJcbiAgICAvLyBOb3JtYWwgU2lnbnVwIG9uIGQgdmF5ICAgIFxyXG4gICAgaWYodGhpcy5pc0xvZ2dpbmdJbiA9PSBmYWxzZSlcclxuICAgIHtcclxuICAgICAgdGhpcy5pc0F1dGhlbnRpY2F0aW5nID0gdHJ1ZTtcclxuICAgICAgdGhpcy5pc0xvZ2dpbmdJbiA9IHRydWU7ICAgIFxyXG4gIFxyXG4gICAgICBsZXQgb2JqTG9naW49e1xyXG4gICAgICAgIHVzZXJuYW1lIDogdGhpcy51c2VyLnVzZXJuYW1lICxcclxuICAgICAgICBlbWFpbDogdGhpcy51c2VyLmVtYWlsLFxyXG4gICAgICAgIHBhc3N3b3JkOnRoaXMudXNlci5wYXNzd29yZCxcclxuICAgICAgICBkZXZpY2VUb2tlbjogQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJkZXZpY2VfdG9rZW5cIilcclxuICAgICAgfVxyXG4gICAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLlNpZ25VcE9uRFZheSxvYmpMb2dpbikuc3Vic2NyaWJlKFxyXG4gICAgICAgIHN1Y2Nlc3MgPT4gdGhpcy5zaWduVXBTdWNjZXNzKHN1Y2Nlc3MpLFxyXG4gICAgICAgIGVycm9yID0+IHRoaXMuc2lnblVwRXJyb3IoZXJyb3IpXHJcbiAgICAgIClcclxuICAgIH1cclxuICAgIGVsc2VcclxuICAgIHtcclxuICAgICAgLy8gbm9ybWFsIGxvZ2luIG9uIGQgdmF5XHJcbiAgICAgIHZhciBvYmpMb2dpbiA9IHtlbWFpbDp0aGlzLnVzZXIuZW1haWwscGFzc3dvcmQ6dGhpcy51c2VyLnBhc3N3b3JkfTtcclxuICAgICAgdGhpcy5iaWtlcG9vbHNlcnZpY2UuUG9zdFNlcnZpY2UoU2VydmljZVVSTC5Mb2dpbixvYmpMb2dpbikuc3Vic2NyaWJlKFxyXG4gICAgICAgIHN1Y2Nlc3MgPT4gdGhpcy5sb2dpblN1Y2Nlc3Moc3VjY2VzcyksXHJcbiAgICAgICAgZXJyb3IgPT4gdGhpcy5sb2dpbkVycm9yKGVycm9yKVxyXG4gICAgICApXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBvbkRyYXdlckJ1dHRvblRhcCgpOiB2b2lkIHtcclxuICAgIGNvbnN0IHNpZGVEcmF3ZXIgPSA8UmFkU2lkZURyYXdlcj5hcHAuZ2V0Um9vdFZpZXcoKTtcclxuICAgIHNpZGVEcmF3ZXIuc2hvd0RyYXdlcigpO1xyXG4gIH1cclxuXHJcbiAgZ29vZ2xlcmVzdWx0KHJlc3VsdClcclxuICB7XHJcbiAgICB0aGlzLmlzTG9nZ2luZ0luID0gdHJ1ZTtcclxuXHJcbiAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcInByb2ZpbGVJbWFnZVwiLHJlc3VsdC5wcm9maWxlSW1hZ2VVUkwpO1xyXG4gICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJlbWFpbFwiLHJlc3VsdC5lbWFpbCk7XHJcbiAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcInVzZXJuYW1lXCIscmVzdWx0Lm5hbWUpO1xyXG5cclxuICAgIGxldCBvYmpHb29nbGVMb2dpbiA9IHtcclxuICAgICAgdXNlcmlkIDpyZXN1bHQudWlkLFxyXG4gICAgICBkZXZpY2VUb2tlbiA6IEFwcGxpY2F0aW9uU2V0dGluZ3MuZ2V0U3RyaW5nKFwiZGV2aWNlX3Rva2VuXCIpLFxyXG4gICAgICB1c2VybmFtZSA6IHJlc3VsdC5uYW1lLFxyXG4gICAgICBlbWFpbCA6IHJlc3VsdC5lbWFpbCxcclxuICAgICAgcHJvZmlsZVBob3RvIDogcmVzdWx0LnByb2ZpbGVJbWFnZVVSTFxyXG4gICAgfVxyXG5cclxuICAgIHRoaXMuYmlrZXBvb2xzZXJ2aWNlLlBvc3RTZXJ2aWNlKFNlcnZpY2VVUkwuQ3JlYXRlV2l0aFNvY2lhbExvZ2luLG9iakdvb2dsZUxvZ2luKS5zdWJzY3JpYmUoXHJcbiAgICAgIHVzZXIgPT4gdGhpcy5jcmVhdGV1c2Vyc3VjY2Vzcyh1c2VyKSxcclxuICAgICAgZXJyb3IgPT4gdGhpcy5jcmVhdGV1c2VyZXJyb3IoZXJyb3IpXHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBjcmVhdGV1c2Vyc3VjY2Vzcyh1c2VyKVxyXG4gIHtcclxuICAgIGNvbnNvbGUubG9nKFwiY3JlYXRldXNlcnN1Y2Nlc3NcIiArIHVzZXIpO1xyXG4gICAgdGhpcy5uYXZpZ2F0ZUhvbWUoKTtcclxuICB9XHJcblxyXG4gIGNyZWF0ZXVzZXJlcnJvcihlcnJvcilcclxuICB7XHJcbiAgICBjb25zb2xlLmxvZyhcImNyZWF0ZXVzZXJlcnJvclwiICsgZXJyb3IpOyAgICBcclxuICB9XHJcblxyXG4gIFxyXG4gIGdvb2dsZWVycm9yKGVycm9yKVxyXG4gIHtcclxuICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICB9XHJcblxyXG4gIHN1Ym1pdEdvb2dsZSgpIHtcclxuICAgIGZpcmViYXNlLmxvZ2luKHt0eXBlOmZpcmViYXNlLkxvZ2luVHlwZS5HT09HTEV9KS5cclxuICAgIHRoZW4oZ29vZ2xlcmVzdWx0ID0+IHRoaXMuZ29vZ2xlcmVzdWx0KGdvb2dsZXJlc3VsdCksXHJcbiAgICBnb29nbGVlcnJvciA9PiB0aGlzLmdvb2dsZWVycm9yKGdvb2dsZWVycm9yKSk7XHJcbiAgfVxyXG5cclxuICBmYnJlc3VsdChzdWNjZXNzKVxyXG4gIHtcclxuICAgIHRoaXMuaXNMb2dnaW5nSW4gPSB0cnVlOyAgICBcclxuICAgIFxyXG4gICAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcInByb2ZpbGVJbWFnZVwiLHN1Y2Nlc3MucHJvZmlsZUltYWdlVVJMKTtcclxuICAgICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJlbWFpbFwiLHN1Y2Nlc3MuZW1haWwpO1xyXG4gICAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcInVzZXJuYW1lXCIsc3VjY2Vzcy5uYW1lKTtcclxuICBcclxuICAgICAgbGV0IG9iakZCTG9naW4gPSB7XHJcbiAgICAgICAgdXNlcmlkIDpzdWNjZXNzLnVpZCxcclxuICAgICAgICBkZXZpY2VUb2tlbiA6IEFwcGxpY2F0aW9uU2V0dGluZ3MuZ2V0U3RyaW5nKFwiZGV2aWNlX3Rva2VuXCIpLFxyXG4gICAgICAgIHVzZXJuYW1lIDogc3VjY2Vzcy5uYW1lLFxyXG4gICAgICAgIGVtYWlsIDogc3VjY2Vzcy5lbWFpbCxcclxuICAgICAgICBwcm9maWxlUGhvdG8gOiBzdWNjZXNzLnByb2ZpbGVJbWFnZVVSTFxyXG4gICAgICB9XHJcbiAgXHJcbiAgICAgIHRoaXMuYmlrZXBvb2xzZXJ2aWNlLlBvc3RTZXJ2aWNlKFNlcnZpY2VVUkwuQ3JlYXRlV2l0aFNvY2lhbExvZ2luLG9iakZCTG9naW4pLnN1YnNjcmliZShcclxuICAgICAgICB1c2VyID0+IHRoaXMuY3JlYXRldXNlcnN1Y2Nlc3ModXNlciksXHJcbiAgICAgICAgZXJyb3IgPT4gdGhpcy5jcmVhdGV1c2VyZXJyb3IoZXJyb3IpXHJcbiAgICAgIClcclxuICB9XHJcblxyXG4gIGZiZXJyb3IoZXJyb3IpXHJcbiAge1xyXG4gICAgbGV0IGZvcm1hdEVycm9yTWVzc2FnZSA9IGVycm9yLnJlcGxhY2UoJ2NvbS5nb29nbGUuZmlyZWJhc2UuYXV0aC5GaXJlYmFzZUF1dGhVc2VyQ29sbGlzaW9uRXhjZXB0aW9uOicsIFwiXCIpO1xyXG4gICAgYWxlcnQoe1xyXG4gICAgICB0aXRsZTogXCJPbiBkIFZheVwiLFxyXG4gICAgICBtZXNzYWdlOiBmb3JtYXRFcnJvck1lc3NhZ2UsXHJcbiAgICAgIG9rQnV0dG9uVGV4dDogXCJPa1wiXHJcbiAgICB9KVxyXG4gIH1cclxuXHJcbiAgc3VibWl0RkIoKSB7XHJcbiAgICBmaXJlYmFzZS5sb2dpbih7dHlwZSA6ZmlyZWJhc2UuTG9naW5UeXBlLkZBQ0VCT09LLCBcclxuICAgICAgZmFjZWJvb2tPcHRpb25zOntcclxuICAgICAgICBzY29wZSA6IFsncHVibGljX3Byb2ZpbGUnLCdlbWFpbCddXHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgICAudGhlbihcclxuICAgICAgc3VjY2VzcyA9PiB0aGlzLmZicmVzdWx0KHN1Y2Nlc3MpLFxyXG4gICAgICBlcnJvciA9PiB0aGlzLmZiZXJyb3IoZXJyb3IpXHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBwdWJsaWMgb25jaGFuZ2UoYXJnczogU2VsZWN0ZWRJbmRleENoYW5nZWRFdmVudERhdGEpIHtcclxuICAgIGNvbnNvbGUubG9nKGBEcm9wIERvd24gc2VsZWN0ZWQgaW5kZXggY2hhbmdlZCBmcm9tICR7YXJncy5vbGRJbmRleH0gdG8gJHthcmdzLm5ld0luZGV4fWApO1xyXG4gIH1cclxuXHJcbiAgcHVibGljIG9ub3BlbigpIHtcclxuICAgIGNvbnNvbGUubG9nKFwiRHJvcCBEb3duIG9wZW5lZC5cIik7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgb25jbG9zZSgpIHtcclxuICAgIGNvbnNvbGUubG9nKFwiRHJvcCBEb3duIGNsb3NlZC5cIik7XHJcbiAgfVxyXG5cclxuICBuYXZpZ2F0ZUhvbWUoKSA6IGFueSB7XHJcbiAgICB0aGlzLnJvdXRlckV4dGVuc2lvbnMubmF2aWdhdGUoW1wiaG9tZVwiXSwge1xyXG4gICAgICB0cmFuc2l0aW9uOiB7XHJcbiAgICAgICAgbmFtZTogXCJmYWRlXCJcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBzdWNjZXNzRm9yZ290UHdkKHN1Y2Nlc3MpXHJcbiAge1xyXG4gICAgY29uc29sZS5sb2coc3VjY2Vzcyk7XHJcbiAgICBhbGVydCh7XHJcbiAgICAgIHRpdGxlOiBcIk9uIGQgVmF5XCIsXHJcbiAgICAgIG1lc3NhZ2U6IFwiWW91ciBwYXNzd29yZCB3YXMgc3VjY2Vzc2Z1bGx5IHJlc2V0LiBQbGVhc2UgY2hlY2sgeW91ciBlbWFpbCBmb3IgaW5zdHJ1Y3Rpb25zIG9uIGNob29zaW5nIGEgbmV3IHBhc3N3b3JkLlwiLFxyXG4gICAgICBva0J1dHRvblRleHQ6IFwiT2tcIlxyXG4gICAgfSlcclxuICB9XHJcblxyXG4gIGVycm9yRm9yZ290UHdkKGVycm9yKVxyXG4gIHtcclxuICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICB9XHJcblxyXG4gIGZvcmdvdFBhc3N3b3JkKCkge1xyXG4gICAgcHJvbXB0KHtcclxuICAgICAgdGl0bGU6IFwiRm9yZ290IFBhc3N3b3JkXCIsXHJcbiAgICAgIG1lc3NhZ2U6IFwiRW50ZXIgdGhlIGVtYWlsIGFkZHJlc3MgeW91IHVzZWQgdG8gcmVnaXN0ZXIgZm9yIE9uIGQgVmF5IHRvIHJlc2V0IHlvdXIgcGFzc3dvcmQuXCIsXHJcbiAgICAgIGRlZmF1bHRUZXh0OiBcIlwiLFxyXG4gICAgICBva0J1dHRvblRleHQ6IFwiT2tcIixcclxuICAgICAgY2FuY2VsQnV0dG9uVGV4dDogXCJDYW5jZWxcIlxyXG4gICAgfSkudGhlbigoZGF0YSkgPT4ge1xyXG4gICAgICBpZiAoZGF0YS5yZXN1bHQpIHsgICAgICAgIFxyXG4gICAgICAgIC8vIENhbGwgdGhlIGJhY2tlbmQgdG8gcmVzZXQgdGhlIHBhc3N3b3JkXHJcbiAgICAgICAgdmFyIG9iamVtYWlsID0ge2VtYWlsQWRkcmVzcyA6IGRhdGEudGV4dC50b1N0cmluZygpLnRyaW0oKX1cclxuICAgICAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLlJlc2V0UGFzc3dvcmQsb2JqZW1haWwpLnN1YnNjcmliZShcclxuICAgICAgICAgIHN1Y2Nlc3MgPT4gdGhpcy5zdWNjZXNzRm9yZ290UHdkKHN1Y2Nlc3MpLFxyXG4gICAgICAgICAgZXJyb3IgPT4gdGhpcy5lcnJvckZvcmdvdFB3ZChlcnJvcilcclxuICAgICAgICApXHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbn1cclxuIl19