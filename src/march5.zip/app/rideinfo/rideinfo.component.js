"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var bikepoolservice_1 = require("../shared/bikepoolservice");
var services_1 = require("../shared/services");
var RideInfo = /** @class */ (function () {
    function RideInfo() {
    }
    return RideInfo;
}());
exports.RideInfo = RideInfo;
var RideInfoComponent = /** @class */ (function () {
    function RideInfoComponent(route, bikepoolservice) {
        var _this = this;
        this.route = route;
        this.bikepoolservice = bikepoolservice;
        this.route.queryParams.subscribe(function (params) {
            var notification = params["objNotificationMessage"];
            _this.rideInfo = new RideInfo();
            var objNotification = JSON.parse(notification);
            _this.rideInfo.RideFromLocation = objNotification.rideLocation;
            _this.rideInfo.RideToLocation = objNotification.destinationLocation;
            _this.rideInfo.RideDistance = objNotification.rideDistance;
            _this.rideInfo.RidePickUpTime = objNotification.rideStartTime;
            _this.rideInfo.RideStatus = objNotification.ridestatus;
            _this.rideInfo.RideFromDeviceToken = objNotification.device_token;
            if (objNotification.phoneNo != undefined) {
                _this.rideInfo.RideContactNo = objNotification.phoneNo;
                console.log("RideContactno" + _this.rideInfo.RideContactNo);
            }
            else {
                _this.rideInfo.riderContactNo = '';
            }
            console.log("status" + _this.rideInfo.riderContactNo);
        });
    }
    RideInfoComponent.prototype.ngOnInit = function () {
    };
    RideInfoComponent.prototype.GetRideInformation = function (status) {
        var objdeviceToken = [];
        objdeviceToken.push({ deviceToken: this.rideInfo.RideFromDeviceToken });
        console.log("Phoneno" + this.rideInfo.riderContactNo);
        var objRideStatus = {
            deviceToken: objdeviceToken,
            requestStatus: status,
            currentLocation: this.rideInfo.RideFromLocation,
            destinationLocation: this.rideInfo.RideToLocation,
            phoneNo: this.rideInfo.riderContactNo
        };
        return objRideStatus;
    };
    RideInfoComponent.prototype.onAccept = function () {
        var objRide = this.GetRideInformation(1);
        this.bikepoolservice.PostService(services_1.ServiceURL.RideStatus, objRide).subscribe(function (ride) { return console.log("success" + JSON.stringify(ride)); }, function (error) { return console.log("error" + error); });
    };
    RideInfoComponent.prototype.OnCancel = function () {
        var objRide = this.GetRideInformation(0);
        this.bikepoolservice.PostService(services_1.ServiceURL.RideStatus, objRide).subscribe(function (ride) { return console.log(ride); }, function (error) { return console.log(error); });
    };
    RideInfoComponent = __decorate([
        core_1.Component({
            selector: 'ns-rideinfo',
            templateUrl: './rideinfo.component.html',
            moduleId: module.id,
        }),
        __metadata("design:paramtypes", [router_1.ActivatedRoute, bikepoolservice_1.BikePoolService])
    ], RideInfoComponent);
    return RideInfoComponent;
}());
exports.RideInfoComponent = RideInfoComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmlkZWluZm8uY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsicmlkZWluZm8uY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsc0NBQWtEO0FBQ2xELDBDQUFpRDtBQUNqRCw2REFBMkQ7QUFDM0QsK0NBQStDO0FBRS9DO0lBQUE7SUFTQSxDQUFDO0lBQUQsZUFBQztBQUFELENBQUMsQUFURCxJQVNDO0FBVFksNEJBQVE7QUFnQnJCO0lBSUUsMkJBQW9CLEtBQXFCLEVBQVMsZUFBK0I7UUFBakYsaUJBdUJDO1FBdkJtQixVQUFLLEdBQUwsS0FBSyxDQUFnQjtRQUFTLG9CQUFlLEdBQWYsZUFBZSxDQUFnQjtRQUMvRSxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsVUFBQSxNQUFNO1lBQ3JDLElBQUksWUFBWSxHQUFHLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1lBRXBELEtBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxRQUFRLEVBQUUsQ0FBQztZQUUvQixJQUFJLGVBQWUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQy9DLEtBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLEdBQUcsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUM5RCxLQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsR0FBRyxlQUFlLENBQUMsbUJBQW1CLENBQUM7WUFDbkUsS0FBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEdBQUcsZUFBZSxDQUFDLFlBQVksQ0FBQztZQUMxRCxLQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsR0FBRyxlQUFlLENBQUMsYUFBYSxDQUFDO1lBQzdELEtBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxHQUFHLGVBQWUsQ0FBQyxVQUFVLENBQUM7WUFDdEQsS0FBSSxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsR0FBRyxlQUFlLENBQUMsWUFBWSxDQUFDO1lBQ2pFLElBQUcsZUFBZSxDQUFDLE9BQU8sSUFBSSxTQUFTLEVBQ3ZDO2dCQUNFLEtBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxHQUFHLGVBQWUsQ0FBQyxPQUFPLENBQUM7Z0JBQ3RELE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxHQUFHLEtBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUM7YUFDNUQ7aUJBQ0c7Z0JBQ0YsS0FBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO2FBQ25DO1lBQ0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEdBQUcsS0FBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUN2RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxvQ0FBUSxHQUFSO0lBQ0EsQ0FBQztJQUVELDhDQUFrQixHQUFsQixVQUFtQixNQUFNO1FBRXZCLElBQUksY0FBYyxHQUFHLEVBQUUsQ0FBQztRQUN4QixjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUMsV0FBVyxFQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsbUJBQW1CLEVBQUMsQ0FBQyxDQUFBO1FBRXRFLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDdEQsSUFBSSxhQUFhLEdBQUc7WUFDbEIsV0FBVyxFQUFHLGNBQWM7WUFDNUIsYUFBYSxFQUFHLE1BQU07WUFDdEIsZUFBZSxFQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCO1lBQ2hELG1CQUFtQixFQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYztZQUNsRCxPQUFPLEVBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjO1NBQ3ZDLENBQUE7UUFFRCxPQUFPLGFBQWEsQ0FBQztJQUN2QixDQUFDO0lBRUQsb0NBQVEsR0FBUjtRQUVFLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV6QyxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxxQkFBVSxDQUFDLFVBQVUsRUFBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQ3ZFLFVBQUEsSUFBSSxJQUFJLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUE3QyxDQUE2QyxFQUNyRCxVQUFBLEtBQUssSUFBSSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxFQUE1QixDQUE0QixDQUN0QyxDQUFBO0lBQ0gsQ0FBQztJQUVELG9DQUFRLEdBQVI7UUFDRSxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFckMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxVQUFVLEVBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUN2RSxVQUFBLElBQUksSUFBSSxPQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQWpCLENBQWlCLEVBQ3pCLFVBQUEsS0FBSyxJQUFJLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBbEIsQ0FBa0IsQ0FDNUIsQ0FBQTtJQUNQLENBQUM7SUFsRVUsaUJBQWlCO1FBTDdCLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsYUFBYTtZQUN2QixXQUFXLEVBQUUsMkJBQTJCO1lBQ3hDLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtTQUNwQixDQUFDO3lDQUsyQix1QkFBYyxFQUF5QixpQ0FBZTtPQUp0RSxpQkFBaUIsQ0FvRTdCO0lBQUQsd0JBQUM7Q0FBQSxBQXBFRCxJQW9FQztBQXBFWSw4Q0FBaUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQWN0aXZhdGVkUm91dGUgfSBmcm9tIFwiQGFuZ3VsYXIvcm91dGVyXCI7XG5pbXBvcnQgeyBCaWtlUG9vbFNlcnZpY2V9IGZyb20gXCIuLi9zaGFyZWQvYmlrZXBvb2xzZXJ2aWNlXCI7XG5pbXBvcnQgeyBTZXJ2aWNlVVJMIH0gZnJvbSBcIi4uL3NoYXJlZC9zZXJ2aWNlc1wiXG5cbmV4cG9ydCBjbGFzcyBSaWRlSW5mb3tcbiAgUmlkZUZyb21Mb2NhdGlvbjogc3RyaW5nXG4gIFJpZGVUb0xvY2F0aW9uOiBzdHJpbmdcbiAgUmlkZURpc3RhbmNlOiBzdHJpbmdcbiAgUmlkZVBpY2tVcFRpbWU6IHN0cmluZ1xuICBSaWRlU3RhdHVzIDogc3RyaW5nXG4gIFJpZGVGcm9tRGV2aWNlVG9rZW4gOiBzdHJpbmdcbiAgUmlkZUNvbnRhY3RObyA6IHN0cmluZ1xuICByaWRlckNvbnRhY3RObyA6IGFueVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICducy1yaWRlaW5mbycsXG4gIHRlbXBsYXRlVXJsOiAnLi9yaWRlaW5mby5jb21wb25lbnQuaHRtbCcsXG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXG59KVxuZXhwb3J0IGNsYXNzIFJpZGVJbmZvQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcblxuICBwdWJsaWMgcmlkZUluZm8gOiBSaWRlSW5mbztcblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJvdXRlOiBBY3RpdmF0ZWRSb3V0ZSxwcml2YXRlIGJpa2Vwb29sc2VydmljZTpCaWtlUG9vbFNlcnZpY2UpIHtcbiAgICB0aGlzLnJvdXRlLnF1ZXJ5UGFyYW1zLnN1YnNjcmliZShwYXJhbXMgPT4ge1xuICAgICAgbGV0IG5vdGlmaWNhdGlvbiA9IHBhcmFtc1tcIm9iak5vdGlmaWNhdGlvbk1lc3NhZ2VcIl07XG5cbiAgICAgIHRoaXMucmlkZUluZm8gPSBuZXcgUmlkZUluZm8oKTtcbiAgICAgIFxuICAgICAgdmFyIG9iak5vdGlmaWNhdGlvbiA9IEpTT04ucGFyc2Uobm90aWZpY2F0aW9uKTtcbiAgICAgIHRoaXMucmlkZUluZm8uUmlkZUZyb21Mb2NhdGlvbiA9IG9iak5vdGlmaWNhdGlvbi5yaWRlTG9jYXRpb247XG4gICAgICB0aGlzLnJpZGVJbmZvLlJpZGVUb0xvY2F0aW9uID0gb2JqTm90aWZpY2F0aW9uLmRlc3RpbmF0aW9uTG9jYXRpb247XG4gICAgICB0aGlzLnJpZGVJbmZvLlJpZGVEaXN0YW5jZSA9IG9iak5vdGlmaWNhdGlvbi5yaWRlRGlzdGFuY2U7XG4gICAgICB0aGlzLnJpZGVJbmZvLlJpZGVQaWNrVXBUaW1lID0gb2JqTm90aWZpY2F0aW9uLnJpZGVTdGFydFRpbWU7ICAgXG4gICAgICB0aGlzLnJpZGVJbmZvLlJpZGVTdGF0dXMgPSBvYmpOb3RpZmljYXRpb24ucmlkZXN0YXR1czsgICBcbiAgICAgIHRoaXMucmlkZUluZm8uUmlkZUZyb21EZXZpY2VUb2tlbiA9IG9iak5vdGlmaWNhdGlvbi5kZXZpY2VfdG9rZW47XG4gICAgICBpZihvYmpOb3RpZmljYXRpb24ucGhvbmVObyAhPSB1bmRlZmluZWQpXG4gICAgICB7XG4gICAgICAgIHRoaXMucmlkZUluZm8uUmlkZUNvbnRhY3RObyA9IG9iak5vdGlmaWNhdGlvbi5waG9uZU5vO1xuICAgICAgICBjb25zb2xlLmxvZyhcIlJpZGVDb250YWN0bm9cIiArIHRoaXMucmlkZUluZm8uUmlkZUNvbnRhY3RObyk7XG4gICAgICB9XG4gICAgICBlbHNle1xuICAgICAgICB0aGlzLnJpZGVJbmZvLnJpZGVyQ29udGFjdE5vID0gJyc7XG4gICAgICB9XG4gICAgICBjb25zb2xlLmxvZyhcInN0YXR1c1wiICsgdGhpcy5yaWRlSW5mby5yaWRlckNvbnRhY3RObyk7XG4gICAgfSk7XG4gIH1cblxuICBuZ09uSW5pdCgpIHtcbiAgfVxuXG4gIEdldFJpZGVJbmZvcm1hdGlvbihzdGF0dXMpIDogYW55XG4gIHtcbiAgICB2YXIgb2JqZGV2aWNlVG9rZW4gPSBbXTtcbiAgICBvYmpkZXZpY2VUb2tlbi5wdXNoKHtkZXZpY2VUb2tlbiA6IHRoaXMucmlkZUluZm8uUmlkZUZyb21EZXZpY2VUb2tlbn0pXG5cbiAgICBjb25zb2xlLmxvZyhcIlBob25lbm9cIiArIHRoaXMucmlkZUluZm8ucmlkZXJDb250YWN0Tm8pO1xuICAgIHZhciBvYmpSaWRlU3RhdHVzID0ge1xuICAgICAgZGV2aWNlVG9rZW4gOiBvYmpkZXZpY2VUb2tlbixcbiAgICAgIHJlcXVlc3RTdGF0dXMgOiBzdGF0dXMsXG4gICAgICBjdXJyZW50TG9jYXRpb24gOiB0aGlzLnJpZGVJbmZvLlJpZGVGcm9tTG9jYXRpb24sXG4gICAgICBkZXN0aW5hdGlvbkxvY2F0aW9uIDogdGhpcy5yaWRlSW5mby5SaWRlVG9Mb2NhdGlvbixcbiAgICAgIHBob25lTm8gOiB0aGlzLnJpZGVJbmZvLnJpZGVyQ29udGFjdE5vXG4gICAgfVxuXG4gICAgcmV0dXJuIG9ialJpZGVTdGF0dXM7XG4gIH1cblxuICBvbkFjY2VwdCgpe1xuICAgIFxuICAgIHZhciBvYmpSaWRlID0gdGhpcy5HZXRSaWRlSW5mb3JtYXRpb24oMSk7XG5cbiAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLlJpZGVTdGF0dXMsb2JqUmlkZSkuc3Vic2NyaWJlKFxuICAgICAgcmlkZSA9PiBjb25zb2xlLmxvZyhcInN1Y2Nlc3NcIiArIEpTT04uc3RyaW5naWZ5KHJpZGUpKSxcbiAgICAgIGVycm9yID0+IGNvbnNvbGUubG9nKFwiZXJyb3JcIiArIGVycm9yKVxuICAgIClcbiAgfVxuXG4gIE9uQ2FuY2VsKCl7XG4gICAgdmFyIG9ialJpZGUgPSB0aGlzLkdldFJpZGVJbmZvcm1hdGlvbigwKTtcbiAgICBcbiAgICAgICAgdGhpcy5iaWtlcG9vbHNlcnZpY2UuUG9zdFNlcnZpY2UoU2VydmljZVVSTC5SaWRlU3RhdHVzLG9ialJpZGUpLnN1YnNjcmliZShcbiAgICAgICAgICByaWRlID0+IGNvbnNvbGUubG9nKHJpZGUpLFxuICAgICAgICAgIGVycm9yID0+IGNvbnNvbGUubG9nKGVycm9yKVxuICAgICAgICApXG4gIH1cbiAgXG59XG4iXX0=