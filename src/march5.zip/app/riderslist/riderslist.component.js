"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var app = require("tns-core-modules/application");
var bikepoolservice_1 = require("../shared/bikepoolservice");
var services_1 = require("../shared/services");
var ApplicationSettings = require("application-settings");
var Geolocation = require("nativescript-geolocation");
var RidersItem = /** @class */ (function () {
    function RidersItem(name, distance, status, userid, devicetoken, profilePhoto) {
        this.name = name;
        this.distance = distance;
        this.status = status;
        this.userid = userid;
        this.devicetoken = devicetoken;
        this.profilePhoto = profilePhoto;
    }
    return RidersItem;
}());
var RiderListComponent = /** @class */ (function () {
    function RiderListComponent(bikepoolservice) {
        this.bikepoolservice = bikepoolservice;
    }
    RiderListComponent.prototype.RidersListSuccess = function (riders) {
        console.log(riders);
        for (var ride = 0; ride < riders.Data.length; ride++) {
            var distance = this.CalculateDistance(riders.Data[ride].latitude, riders.Data[ride].longitude);
            var rideDistance = isNaN(distance) ? "Less than a Km" : distance.toString();
            this.dataItems.push(new RidersItem(riders.Data[ride].username, rideDistance.toString(), riders.Data[ride].status, riders.Data[ride].userid, riders.Data[ride].deviceToken, riders.Data[ride].profilePhoto));
        }
    };
    RiderListComponent.prototype.CalculateDistance = function (lat, long) {
        var locationFrom = new Geolocation.Location();
        locationFrom.latitude = parseFloat(ApplicationSettings.getString("fromlat"));
        locationFrom.longitude = parseFloat(ApplicationSettings.getString("fromlong"));
        var locationTo = new Geolocation.Location();
        locationTo.latitude = parseFloat(lat);
        locationTo.longitude = parseFloat(long);
        var distance = Geolocation.distance(locationFrom, locationTo);
        return (distance / 1000).toFixed(2).toString() + "kms";
    };
    RiderListComponent.prototype.RiderListError = function (error) {
    };
    RiderListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.dataItems = [];
        this.bikepoolservice.PostService(services_1.ServiceURL.RideUsers, null).subscribe(function (riders) { return _this.RidersListSuccess(riders); }, function (error) { return _this.RiderListError(error); });
    };
    RiderListComponent.prototype.onDrawerButtonTap = function () {
        var sideDrawer = app.getRootView();
        sideDrawer.showDrawer();
    };
    RiderListComponent.prototype.onItemTap = function (args) {
        var _this = this;
        var selectedRider = this.dataItems[args.index];
        var objRideStatus = {
            userid: selectedRider.userid,
            rideStartTime: ApplicationSettings.getString("ridetime"),
            rideDistance: ApplicationSettings.getString("ridedistance"),
            currentLocation: ApplicationSettings.getString("currentlocation"),
            destinationLocation: ApplicationSettings.getString("tolocation"),
            deviceToken: selectedRider.devicetoken
        };
        console.log(objRideStatus);
        this.bikepoolservice.PostService(services_1.ServiceURL.RequestForRide, objRideStatus).subscribe(function (success) { return _this.RideStatusSuccess(success); }, function (error) { return _this.RideStatusError(error); });
    };
    RiderListComponent.prototype.RideStatusSuccess = function (response) {
        console.log(response);
    };
    RiderListComponent.prototype.RideStatusError = function (error) {
        console.log(error);
    };
    RiderListComponent.prototype.onRiderItemTap = function (item) {
        console.log(item);
    };
    RiderListComponent.prototype.onSetupItemView = function (args) {
        args.view.context.third = (args.index % 3 === 0);
    };
    RiderListComponent = __decorate([
        core_1.Component({
            selector: 'ns-riderslist',
            templateUrl: './riderslist.component.html',
            moduleId: module.id,
        }),
        __metadata("design:paramtypes", [bikepoolservice_1.BikePoolService])
    ], RiderListComponent);
    return RiderListComponent;
}());
exports.RiderListComponent = RiderListComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmlkZXJzbGlzdC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJyaWRlcnNsaXN0LmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUFrRDtBQUVsRCxrREFBb0Q7QUFFcEQsNkRBQTJEO0FBQzNELCtDQUFnRDtBQUNoRCwwREFBNEQ7QUFDNUQsc0RBQXdEO0FBRXhEO0lBQ0Usb0JBQW1CLElBQVksRUFDdEIsUUFBZ0IsRUFBUyxNQUFjLEVBQVMsTUFBYyxFQUM5RCxXQUFrQixFQUFRLFlBQW1CO1FBRm5DLFNBQUksR0FBSixJQUFJLENBQVE7UUFDdEIsYUFBUSxHQUFSLFFBQVEsQ0FBUTtRQUFTLFdBQU0sR0FBTixNQUFNLENBQVE7UUFBUyxXQUFNLEdBQU4sTUFBTSxDQUFRO1FBQzlELGdCQUFXLEdBQVgsV0FBVyxDQUFPO1FBQVEsaUJBQVksR0FBWixZQUFZLENBQU87SUFBSSxDQUFDO0lBQzdELGlCQUFDO0FBQUQsQ0FBQyxBQUpELElBSUM7QUFPRDtJQW9DRSw0QkFBb0IsZUFBZ0M7UUFBaEMsb0JBQWUsR0FBZixlQUFlLENBQWlCO0lBQ3BELENBQUM7SUEvQkQsOENBQWlCLEdBQWpCLFVBQWtCLE1BQU07UUFFdEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVwQixLQUFLLElBQUksSUFBSSxHQUFHLENBQUMsRUFBRSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDcEQsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUE7WUFDOUYsSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQzVFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxRQUFRLEVBQUUsRUFDckYsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQ2xELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxFQUM3QixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUE7U0FDbEM7SUFDSCxDQUFDO0lBRUQsOENBQWlCLEdBQWpCLFVBQWtCLEdBQUcsRUFBRSxJQUFJO1FBQ3pCLElBQUksWUFBWSxHQUFHLElBQUksV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQzlDLFlBQVksQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1FBQzdFLFlBQVksQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO1FBRS9FLElBQUksVUFBVSxHQUFHLElBQUksV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQzVDLFVBQVUsQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3RDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRXhDLElBQUksUUFBUSxHQUFHLFdBQVcsQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQzlELE9BQU8sQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxHQUFHLEtBQUssQ0FBQztJQUN6RCxDQUFDO0lBRUQsMkNBQWMsR0FBZCxVQUFlLEtBQUs7SUFFcEIsQ0FBQztJQUlELHFDQUFRLEdBQVI7UUFBQSxpQkFPQztRQU5DLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO1FBRWhCLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLHFCQUFVLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FDcEUsVUFBQSxNQUFNLElBQUksT0FBQSxLQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLEVBQTlCLENBQThCLEVBQ3hDLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBMUIsQ0FBMEIsQ0FDcEMsQ0FBQTtJQUNQLENBQUM7SUFFRCw4Q0FBaUIsR0FBakI7UUFDRSxJQUFNLFVBQVUsR0FBa0IsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3BELFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsc0NBQVMsR0FBVCxVQUFVLElBQUk7UUFBZCxpQkFtQkM7UUFsQkMsSUFBSSxhQUFhLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFL0MsSUFBSSxhQUFhLEdBQ2pCO1lBQ0UsTUFBTSxFQUFHLGFBQWEsQ0FBQyxNQUFNO1lBQzdCLGFBQWEsRUFBRyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDO1lBQ3pELFlBQVksRUFBRyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDO1lBQzVELGVBQWUsRUFBRyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUM7WUFDbEUsbUJBQW1CLEVBQUcsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQztZQUNqRSxXQUFXLEVBQUcsYUFBYSxDQUFDLFdBQVc7U0FDeEMsQ0FBQTtRQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUM7UUFFM0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMscUJBQVUsQ0FBQyxjQUFjLEVBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUNqRixVQUFBLE9BQU8sSUFBRyxPQUFBLEtBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsRUFBL0IsQ0FBK0IsRUFDekMsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxFQUEzQixDQUEyQixDQUNyQyxDQUFBO0lBQ0gsQ0FBQztJQUVELDhDQUFpQixHQUFqQixVQUFrQixRQUFRO1FBRXhCLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDeEIsQ0FBQztJQUVELDRDQUFlLEdBQWYsVUFBZ0IsS0FBSztRQUVuQixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3JCLENBQUM7SUFFRCwyQ0FBYyxHQUFkLFVBQWUsSUFBZ0I7UUFDN0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNwQixDQUFDO0lBRUQsNENBQWUsR0FBZixVQUFnQixJQUF1QjtRQUNyQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBMUZVLGtCQUFrQjtRQUw5QixnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLGVBQWU7WUFDekIsV0FBVyxFQUFFLDZCQUE2QjtZQUMxQyxRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7U0FDcEIsQ0FBQzt5Q0FxQ3FDLGlDQUFlO09BcEN6QyxrQkFBa0IsQ0EyRjlCO0lBQUQseUJBQUM7Q0FBQSxBQTNGRCxJQTJGQztBQTNGWSxnREFBa0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgUmFkU2lkZURyYXdlciB9IGZyb20gXCJuYXRpdmVzY3JpcHQtdWktc2lkZWRyYXdlclwiO1xuaW1wb3J0ICogYXMgYXBwIGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL2FwcGxpY2F0aW9uXCI7XG5pbXBvcnQgeyBTZXR1cEl0ZW1WaWV3QXJncyB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9kaXJlY3RpdmVzXCI7XG5pbXBvcnQgeyBCaWtlUG9vbFNlcnZpY2UgfSBmcm9tIFwiLi4vc2hhcmVkL2Jpa2Vwb29sc2VydmljZVwiXG5pbXBvcnQgeyBTZXJ2aWNlVVJMIH0gZnJvbSBcIi4uL3NoYXJlZC9zZXJ2aWNlc1wiO1xuaW1wb3J0ICogYXMgQXBwbGljYXRpb25TZXR0aW5ncyBmcm9tIFwiYXBwbGljYXRpb24tc2V0dGluZ3NcIjtcbmltcG9ydCAqIGFzIEdlb2xvY2F0aW9uIGZyb20gXCJuYXRpdmVzY3JpcHQtZ2VvbG9jYXRpb25cIjtcblxuY2xhc3MgUmlkZXJzSXRlbSB7XG4gIGNvbnN0cnVjdG9yKHB1YmxpYyBuYW1lOiBzdHJpbmcsXG4gICAgcHVibGljIGRpc3RhbmNlOiBzdHJpbmcsIHB1YmxpYyBzdGF0dXM6IHN0cmluZywgcHVibGljIHVzZXJpZDogc3RyaW5nLFxuICAgIHB1YmxpYyBkZXZpY2V0b2tlbjpzdHJpbmcscHVibGljIHByb2ZpbGVQaG90bzpzdHJpbmcpIHsgfVxufVxuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICducy1yaWRlcnNsaXN0JyxcbiAgdGVtcGxhdGVVcmw6ICcuL3JpZGVyc2xpc3QuY29tcG9uZW50Lmh0bWwnLFxuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxufSlcbmV4cG9ydCBjbGFzcyBSaWRlckxpc3RDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuXG4gIHB1YmxpYyBkYXRhSXRlbXM6IEFycmF5PFJpZGVyc0l0ZW0+O1xuICBmcm9tTGF0OiBzdHJpbmc7XG4gIGZyb21Mb25nOiBzdHJpbmc7XG5cbiAgUmlkZXJzTGlzdFN1Y2Nlc3MocmlkZXJzKSB7XG5cbiAgICBjb25zb2xlLmxvZyhyaWRlcnMpO1xuXG4gICAgZm9yIChsZXQgcmlkZSA9IDA7IHJpZGUgPCByaWRlcnMuRGF0YS5sZW5ndGg7IHJpZGUrKykge1xuICAgICAgbGV0IGRpc3RhbmNlID0gdGhpcy5DYWxjdWxhdGVEaXN0YW5jZShyaWRlcnMuRGF0YVtyaWRlXS5sYXRpdHVkZSwgcmlkZXJzLkRhdGFbcmlkZV0ubG9uZ2l0dWRlKVxuICAgICAgbGV0IHJpZGVEaXN0YW5jZSA9IGlzTmFOKGRpc3RhbmNlKSA/IFwiTGVzcyB0aGFuIGEgS21cIiA6IGRpc3RhbmNlLnRvU3RyaW5nKCk7XG4gICAgICB0aGlzLmRhdGFJdGVtcy5wdXNoKG5ldyBSaWRlcnNJdGVtKHJpZGVycy5EYXRhW3JpZGVdLnVzZXJuYW1lLCByaWRlRGlzdGFuY2UudG9TdHJpbmcoKSxcbiAgICAgICByaWRlcnMuRGF0YVtyaWRlXS5zdGF0dXMsIHJpZGVycy5EYXRhW3JpZGVdLnVzZXJpZCxcbiAgICAgICByaWRlcnMuRGF0YVtyaWRlXS5kZXZpY2VUb2tlbixcbiAgICAgICByaWRlcnMuRGF0YVtyaWRlXS5wcm9maWxlUGhvdG8pKVxuICAgIH1cbiAgfVxuXG4gIENhbGN1bGF0ZURpc3RhbmNlKGxhdCwgbG9uZyk6IGFueSB7XG4gICAgbGV0IGxvY2F0aW9uRnJvbSA9IG5ldyBHZW9sb2NhdGlvbi5Mb2NhdGlvbigpO1xuICAgIGxvY2F0aW9uRnJvbS5sYXRpdHVkZSA9IHBhcnNlRmxvYXQoQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJmcm9tbGF0XCIpKTtcbiAgICBsb2NhdGlvbkZyb20ubG9uZ2l0dWRlID0gcGFyc2VGbG9hdChBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcImZyb21sb25nXCIpKTtcblxuICAgIGxldCBsb2NhdGlvblRvID0gbmV3IEdlb2xvY2F0aW9uLkxvY2F0aW9uKCk7XG4gICAgbG9jYXRpb25Uby5sYXRpdHVkZSA9IHBhcnNlRmxvYXQobGF0KTtcbiAgICBsb2NhdGlvblRvLmxvbmdpdHVkZSA9IHBhcnNlRmxvYXQobG9uZyk7XG5cbiAgICBsZXQgZGlzdGFuY2UgPSBHZW9sb2NhdGlvbi5kaXN0YW5jZShsb2NhdGlvbkZyb20sIGxvY2F0aW9uVG8pO1xuICAgIHJldHVybiAoZGlzdGFuY2UgLyAxMDAwKS50b0ZpeGVkKDIpLnRvU3RyaW5nKCkgKyBcImttc1wiO1xuICB9XG5cbiAgUmlkZXJMaXN0RXJyb3IoZXJyb3IpIHtcblxuICB9XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgYmlrZXBvb2xzZXJ2aWNlOiBCaWtlUG9vbFNlcnZpY2UpIHsgICAgXG4gIH1cblxuICBuZ09uSW5pdCgpIHtcbiAgICB0aGlzLmRhdGFJdGVtcyA9IFtdO1xuICAgIFxuICAgICAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5Qb3N0U2VydmljZShTZXJ2aWNlVVJMLlJpZGVVc2VycywgbnVsbCkuc3Vic2NyaWJlKFxuICAgICAgICAgIHJpZGVycyA9PiB0aGlzLlJpZGVyc0xpc3RTdWNjZXNzKHJpZGVycyksXG4gICAgICAgICAgZXJyb3IgPT4gdGhpcy5SaWRlckxpc3RFcnJvcihlcnJvcilcbiAgICAgICAgKVxuICB9XG5cbiAgb25EcmF3ZXJCdXR0b25UYXAoKTogdm9pZCB7XG4gICAgY29uc3Qgc2lkZURyYXdlciA9IDxSYWRTaWRlRHJhd2VyPmFwcC5nZXRSb290VmlldygpO1xuICAgIHNpZGVEcmF3ZXIuc2hvd0RyYXdlcigpO1xuICB9XG5cbiAgb25JdGVtVGFwKGFyZ3MpIHtcbiAgICBsZXQgc2VsZWN0ZWRSaWRlciA9IHRoaXMuZGF0YUl0ZW1zW2FyZ3MuaW5kZXhdO1xuICAgIFxuICAgIGxldCBvYmpSaWRlU3RhdHVzID1cbiAgICB7XG4gICAgICB1c2VyaWQgOiBzZWxlY3RlZFJpZGVyLnVzZXJpZCxcbiAgICAgIHJpZGVTdGFydFRpbWUgOiBBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcInJpZGV0aW1lXCIpLFxuICAgICAgcmlkZURpc3RhbmNlIDogQXBwbGljYXRpb25TZXR0aW5ncy5nZXRTdHJpbmcoXCJyaWRlZGlzdGFuY2VcIiksXG4gICAgICBjdXJyZW50TG9jYXRpb24gOiBBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcImN1cnJlbnRsb2NhdGlvblwiKSxcbiAgICAgIGRlc3RpbmF0aW9uTG9jYXRpb24gOiBBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcInRvbG9jYXRpb25cIiksXG4gICAgICBkZXZpY2VUb2tlbiA6IHNlbGVjdGVkUmlkZXIuZGV2aWNldG9rZW5cbiAgICB9XG5cbiAgICBjb25zb2xlLmxvZyhvYmpSaWRlU3RhdHVzKTtcblxuICAgIHRoaXMuYmlrZXBvb2xzZXJ2aWNlLlBvc3RTZXJ2aWNlKFNlcnZpY2VVUkwuUmVxdWVzdEZvclJpZGUsb2JqUmlkZVN0YXR1cykuc3Vic2NyaWJlKFxuICAgICAgc3VjY2VzcyA9PnRoaXMuUmlkZVN0YXR1c1N1Y2Nlc3Moc3VjY2VzcyksXG4gICAgICBlcnJvciA9PiB0aGlzLlJpZGVTdGF0dXNFcnJvcihlcnJvcilcbiAgICApXG4gIH1cblxuICBSaWRlU3RhdHVzU3VjY2VzcyhyZXNwb25zZSlcbiAge1xuICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKTtcbiAgfVxuXG4gIFJpZGVTdGF0dXNFcnJvcihlcnJvcilcbiAge1xuICAgIGNvbnNvbGUubG9nKGVycm9yKTtcbiAgfVxuXG4gIG9uUmlkZXJJdGVtVGFwKGl0ZW06IFJpZGVyc0l0ZW0pIHtcbiAgICBjb25zb2xlLmxvZyhpdGVtKTtcbiAgfVxuXG4gIG9uU2V0dXBJdGVtVmlldyhhcmdzOiBTZXR1cEl0ZW1WaWV3QXJncykge1xuICAgIGFyZ3Mudmlldy5jb250ZXh0LnRoaXJkID0gKGFyZ3MuaW5kZXggJSAzID09PSAwKTtcbiAgfVxufVxuIl19