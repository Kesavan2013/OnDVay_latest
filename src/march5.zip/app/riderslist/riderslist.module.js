"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("nativescript-angular/common");
var riderslist_routing_module_1 = require("./riderslist-routing.module");
var riderslist_component_1 = require("./riderslist.component");
var RidersListModule = /** @class */ (function () {
    function RidersListModule() {
    }
    RidersListModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.NativeScriptCommonModule,
                riderslist_routing_module_1.RidersListRoutingModule
            ],
            declarations: [
                riderslist_component_1.RiderListComponent
            ],
            schemas: [
                core_1.NO_ERRORS_SCHEMA
            ]
        })
    ], RidersListModule);
    return RidersListModule;
}());
exports.RidersListModule = RidersListModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmlkZXJzbGlzdC5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJyaWRlcnNsaXN0Lm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUEyRDtBQUMzRCxzREFBdUU7QUFFdkUseUVBQXNFO0FBQ3RFLCtEQUE0RDtBQWM1RDtJQUFBO0lBQWdDLENBQUM7SUFBcEIsZ0JBQWdCO1FBWjVCLGVBQVEsQ0FBQztZQUNOLE9BQU8sRUFBRTtnQkFDTCxpQ0FBd0I7Z0JBQ3hCLG1EQUF1QjthQUMxQjtZQUNELFlBQVksRUFBRTtnQkFDVix5Q0FBa0I7YUFDckI7WUFDRCxPQUFPLEVBQUU7Z0JBQ0wsdUJBQWdCO2FBQ25CO1NBQ0osQ0FBQztPQUNXLGdCQUFnQixDQUFJO0lBQUQsdUJBQUM7Q0FBQSxBQUFqQyxJQUFpQztBQUFwQiw0Q0FBZ0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSwgTk9fRVJST1JTX1NDSEVNQSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvY29tbW9uXCI7XG5cbmltcG9ydCB7IFJpZGVyc0xpc3RSb3V0aW5nTW9kdWxlIH0gZnJvbSBcIi4vcmlkZXJzbGlzdC1yb3V0aW5nLm1vZHVsZVwiO1xuaW1wb3J0IHsgUmlkZXJMaXN0Q29tcG9uZW50IH0gZnJvbSBcIi4vcmlkZXJzbGlzdC5jb21wb25lbnRcIjtcblxuQE5nTW9kdWxlKHtcbiAgICBpbXBvcnRzOiBbXG4gICAgICAgIE5hdGl2ZVNjcmlwdENvbW1vbk1vZHVsZSxcbiAgICAgICAgUmlkZXJzTGlzdFJvdXRpbmdNb2R1bGVcbiAgICBdLFxuICAgIGRlY2xhcmF0aW9uczogW1xuICAgICAgICBSaWRlckxpc3RDb21wb25lbnRcbiAgICBdLFxuICAgIHNjaGVtYXM6IFtcbiAgICAgICAgTk9fRVJST1JTX1NDSEVNQVxuICAgIF1cbn0pXG5leHBvcnQgY2xhc3MgUmlkZXJzTGlzdE1vZHVsZSB7IH1cbiJdfQ==