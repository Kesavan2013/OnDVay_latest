"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var app = require("tns-core-modules/application");
var Geolocation = require("nativescript-geolocation");
var date_picker_1 = require("tns-core-modules/ui/date-picker");
var bikepoolservice_1 = require("../shared/bikepoolservice");
var dialogs = require("tns-core-modules/ui/dialogs");
var router_1 = require("nativescript-angular/router");
var firebase = require("nativescript-plugin-firebase");
var ApplicationSettings = require("application-settings");
var router_2 = require("@angular/router");
var HomeComponent = /** @class */ (function () {
    function HomeComponent(bikepoolservice, routerExtensions, router, zone) {
        this.bikepoolservice = bikepoolservice;
        this.routerExtensions = routerExtensions;
        this.router = router;
        this.zone = zone;
        this.currentLocation = "Triplicane";
        // Use the component constructor to inject providers.
    }
    HomeComponent.prototype.ngOnInit = function () {
        //this.ClearRideSettings();
        this.items = [];
        this.items.push("Car");
        this.items.push("Bike");
        // call setDatePickerTime method
        this.setDatePickerTime();
        // Init your component properties here.
        var location = this.getDeviceLocation();
        this.InitFireBasePlugIn();
        this.updateStatusAvail();
    };
    HomeComponent.prototype.setDatePickerTime = function () {
        var date = new Date();
        var datePicker = new date_picker_1.DatePicker();
        datePicker.day = date.getDate();
        datePicker.month = date.getMonth() + 1;
        datePicker.year = date.getFullYear();
        datePicker.date = new Date(); // using Date object
        datePicker.minDate = new Date(date.getFullYear(), date.getMonth() + 1, date.getDate());
        datePicker.maxDate = new Date(2040, 4, 20);
    };
    HomeComponent.prototype.updateStatusAvail = function () {
        var _this = this;
        firebase.addValueEventListener(function (data) {
            var Status;
            if (data.value) {
                console.log('Status: Online');
                Status = "Online";
            }
            else {
                console.log('Status: Offline');
                Status = "Offline";
            }
            var objUpdateUserLocation = {
                userid: ApplicationSettings.getString("userid"),
                longitude: _this.FromLat,
                latitude: _this.FromLong,
                status: Status
            };
            // this.bikepoolservice.PostService(ServiceURL.RideUpdateUserLocation,objUpdateUserLocation).subscribe(
            //     success => console.log(success),
            //     error => console.log("updatedevicelocation" + error)
            // )
        }, '.info/connected');
    };
    HomeComponent.prototype.InitFireBasePlugIn = function () {
        var _this = this;
        firebase.init({
            //persist should be set to false as otherwise numbers aren't returned during livesync
            persist: false,
            url: "https://metroapplicationproject.firebaseio.com",
            onPushTokenReceivedCallback: function (token) {
                ApplicationSettings.setString('device_token', token);
                console.log('device token: ', token); // <-- add this
            },
            onMessageReceivedCallback: function (message) {
                var objNotificationMessage = message.data.value;
                console.log(message.data.value);
                var navigationExtras = {
                    queryParams: {
                        objNotificationMessage: objNotificationMessage
                    }
                };
                _this.router.navigate(["rideinfo"], navigationExtras);
            },
            notificationCallbackAndroid: function (message) {
                console.log(JSON.stringify(message));
                //if (message.foreground == false) {
                dialogs.alert({
                    title: "On d Vay",
                    message: "Riders Requested Notification",
                    okButtonText: "ok"
                });
                // } else {
                //     console.log("Message received when inside the app");
                // }
            },
            onAuthStateChanged: function (data) {
                console.log(JSON.stringify(data));
                if (data.loggedIn) {
                    ApplicationSettings.setString("userid", data.user.uid);
                }
                else {
                    ApplicationSettings.remove("userid");
                    console.log("OnAuthState" + data);
                }
            }
        }).then(function (instance) {
            console.log("firebase.init done");
            console.log(instance);
        }, function (error) {
            console.log("firebase.init error: " + error);
        });
    };
    HomeComponent.prototype.onDatePickerLoaded = function (data) {
    };
    HomeComponent.prototype.getDeviceLocation = function () {
        var _this = this;
        return new Promise(function (resolve, reject) {
            Geolocation.enableLocationRequest().then(function () {
                Geolocation.getCurrentLocation({ timeout: 10000 }).then(function (location) {
                    resolve(location);
                    // Call updateDeviceLocation method
                    _this.userlatitude = location.latitude;
                    _this.userlongtitude = location.longitude;
                    _this.updateDeviceLocation(location.latitude, location.longitude);
                }).catch(function (error) {
                    reject(error);
                });
            });
        });
    };
    HomeComponent.prototype.updateDeviceLocation = function (lat, long) {
        var _this = this;
        this.FromLat = lat;
        this.FromLong = long;
        var formURL = "?prox=" + lat + "," + long;
        this.bikepoolservice.GetAddress(formURL).subscribe(function (address) { return _this.handleSuccessDeviceLoc(address); }, function (error) { return _this.handleErrorDeviceLoc(error); });
    };
    HomeComponent.prototype.handleSuccessDeviceLoc = function (success) {
        var objResult = success.Response.View[0].Result[0];
        this.currentLocation = objResult.Location.Address.Label;
        this.FromLat = objResult.Location.DisplayPosition.Latitude;
        this.FromLong = objResult.Location.DisplayPosition.Longitude;
        ApplicationSettings.setString("fromlat", this.FromLat.toString());
        ApplicationSettings.setString("fromlong", this.FromLong.toString());
    };
    HomeComponent.prototype.handleErrorDeviceLoc = function (error) { };
    HomeComponent.prototype.onSubmit = function (args) {
        var _this = this;
        var searchBar = args.object;
        this.bikepoolservice.GetAddressAC(searchBar.text).subscribe(function (ac) { return _this.handleACSuccess(ac); }, function (error) { return _this.handleACError(error); });
    };
    HomeComponent.prototype.setRideSettings = function () {
        // ApplicationSettings.setString("currentlocation",this.currentLocation);
        // ApplicationSettings.setString("tolocation",this.searchPhrase);
        // ApplicationSettings.setString("ridedistance",this.totalRideDistance);
        // ApplicationSettings.setString("ridetime",this.selectedRideTime);
        // ApplicationSettings.setString("fromlat",this.FromLat);
        // ApplicationSettings.setString("fromlong",this.FromLong);
        // ApplicationSettings.setString("tolat",this.ToLat);
        // ApplicationSettings.setString("tolong",this.ToLong);
    };
    HomeComponent.prototype.ClearRideSettings = function () {
        // ApplicationSettings.remove("currentlocation");
        // ApplicationSettings.remove("tolocation");
        // ApplicationSettings.remove("ridedistance");
        // ApplicationSettings.remove("ridetime");
        // ApplicationSettings.remove("fromlat");
        // ApplicationSettings.remove("fromlong");
        // ApplicationSettings.remove("tolat");
        // ApplicationSettings.remove("tolong");
    };
    HomeComponent.prototype.handleACSuccess = function (success) {
        var objResult = success.Response.View[0].Result[0];
        this.searchPhrase = objResult.Location.Address.Label;
        this.ToLat = objResult.Location.DisplayPosition.Latitude;
        this.ToLong = objResult.Location.DisplayPosition.Longitude;
        ApplicationSettings.setString("currentlocation", this.currentLocation);
        ApplicationSettings.setString("tolocation", this.searchPhrase);
        this.CalculateDistance();
    };
    HomeComponent.prototype.handleACError = function (error) { };
    HomeComponent.prototype.onTextChanged = function (args) {
        var searchBar = args.object;
    };
    HomeComponent.prototype.onClear = function (args) {
        var searchBar = args.object;
        searchBar.text = "";
        searchBar.hint = "Enter Location";
    };
    HomeComponent.prototype.onchange = function (args) {
        console.log("Drop Down selected index changed from " + args.oldIndex + " to " + args.newIndex);
    };
    HomeComponent.prototype.onopen = function () {
        console.log("Drop Down opened.");
    };
    HomeComponent.prototype.onclose = function () {
        console.log("Drop Down closed.");
    };
    HomeComponent.prototype.onDrawerButtonTap = function () {
        var sideDrawer = app.getRootView();
        sideDrawer.showDrawer();
    };
    HomeComponent.prototype.onFindRiders = function (event) {
        //this.setRideSettings();
        this.routerExtensions.navigate(["/riderslist"], { clearHistory: true });
    };
    HomeComponent.prototype.onPickerLoaded = function (args) {
        var timePicker = args.object;
        var today = new Date();
        var time = today.getHours();
        timePicker.hour = time;
        timePicker.minute = today.getMinutes() + 10;
        var periodian = (timePicker.hour >= 12) ? "am" : "pm";
        this.selectedRideTime = timePicker.hour + timePicker.minute + periodian;
        ApplicationSettings.setString("ridetime", this.selectedRideTime);
    };
    HomeComponent.prototype.onTimeChanged = function (args) {
        var totalTime;
        var hour = args.value.getHours();
        var minutes = args.value.getMinutes();
        if (parseFloat(hour) >= 12) {
            var FormatHour = parseFloat(hour) - 12;
            this.selectedRideTime = (FormatHour == 0) ? "12" : FormatHour.toString() + " : " + minutes + " pm";
        }
        else {
            this.selectedRideTime = parseFloat(hour).toString() + " : " + minutes.toString() + " am";
        }
        ApplicationSettings.setString("ridetime", this.selectedRideTime);
        //this.setRideSettings();
    };
    HomeComponent.prototype.CalculateDistance = function () {
        var _this = this;
        var locationFrom = new Geolocation.Location();
        locationFrom.latitude = parseFloat(this.FromLat);
        locationFrom.longitude = parseFloat(this.FromLong);
        var locationTo = new Geolocation.Location();
        locationTo.latitude = parseFloat(this.ToLat);
        locationTo.longitude = parseFloat(this.ToLong);
        var url = "waypoint0=" + this.FromLat + "," + this.FromLong + "&waypoint1=" + this.ToLat + "," + this.ToLong;
        console.log(url);
        this.bikepoolservice.GetDistance(url).subscribe(function (distance) { return _this.distancesuccess(distance); }, function (error) { return _this.distanceerror(error); });
    };
    HomeComponent.prototype.distancesuccess = function (distance) {
        var dist = distance.response.route[0].summary.distance;
        var travelTime = distance.response.route[0].summary.travelTime;
        this.totalRideDistance = dist / 1000;
        ApplicationSettings.setString("ridedistance", this.totalRideDistance.toString(2));
    };
    HomeComponent.prototype.distanceerror = function (error) {
        console.log(error);
    };
    HomeComponent = __decorate([
        core_1.Component({
            selector: "Home",
            moduleId: module.id,
            templateUrl: "./home.component.html"
        }),
        __metadata("design:paramtypes", [bikepoolservice_1.BikePoolService, router_1.RouterExtensions,
            router_2.Router, core_1.NgZone])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaG9tZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJob21lLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLHNDQUEwRDtBQUUxRCxrREFBb0Q7QUFDcEQsc0RBQXdEO0FBSXhELCtEQUE2RDtBQUc3RCw2REFBNEQ7QUFFNUQscURBQXVEO0FBQ3ZELHNEQUErRDtBQUMvRCxJQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsOEJBQThCLENBQUMsQ0FBQztBQUN6RCwwREFBNEQ7QUFDNUQsMENBQTJEO0FBTzNEO0lBV0ksdUJBQW9CLGVBQWtDLEVBQVUsZ0JBQWtDLEVBQ3RGLE1BQWMsRUFBVSxJQUFZO1FBRDVCLG9CQUFlLEdBQWYsZUFBZSxDQUFtQjtRQUFVLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBa0I7UUFDdEYsV0FBTSxHQUFOLE1BQU0sQ0FBUTtRQUFVLFNBQUksR0FBSixJQUFJLENBQVE7UUFWaEQsb0JBQWUsR0FBVyxZQUFZLENBQUM7UUFXbkMscURBQXFEO0lBQ3pELENBQUM7SUFFRCxnQ0FBUSxHQUFSO1FBRUksMkJBQTJCO1FBQzNCLElBQUksQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRXhCLGdDQUFnQztRQUNoQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUV6Qix1Q0FBdUM7UUFDdkMsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFFeEMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFFMUIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7SUFDN0IsQ0FBQztJQUVELHlDQUFpQixHQUFqQjtRQUNJLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7UUFDdEIsSUFBTSxVQUFVLEdBQUcsSUFBSSx3QkFBVSxFQUFFLENBQUM7UUFDcEMsVUFBVSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDaEMsVUFBVSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZDLFVBQVUsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3JDLFVBQVUsQ0FBQyxJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxDQUFDLG9CQUFvQjtRQUVsRCxVQUFVLENBQUMsT0FBTyxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZGLFVBQVUsQ0FBQyxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQseUNBQWlCLEdBQWpCO1FBQUEsaUJBd0JDO1FBdEJHLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxVQUFBLElBQUk7WUFDL0IsSUFBSSxNQUFNLENBQUM7WUFDWCxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUU7Z0JBQ1osT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUM5QixNQUFNLEdBQUcsUUFBUSxDQUFDO2FBQ3JCO2lCQUFNO2dCQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQztnQkFDL0IsTUFBTSxHQUFHLFNBQVMsQ0FBQzthQUN0QjtZQUVELElBQUkscUJBQXFCLEdBQ3JCO2dCQUNJLE1BQU0sRUFBRSxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDO2dCQUMvQyxTQUFTLEVBQUUsS0FBSSxDQUFDLE9BQU87Z0JBQ3ZCLFFBQVEsRUFBRSxLQUFJLENBQUMsUUFBUTtnQkFDdkIsTUFBTSxFQUFFLE1BQU07YUFDakIsQ0FBQTtZQUNMLHVHQUF1RztZQUN2Ryx1Q0FBdUM7WUFDdkMsMkRBQTJEO1lBQzNELElBQUk7UUFDUixDQUFDLEVBQUUsaUJBQWlCLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBRUQsMENBQWtCLEdBQWxCO1FBQUEsaUJBcURDO1FBcERHLFFBQVEsQ0FBQyxJQUFJLENBQUM7WUFDVixxRkFBcUY7WUFDckYsT0FBTyxFQUFFLEtBQUs7WUFDZCxHQUFHLEVBQUUsZ0RBQWdEO1lBQ3JELDJCQUEyQixFQUFFLFVBQVUsS0FBSztnQkFDeEMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDckQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLGVBQWU7WUFDekQsQ0FBQztZQUVELHlCQUF5QixFQUFFLFVBQUMsT0FBWTtnQkFDcEMsSUFBSSxzQkFBc0IsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztnQkFDaEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNoQyxJQUFJLGdCQUFnQixHQUFxQjtvQkFDckMsV0FBVyxFQUFFO3dCQUNULHNCQUFzQix3QkFBQTtxQkFDekI7aUJBQ0osQ0FBQztnQkFFRixLQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFFLGdCQUFnQixDQUFDLENBQUM7WUFDekQsQ0FBQztZQUNELDJCQUEyQixFQUFFLFVBQUMsT0FBWTtnQkFDdEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7Z0JBRXJDLG9DQUFvQztnQkFDcEMsT0FBTyxDQUFDLEtBQUssQ0FBQztvQkFDVixLQUFLLEVBQUUsVUFBVTtvQkFDakIsT0FBTyxFQUFFLCtCQUErQjtvQkFDeEMsWUFBWSxFQUFFLElBQUk7aUJBQ3JCLENBQUMsQ0FBQztnQkFDSCxXQUFXO2dCQUNYLDJEQUEyRDtnQkFDM0QsSUFBSTtZQUNSLENBQUM7WUFDRCxrQkFBa0IsRUFBRSxVQUFDLElBQVM7Z0JBQzFCLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO2dCQUNqQyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7b0JBQ2YsbUJBQW1CLENBQUMsU0FBUyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUMxRDtxQkFDSTtvQkFDRCxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQ3JDLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxDQUFDO2lCQUNyQztZQUNMLENBQUM7U0FDSixDQUFDLENBQUMsSUFBSSxDQUNILFVBQVUsUUFBUTtZQUNkLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUNsQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzFCLENBQUMsRUFDRCxVQUFVLEtBQUs7WUFDWCxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixHQUFHLEtBQUssQ0FBQyxDQUFDO1FBQ2pELENBQUMsQ0FDQSxDQUFDO0lBQ1YsQ0FBQztJQUVELDBDQUFrQixHQUFsQixVQUFtQixJQUFlO0lBRWxDLENBQUM7SUFLTyx5Q0FBaUIsR0FBekI7UUFBQSxpQkFjQztRQWJHLE9BQU8sSUFBSSxPQUFPLENBQUMsVUFBQyxPQUFPLEVBQUUsTUFBTTtZQUMvQixXQUFXLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxJQUFJLENBQUM7Z0JBQ3JDLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFBLFFBQVE7b0JBQzVELE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDbEIsbUNBQW1DO29CQUNuQyxLQUFJLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUM7b0JBQ3RDLEtBQUksQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLFNBQVMsQ0FBQztvQkFDekMsS0FBSSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUNyRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBQSxLQUFLO29CQUNWLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbEIsQ0FBQyxDQUFDLENBQUM7WUFDUCxDQUFDLENBQUMsQ0FBQztRQUNQLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELDRDQUFvQixHQUFwQixVQUFxQixHQUFHLEVBQUUsSUFBSTtRQUE5QixpQkFNQztRQUxHLElBQUksQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDO1FBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFDekMsSUFBSSxPQUFPLEdBQUcsUUFBUSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO1FBQzFDLElBQUksQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FDOUMsVUFBQSxPQUFPLElBQUksT0FBQSxLQUFJLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLEVBQXBDLENBQW9DLEVBQy9DLFVBQUEsS0FBSyxJQUFJLE9BQUEsS0FBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxFQUFoQyxDQUFnQyxDQUFDLENBQUE7SUFDbEQsQ0FBQztJQUVELDhDQUFzQixHQUF0QixVQUF1QixPQUFPO1FBQzFCLElBQUksU0FBUyxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztRQUN4RCxJQUFJLENBQUMsT0FBTyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQztRQUMzRCxJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQztRQUM3RCxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztRQUNsRSxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztJQUN4RSxDQUFDO0lBRUQsNENBQW9CLEdBQXBCLFVBQXFCLEtBQUssSUFBSSxDQUFDO0lBRXhCLGdDQUFRLEdBQWYsVUFBZ0IsSUFBSTtRQUFwQixpQkFLQztRQUpHLElBQUksU0FBUyxHQUFjLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDdkMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FDdkQsVUFBQSxFQUFFLElBQUksT0FBQSxLQUFJLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxFQUF4QixDQUF3QixFQUM5QixVQUFBLEtBQUssSUFBSSxPQUFBLEtBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLEVBQXpCLENBQXlCLENBQUMsQ0FBQTtJQUMzQyxDQUFDO0lBRUQsdUNBQWUsR0FBZjtRQUNJLHlFQUF5RTtRQUN6RSxpRUFBaUU7UUFDakUsd0VBQXdFO1FBQ3hFLG1FQUFtRTtRQUNuRSx5REFBeUQ7UUFDekQsMkRBQTJEO1FBQzNELHFEQUFxRDtRQUNyRCx1REFBdUQ7SUFDM0QsQ0FBQztJQUVELHlDQUFpQixHQUFqQjtRQUNJLGlEQUFpRDtRQUNqRCw0Q0FBNEM7UUFDNUMsOENBQThDO1FBQzlDLDBDQUEwQztRQUMxQyx5Q0FBeUM7UUFDekMsMENBQTBDO1FBQzFDLHVDQUF1QztRQUN2Qyx3Q0FBd0M7SUFDNUMsQ0FBQztJQUVELHVDQUFlLEdBQWYsVUFBZ0IsT0FBTztRQUNuQixJQUFJLFNBQVMsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkQsSUFBSSxDQUFDLFlBQVksR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7UUFDckQsSUFBSSxDQUFDLEtBQUssR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7UUFDekQsSUFBSSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUM7UUFDM0QsbUJBQW1CLENBQUMsU0FBUyxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUN2RSxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUMvRCxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztJQUM3QixDQUFDO0lBRUQscUNBQWEsR0FBYixVQUFjLEtBQUssSUFBSSxDQUFDO0lBRWpCLHFDQUFhLEdBQXBCLFVBQXFCLElBQUk7UUFDckIsSUFBSSxTQUFTLEdBQWMsSUFBSSxDQUFDLE1BQU0sQ0FBQztJQUMzQyxDQUFDO0lBRU0sK0JBQU8sR0FBZCxVQUFlLElBQUk7UUFDZixJQUFJLFNBQVMsR0FBYyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ3ZDLFNBQVMsQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ3BCLFNBQVMsQ0FBQyxJQUFJLEdBQUcsZ0JBQWdCLENBQUM7SUFDdEMsQ0FBQztJQUVNLGdDQUFRLEdBQWYsVUFBZ0IsSUFBbUM7UUFDL0MsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQ0FBeUMsSUFBSSxDQUFDLFFBQVEsWUFBTyxJQUFJLENBQUMsUUFBVSxDQUFDLENBQUM7SUFDOUYsQ0FBQztJQUVNLDhCQUFNLEdBQWI7UUFDSSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVNLCtCQUFPLEdBQWQ7UUFDSSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVELHlDQUFpQixHQUFqQjtRQUNJLElBQU0sVUFBVSxHQUFrQixHQUFHLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEQsVUFBVSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFRCxvQ0FBWSxHQUFaLFVBQWEsS0FBSztRQUNkLHlCQUF5QjtRQUN6QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUUsRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRUQsc0NBQWMsR0FBZCxVQUFlLElBQUk7UUFDZixJQUFJLFVBQVUsR0FBZSxJQUFJLENBQUMsTUFBTSxDQUFDO1FBRXpDLElBQUksS0FBSyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7UUFDdkIsSUFBSSxJQUFJLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBRTVCLFVBQVUsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ3ZCLFVBQVUsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLFVBQVUsRUFBRSxHQUFHLEVBQUUsQ0FBQztRQUU1QyxJQUFJLFNBQVMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxJQUFJLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFBO1FBQ3JELElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxVQUFVLENBQUMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDO1FBQ3hFLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDckUsQ0FBQztJQUlELHFDQUFhLEdBQWIsVUFBYyxJQUFJO1FBRWQsSUFBSSxTQUFTLENBQUM7UUFDZCxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2pDLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxFQUFFLENBQUM7UUFFdEMsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxFQUFFO1lBQ3hCLElBQUksVUFBVSxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDdkMsSUFBSSxDQUFDLGdCQUFnQixHQUFHLENBQUMsVUFBVSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsR0FBRyxLQUFLLEdBQUcsT0FBTyxHQUFHLEtBQUssQ0FBQztTQUN0RzthQUNJO1lBQ0QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUUsR0FBRyxLQUFLLEdBQUcsT0FBTyxDQUFDLFFBQVEsRUFBRSxHQUFHLEtBQUssQ0FBQztTQUM1RjtRQUNELG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDakUseUJBQXlCO0lBQzdCLENBQUM7SUFFRCx5Q0FBaUIsR0FBakI7UUFBQSxpQkFlQztRQWRHLElBQUksWUFBWSxHQUFHLElBQUksV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQzlDLFlBQVksQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNqRCxZQUFZLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFbkQsSUFBSSxVQUFVLEdBQUcsSUFBSSxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDNUMsVUFBVSxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzdDLFVBQVUsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUUvQyxJQUFJLEdBQUcsR0FBRyxZQUFZLEdBQUcsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFFBQVEsR0FBRyxhQUFhLEdBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQTtRQUM1RyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2pCLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FDM0MsVUFBQSxRQUFRLElBQUksT0FBQSxLQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxFQUE5QixDQUE4QixFQUMxQyxVQUFBLEtBQUssSUFBSSxPQUFBLEtBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLEVBQXpCLENBQXlCLENBQ3JDLENBQUE7SUFDTCxDQUFDO0lBRUQsdUNBQWUsR0FBZixVQUFnQixRQUFRO1FBQ3BCLElBQUksSUFBSSxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUE7UUFDdEQsSUFBSSxVQUFVLEdBQUcsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztRQUMvRCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNyQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN0RixDQUFDO0lBRUQscUNBQWEsR0FBYixVQUFjLEtBQUs7UUFDZixPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3ZCLENBQUM7SUE3U1EsYUFBYTtRQUx6QixnQkFBUyxDQUFDO1lBQ1AsUUFBUSxFQUFFLE1BQU07WUFDaEIsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFdBQVcsRUFBRSx1QkFBdUI7U0FDdkMsQ0FBQzt5Q0FZd0MsaUNBQWUsRUFBNkIseUJBQWdCO1lBQzlFLGVBQU0sRUFBZ0IsYUFBTTtPQVp2QyxhQUFhLENBOFN6QjtJQUFELG9CQUFDO0NBQUEsQUE5U0QsSUE4U0M7QUE5U1ksc0NBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgTmdab25lIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IFJhZFNpZGVEcmF3ZXIgfSBmcm9tIFwibmF0aXZlc2NyaXB0LXVpLXNpZGVkcmF3ZXJcIjtcbmltcG9ydCAqIGFzIGFwcCBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9hcHBsaWNhdGlvblwiO1xuaW1wb3J0ICogYXMgR2VvbG9jYXRpb24gZnJvbSBcIm5hdGl2ZXNjcmlwdC1nZW9sb2NhdGlvblwiO1xuaW1wb3J0IHsgQWNjdXJhY3kgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy91aS9lbnVtc1wiOyAvLyB1c2VkIHRvIGRlc2NyaWJlIGF0IHdoYXQgYWNjdXJhY3kgdGhlIGxvY2F0aW9uIHNob3VsZCBiZSBnZXRcbmltcG9ydCB7IFNlYXJjaEJhciB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL3NlYXJjaC1iYXJcIjtcbmltcG9ydCB7IFNlbGVjdGVkSW5kZXhDaGFuZ2VkRXZlbnREYXRhIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1kcm9wLWRvd25cIjtcbmltcG9ydCB7IERhdGVQaWNrZXIgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy91aS9kYXRlLXBpY2tlclwiO1xuaW1wb3J0IHsgVGltZVBpY2tlciB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL3RpbWUtcGlja2VyXCI7XG5pbXBvcnQgeyBFdmVudERhdGEsIE9ic2VydmFibGUgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9kYXRhL29ic2VydmFibGVcIjtcbmltcG9ydCB7IEJpa2VQb29sU2VydmljZSB9IGZyb20gXCIuLi9zaGFyZWQvYmlrZXBvb2xzZXJ2aWNlXCI7XG5pbXBvcnQgeyBTZXJ2aWNlVVJMfSBmcm9tIFwiLi4vc2hhcmVkL3NlcnZpY2VzXCJcbmltcG9ydCAqIGFzIGRpYWxvZ3MgZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvdWkvZGlhbG9nc1wiO1xuaW1wb3J0IHsgUm91dGVyRXh0ZW5zaW9ucyB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9yb3V0ZXJcIjtcbmNvbnN0IGZpcmViYXNlID0gcmVxdWlyZShcIm5hdGl2ZXNjcmlwdC1wbHVnaW4tZmlyZWJhc2VcIik7XG5pbXBvcnQgKiBhcyBBcHBsaWNhdGlvblNldHRpbmdzIGZyb20gXCJhcHBsaWNhdGlvbi1zZXR0aW5nc1wiO1xuaW1wb3J0IHsgUm91dGVyLCBOYXZpZ2F0aW9uRXh0cmFzIH0gZnJvbSBcIkBhbmd1bGFyL3JvdXRlclwiO1xuXG5AQ29tcG9uZW50KHtcbiAgICBzZWxlY3RvcjogXCJIb21lXCIsXG4gICAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcbiAgICB0ZW1wbGF0ZVVybDogXCIuL2hvbWUuY29tcG9uZW50Lmh0bWxcIlxufSlcbmV4cG9ydCBjbGFzcyBIb21lQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcblxuICAgIGN1cnJlbnRMb2NhdGlvbjogc3RyaW5nID0gXCJUcmlwbGljYW5lXCI7XG4gICAgaXRlbXM6IGFueTtcbiAgICBzZWFyY2hQaHJhc2U6IHN0cmluZztcbiAgICBGcm9tTGF0OiBzdHJpbmc7XG4gICAgRnJvbUxvbmc6IHN0cmluZztcbiAgICBUb0xhdDogc3RyaW5nO1xuICAgIFRvTG9uZzogc3RyaW5nO1xuICAgIHRvdGFsUmlkZURpc3RhbmNlOiBhbnk7XG5cbiAgICBjb25zdHJ1Y3Rvcihwcml2YXRlIGJpa2Vwb29sc2VydmljZTogKEJpa2VQb29sU2VydmljZSksIHByaXZhdGUgcm91dGVyRXh0ZW5zaW9uczogUm91dGVyRXh0ZW5zaW9ucyxcbiAgICAgICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlciwgcHJpdmF0ZSB6b25lOiBOZ1pvbmUpIHtcbiAgICAgICAgLy8gVXNlIHRoZSBjb21wb25lbnQgY29uc3RydWN0b3IgdG8gaW5qZWN0IHByb3ZpZGVycy5cbiAgICB9XG5cbiAgICBuZ09uSW5pdCgpOiB2b2lkIHtcblxuICAgICAgICAvL3RoaXMuQ2xlYXJSaWRlU2V0dGluZ3MoKTtcbiAgICAgICAgdGhpcy5pdGVtcyA9IFtdO1xuICAgICAgICB0aGlzLml0ZW1zLnB1c2goXCJDYXJcIik7XG4gICAgICAgIHRoaXMuaXRlbXMucHVzaChcIkJpa2VcIik7XG5cbiAgICAgICAgLy8gY2FsbCBzZXREYXRlUGlja2VyVGltZSBtZXRob2RcbiAgICAgICAgdGhpcy5zZXREYXRlUGlja2VyVGltZSgpO1xuXG4gICAgICAgIC8vIEluaXQgeW91ciBjb21wb25lbnQgcHJvcGVydGllcyBoZXJlLlxuICAgICAgICBsZXQgbG9jYXRpb24gPSB0aGlzLmdldERldmljZUxvY2F0aW9uKCk7XG5cbiAgICAgICAgdGhpcy5Jbml0RmlyZUJhc2VQbHVnSW4oKTtcblxuICAgICAgICB0aGlzLnVwZGF0ZVN0YXR1c0F2YWlsKCk7XG4gICAgfVxuXG4gICAgc2V0RGF0ZVBpY2tlclRpbWUoKSB7XG4gICAgICAgIGxldCBkYXRlID0gbmV3IERhdGUoKTtcbiAgICAgICAgY29uc3QgZGF0ZVBpY2tlciA9IG5ldyBEYXRlUGlja2VyKCk7XG4gICAgICAgIGRhdGVQaWNrZXIuZGF5ID0gZGF0ZS5nZXREYXRlKCk7XG4gICAgICAgIGRhdGVQaWNrZXIubW9udGggPSBkYXRlLmdldE1vbnRoKCkgKyAxO1xuICAgICAgICBkYXRlUGlja2VyLnllYXIgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XG4gICAgICAgIGRhdGVQaWNrZXIuZGF0ZSA9IG5ldyBEYXRlKCk7IC8vIHVzaW5nIERhdGUgb2JqZWN0XG5cbiAgICAgICAgZGF0ZVBpY2tlci5taW5EYXRlID0gbmV3IERhdGUoZGF0ZS5nZXRGdWxsWWVhcigpLCBkYXRlLmdldE1vbnRoKCkgKyAxLCBkYXRlLmdldERhdGUoKSk7XG4gICAgICAgIGRhdGVQaWNrZXIubWF4RGF0ZSA9IG5ldyBEYXRlKDIwNDAsIDQsIDIwKTtcbiAgICB9XG5cbiAgICB1cGRhdGVTdGF0dXNBdmFpbCgpIHtcblxuICAgICAgICBmaXJlYmFzZS5hZGRWYWx1ZUV2ZW50TGlzdGVuZXIoZGF0YSA9PiB7XG4gICAgICAgICAgICBsZXQgU3RhdHVzO1xuICAgICAgICAgICAgaWYgKGRhdGEudmFsdWUpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnU3RhdHVzOiBPbmxpbmUnKTtcbiAgICAgICAgICAgICAgICBTdGF0dXMgPSBcIk9ubGluZVwiO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnU3RhdHVzOiBPZmZsaW5lJyk7XG4gICAgICAgICAgICAgICAgU3RhdHVzID0gXCJPZmZsaW5lXCI7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGxldCBvYmpVcGRhdGVVc2VyTG9jYXRpb24gPVxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgdXNlcmlkOiBBcHBsaWNhdGlvblNldHRpbmdzLmdldFN0cmluZyhcInVzZXJpZFwiKSxcbiAgICAgICAgICAgICAgICAgICAgbG9uZ2l0dWRlOiB0aGlzLkZyb21MYXQsXG4gICAgICAgICAgICAgICAgICAgIGxhdGl0dWRlOiB0aGlzLkZyb21Mb25nLFxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IFN0YXR1c1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIHRoaXMuYmlrZXBvb2xzZXJ2aWNlLlBvc3RTZXJ2aWNlKFNlcnZpY2VVUkwuUmlkZVVwZGF0ZVVzZXJMb2NhdGlvbixvYmpVcGRhdGVVc2VyTG9jYXRpb24pLnN1YnNjcmliZShcbiAgICAgICAgICAgIC8vICAgICBzdWNjZXNzID0+IGNvbnNvbGUubG9nKHN1Y2Nlc3MpLFxuICAgICAgICAgICAgLy8gICAgIGVycm9yID0+IGNvbnNvbGUubG9nKFwidXBkYXRlZGV2aWNlbG9jYXRpb25cIiArIGVycm9yKVxuICAgICAgICAgICAgLy8gKVxuICAgICAgICB9LCAnLmluZm8vY29ubmVjdGVkJyk7XG4gICAgfVxuXG4gICAgSW5pdEZpcmVCYXNlUGx1Z0luKCkge1xuICAgICAgICBmaXJlYmFzZS5pbml0KHtcbiAgICAgICAgICAgIC8vcGVyc2lzdCBzaG91bGQgYmUgc2V0IHRvIGZhbHNlIGFzIG90aGVyd2lzZSBudW1iZXJzIGFyZW4ndCByZXR1cm5lZCBkdXJpbmcgbGl2ZXN5bmNcbiAgICAgICAgICAgIHBlcnNpc3Q6IGZhbHNlLFxuICAgICAgICAgICAgdXJsOiBcImh0dHBzOi8vbWV0cm9hcHBsaWNhdGlvbnByb2plY3QuZmlyZWJhc2Vpby5jb21cIixcbiAgICAgICAgICAgIG9uUHVzaFRva2VuUmVjZWl2ZWRDYWxsYmFjazogZnVuY3Rpb24gKHRva2VuKSB7XG4gICAgICAgICAgICAgICAgQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoJ2RldmljZV90b2tlbicsIHRva2VuKTtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnZGV2aWNlIHRva2VuOiAnLCB0b2tlbik7IC8vIDwtLSBhZGQgdGhpc1xuICAgICAgICAgICAgfSxcblxuICAgICAgICAgICAgb25NZXNzYWdlUmVjZWl2ZWRDYWxsYmFjazogKG1lc3NhZ2U6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgIGxldCBvYmpOb3RpZmljYXRpb25NZXNzYWdlID0gbWVzc2FnZS5kYXRhLnZhbHVlO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKG1lc3NhZ2UuZGF0YS52YWx1ZSk7XG4gICAgICAgICAgICAgICAgbGV0IG5hdmlnYXRpb25FeHRyYXM6IE5hdmlnYXRpb25FeHRyYXMgPSB7XG4gICAgICAgICAgICAgICAgICAgIHF1ZXJ5UGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBvYmpOb3RpZmljYXRpb25NZXNzYWdlXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgdGhpcy5yb3V0ZXIubmF2aWdhdGUoW1wicmlkZWluZm9cIl0sIG5hdmlnYXRpb25FeHRyYXMpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG5vdGlmaWNhdGlvbkNhbGxiYWNrQW5kcm9pZDogKG1lc3NhZ2U6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KG1lc3NhZ2UpKTtcblxuICAgICAgICAgICAgICAgIC8vaWYgKG1lc3NhZ2UuZm9yZWdyb3VuZCA9PSBmYWxzZSkge1xuICAgICAgICAgICAgICAgIGRpYWxvZ3MuYWxlcnQoe1xuICAgICAgICAgICAgICAgICAgICB0aXRsZTogXCJPbiBkIFZheVwiLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIlJpZGVycyBSZXF1ZXN0ZWQgTm90aWZpY2F0aW9uXCIsXG4gICAgICAgICAgICAgICAgICAgIG9rQnV0dG9uVGV4dDogXCJva1wiXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgLy8gfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2coXCJNZXNzYWdlIHJlY2VpdmVkIHdoZW4gaW5zaWRlIHRoZSBhcHBcIik7XG4gICAgICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG9uQXV0aFN0YXRlQ2hhbmdlZDogKGRhdGE6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKEpTT04uc3RyaW5naWZ5KGRhdGEpKVxuICAgICAgICAgICAgICAgIGlmIChkYXRhLmxvZ2dlZEluKSB7XG4gICAgICAgICAgICAgICAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwidXNlcmlkXCIsIGRhdGEudXNlci51aWQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgQXBwbGljYXRpb25TZXR0aW5ncy5yZW1vdmUoXCJ1c2VyaWRcIik7XG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiT25BdXRoU3RhdGVcIiArIGRhdGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSkudGhlbihcbiAgICAgICAgICAgIGZ1bmN0aW9uIChpbnN0YW5jZSkge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZmlyZWJhc2UuaW5pdCBkb25lXCIpO1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGluc3RhbmNlKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBmdW5jdGlvbiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImZpcmViYXNlLmluaXQgZXJyb3I6IFwiICsgZXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgKTtcbiAgICB9XG5cbiAgICBvbkRhdGVQaWNrZXJMb2FkZWQoZGF0YTogRXZlbnREYXRhKSB7XG5cbiAgICB9XG5cbiAgICB1c2VybGF0aXR1ZGU6IGFueTtcbiAgICB1c2VybG9uZ3RpdHVkZTogYW55O1xuXG4gICAgcHJpdmF0ZSBnZXREZXZpY2VMb2NhdGlvbigpOiBQcm9taXNlPGFueT4ge1xuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgICAgR2VvbG9jYXRpb24uZW5hYmxlTG9jYXRpb25SZXF1ZXN0KCkudGhlbigoKSA9PiB7XG4gICAgICAgICAgICAgICAgR2VvbG9jYXRpb24uZ2V0Q3VycmVudExvY2F0aW9uKHsgdGltZW91dDogMTAwMDAgfSkudGhlbihsb2NhdGlvbiA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJlc29sdmUobG9jYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICAvLyBDYWxsIHVwZGF0ZURldmljZUxvY2F0aW9uIG1ldGhvZFxuICAgICAgICAgICAgICAgICAgICB0aGlzLnVzZXJsYXRpdHVkZSA9IGxvY2F0aW9uLmxhdGl0dWRlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnVzZXJsb25ndGl0dWRlID0gbG9jYXRpb24ubG9uZ2l0dWRlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZURldmljZUxvY2F0aW9uKGxvY2F0aW9uLmxhdGl0dWRlLCBsb2NhdGlvbi5sb25naXR1ZGUpO1xuICAgICAgICAgICAgICAgIH0pLmNhdGNoKGVycm9yID0+IHtcbiAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGVycm9yKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICB1cGRhdGVEZXZpY2VMb2NhdGlvbihsYXQsIGxvbmcpIHtcbiAgICAgICAgdGhpcy5Gcm9tTGF0ID0gbGF0OyB0aGlzLkZyb21Mb25nID0gbG9uZztcbiAgICAgICAgbGV0IGZvcm1VUkwgPSBcIj9wcm94PVwiICsgbGF0ICsgXCIsXCIgKyBsb25nO1xuICAgICAgICB0aGlzLmJpa2Vwb29sc2VydmljZS5HZXRBZGRyZXNzKGZvcm1VUkwpLnN1YnNjcmliZShcbiAgICAgICAgICAgIGFkZHJlc3MgPT4gdGhpcy5oYW5kbGVTdWNjZXNzRGV2aWNlTG9jKGFkZHJlc3MpLFxuICAgICAgICAgICAgZXJyb3IgPT4gdGhpcy5oYW5kbGVFcnJvckRldmljZUxvYyhlcnJvcikpXG4gICAgfVxuXG4gICAgaGFuZGxlU3VjY2Vzc0RldmljZUxvYyhzdWNjZXNzKSB7XG4gICAgICAgIGxldCBvYmpSZXN1bHQgPSBzdWNjZXNzLlJlc3BvbnNlLlZpZXdbMF0uUmVzdWx0WzBdO1xuICAgICAgICB0aGlzLmN1cnJlbnRMb2NhdGlvbiA9IG9ialJlc3VsdC5Mb2NhdGlvbi5BZGRyZXNzLkxhYmVsO1xuICAgICAgICB0aGlzLkZyb21MYXQgPSBvYmpSZXN1bHQuTG9jYXRpb24uRGlzcGxheVBvc2l0aW9uLkxhdGl0dWRlO1xuICAgICAgICB0aGlzLkZyb21Mb25nID0gb2JqUmVzdWx0LkxvY2F0aW9uLkRpc3BsYXlQb3NpdGlvbi5Mb25naXR1ZGU7XG4gICAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwiZnJvbWxhdFwiLCB0aGlzLkZyb21MYXQudG9TdHJpbmcoKSk7XG4gICAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwiZnJvbWxvbmdcIiwgdGhpcy5Gcm9tTG9uZy50b1N0cmluZygpKTtcbiAgICB9XG5cbiAgICBoYW5kbGVFcnJvckRldmljZUxvYyhlcnJvcikgeyB9XG5cbiAgICBwdWJsaWMgb25TdWJtaXQoYXJncykge1xuICAgICAgICBsZXQgc2VhcmNoQmFyID0gPFNlYXJjaEJhcj5hcmdzLm9iamVjdDtcbiAgICAgICAgdGhpcy5iaWtlcG9vbHNlcnZpY2UuR2V0QWRkcmVzc0FDKHNlYXJjaEJhci50ZXh0KS5zdWJzY3JpYmUoXG4gICAgICAgICAgICBhYyA9PiB0aGlzLmhhbmRsZUFDU3VjY2VzcyhhYyksXG4gICAgICAgICAgICBlcnJvciA9PiB0aGlzLmhhbmRsZUFDRXJyb3IoZXJyb3IpKVxuICAgIH1cblxuICAgIHNldFJpZGVTZXR0aW5ncygpIHtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJjdXJyZW50bG9jYXRpb25cIix0aGlzLmN1cnJlbnRMb2NhdGlvbik7XG4gICAgICAgIC8vIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwidG9sb2NhdGlvblwiLHRoaXMuc2VhcmNoUGhyYXNlKTtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJyaWRlZGlzdGFuY2VcIix0aGlzLnRvdGFsUmlkZURpc3RhbmNlKTtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJyaWRldGltZVwiLHRoaXMuc2VsZWN0ZWRSaWRlVGltZSk7XG4gICAgICAgIC8vIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwiZnJvbWxhdFwiLHRoaXMuRnJvbUxhdCk7XG4gICAgICAgIC8vIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwiZnJvbWxvbmdcIix0aGlzLkZyb21Mb25nKTtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5zZXRTdHJpbmcoXCJ0b2xhdFwiLHRoaXMuVG9MYXQpO1xuICAgICAgICAvLyBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcInRvbG9uZ1wiLHRoaXMuVG9Mb25nKTtcbiAgICB9XG5cbiAgICBDbGVhclJpZGVTZXR0aW5ncygpIHtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5yZW1vdmUoXCJjdXJyZW50bG9jYXRpb25cIik7XG4gICAgICAgIC8vIEFwcGxpY2F0aW9uU2V0dGluZ3MucmVtb3ZlKFwidG9sb2NhdGlvblwiKTtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5yZW1vdmUoXCJyaWRlZGlzdGFuY2VcIik7XG4gICAgICAgIC8vIEFwcGxpY2F0aW9uU2V0dGluZ3MucmVtb3ZlKFwicmlkZXRpbWVcIik7XG4gICAgICAgIC8vIEFwcGxpY2F0aW9uU2V0dGluZ3MucmVtb3ZlKFwiZnJvbWxhdFwiKTtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5yZW1vdmUoXCJmcm9tbG9uZ1wiKTtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5yZW1vdmUoXCJ0b2xhdFwiKTtcbiAgICAgICAgLy8gQXBwbGljYXRpb25TZXR0aW5ncy5yZW1vdmUoXCJ0b2xvbmdcIik7XG4gICAgfVxuXG4gICAgaGFuZGxlQUNTdWNjZXNzKHN1Y2Nlc3MpIHtcbiAgICAgICAgbGV0IG9ialJlc3VsdCA9IHN1Y2Nlc3MuUmVzcG9uc2UuVmlld1swXS5SZXN1bHRbMF07XG4gICAgICAgIHRoaXMuc2VhcmNoUGhyYXNlID0gb2JqUmVzdWx0LkxvY2F0aW9uLkFkZHJlc3MuTGFiZWw7XG4gICAgICAgIHRoaXMuVG9MYXQgPSBvYmpSZXN1bHQuTG9jYXRpb24uRGlzcGxheVBvc2l0aW9uLkxhdGl0dWRlO1xuICAgICAgICB0aGlzLlRvTG9uZyA9IG9ialJlc3VsdC5Mb2NhdGlvbi5EaXNwbGF5UG9zaXRpb24uTG9uZ2l0dWRlO1xuICAgICAgICBBcHBsaWNhdGlvblNldHRpbmdzLnNldFN0cmluZyhcImN1cnJlbnRsb2NhdGlvblwiLCB0aGlzLmN1cnJlbnRMb2NhdGlvbik7XG4gICAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwidG9sb2NhdGlvblwiLCB0aGlzLnNlYXJjaFBocmFzZSk7XG4gICAgICAgIHRoaXMuQ2FsY3VsYXRlRGlzdGFuY2UoKTtcbiAgICB9XG5cbiAgICBoYW5kbGVBQ0Vycm9yKGVycm9yKSB7IH1cblxuICAgIHB1YmxpYyBvblRleHRDaGFuZ2VkKGFyZ3MpIHtcbiAgICAgICAgbGV0IHNlYXJjaEJhciA9IDxTZWFyY2hCYXI+YXJncy5vYmplY3Q7XG4gICAgfVxuXG4gICAgcHVibGljIG9uQ2xlYXIoYXJncykge1xuICAgICAgICBsZXQgc2VhcmNoQmFyID0gPFNlYXJjaEJhcj5hcmdzLm9iamVjdDtcbiAgICAgICAgc2VhcmNoQmFyLnRleHQgPSBcIlwiO1xuICAgICAgICBzZWFyY2hCYXIuaGludCA9IFwiRW50ZXIgTG9jYXRpb25cIjtcbiAgICB9XG5cbiAgICBwdWJsaWMgb25jaGFuZ2UoYXJnczogU2VsZWN0ZWRJbmRleENoYW5nZWRFdmVudERhdGEpIHtcbiAgICAgICAgY29uc29sZS5sb2coYERyb3AgRG93biBzZWxlY3RlZCBpbmRleCBjaGFuZ2VkIGZyb20gJHthcmdzLm9sZEluZGV4fSB0byAke2FyZ3MubmV3SW5kZXh9YCk7XG4gICAgfVxuXG4gICAgcHVibGljIG9ub3BlbigpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJEcm9wIERvd24gb3BlbmVkLlwiKTtcbiAgICB9XG5cbiAgICBwdWJsaWMgb25jbG9zZSgpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJEcm9wIERvd24gY2xvc2VkLlwiKTtcbiAgICB9XG5cbiAgICBvbkRyYXdlckJ1dHRvblRhcCgpOiB2b2lkIHtcbiAgICAgICAgY29uc3Qgc2lkZURyYXdlciA9IDxSYWRTaWRlRHJhd2VyPmFwcC5nZXRSb290VmlldygpO1xuICAgICAgICBzaWRlRHJhd2VyLnNob3dEcmF3ZXIoKTtcbiAgICB9XG5cbiAgICBvbkZpbmRSaWRlcnMoZXZlbnQpIHtcbiAgICAgICAgLy90aGlzLnNldFJpZGVTZXR0aW5ncygpO1xuICAgICAgICB0aGlzLnJvdXRlckV4dGVuc2lvbnMubmF2aWdhdGUoW1wiL3JpZGVyc2xpc3RcIl0sIHsgY2xlYXJIaXN0b3J5OiB0cnVlIH0pO1xuICAgIH1cblxuICAgIG9uUGlja2VyTG9hZGVkKGFyZ3MpIHtcbiAgICAgICAgbGV0IHRpbWVQaWNrZXIgPSA8VGltZVBpY2tlcj5hcmdzLm9iamVjdDtcblxuICAgICAgICB2YXIgdG9kYXkgPSBuZXcgRGF0ZSgpO1xuICAgICAgICB2YXIgdGltZSA9IHRvZGF5LmdldEhvdXJzKCk7XG5cbiAgICAgICAgdGltZVBpY2tlci5ob3VyID0gdGltZTtcbiAgICAgICAgdGltZVBpY2tlci5taW51dGUgPSB0b2RheS5nZXRNaW51dGVzKCkgKyAxMDtcblxuICAgICAgICBsZXQgcGVyaW9kaWFuID0gKHRpbWVQaWNrZXIuaG91ciA+PSAxMikgPyBcImFtXCIgOiBcInBtXCJcbiAgICAgICAgdGhpcy5zZWxlY3RlZFJpZGVUaW1lID0gdGltZVBpY2tlci5ob3VyICsgdGltZVBpY2tlci5taW51dGUgKyBwZXJpb2RpYW47XG4gICAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwicmlkZXRpbWVcIiwgdGhpcy5zZWxlY3RlZFJpZGVUaW1lKTtcbiAgICB9XG5cbiAgICBzZWxlY3RlZFJpZGVUaW1lOiBzdHJpbmc7XG5cbiAgICBvblRpbWVDaGFuZ2VkKGFyZ3MpIHtcblxuICAgICAgICBsZXQgdG90YWxUaW1lO1xuICAgICAgICBsZXQgaG91ciA9IGFyZ3MudmFsdWUuZ2V0SG91cnMoKTtcbiAgICAgICAgbGV0IG1pbnV0ZXMgPSBhcmdzLnZhbHVlLmdldE1pbnV0ZXMoKTtcblxuICAgICAgICBpZiAocGFyc2VGbG9hdChob3VyKSA+PSAxMikge1xuICAgICAgICAgICAgbGV0IEZvcm1hdEhvdXIgPSBwYXJzZUZsb2F0KGhvdXIpIC0gMTI7XG4gICAgICAgICAgICB0aGlzLnNlbGVjdGVkUmlkZVRpbWUgPSAoRm9ybWF0SG91ciA9PSAwKSA/IFwiMTJcIiA6IEZvcm1hdEhvdXIudG9TdHJpbmcoKSArIFwiIDogXCIgKyBtaW51dGVzICsgXCIgcG1cIjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRSaWRlVGltZSA9IHBhcnNlRmxvYXQoaG91cikudG9TdHJpbmcoKSArIFwiIDogXCIgKyBtaW51dGVzLnRvU3RyaW5nKCkgKyBcIiBhbVwiO1xuICAgICAgICB9XG4gICAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwicmlkZXRpbWVcIiwgdGhpcy5zZWxlY3RlZFJpZGVUaW1lKTtcbiAgICAgICAgLy90aGlzLnNldFJpZGVTZXR0aW5ncygpO1xuICAgIH1cblxuICAgIENhbGN1bGF0ZURpc3RhbmNlKCkge1xuICAgICAgICBsZXQgbG9jYXRpb25Gcm9tID0gbmV3IEdlb2xvY2F0aW9uLkxvY2F0aW9uKCk7XG4gICAgICAgIGxvY2F0aW9uRnJvbS5sYXRpdHVkZSA9IHBhcnNlRmxvYXQodGhpcy5Gcm9tTGF0KTtcbiAgICAgICAgbG9jYXRpb25Gcm9tLmxvbmdpdHVkZSA9IHBhcnNlRmxvYXQodGhpcy5Gcm9tTG9uZyk7XG5cbiAgICAgICAgbGV0IGxvY2F0aW9uVG8gPSBuZXcgR2VvbG9jYXRpb24uTG9jYXRpb24oKTtcbiAgICAgICAgbG9jYXRpb25Uby5sYXRpdHVkZSA9IHBhcnNlRmxvYXQodGhpcy5Ub0xhdCk7XG4gICAgICAgIGxvY2F0aW9uVG8ubG9uZ2l0dWRlID0gcGFyc2VGbG9hdCh0aGlzLlRvTG9uZyk7XG5cbiAgICAgICAgdmFyIHVybCA9IFwid2F5cG9pbnQwPVwiICsgdGhpcy5Gcm9tTGF0ICsgXCIsXCIgKyB0aGlzLkZyb21Mb25nICsgXCImd2F5cG9pbnQxPVwiICsgdGhpcy5Ub0xhdCArIFwiLFwiICsgdGhpcy5Ub0xvbmdcbiAgICAgICAgY29uc29sZS5sb2codXJsKTtcbiAgICAgICAgdGhpcy5iaWtlcG9vbHNlcnZpY2UuR2V0RGlzdGFuY2UodXJsKS5zdWJzY3JpYmUoXG4gICAgICAgICAgICBkaXN0YW5jZSA9PiB0aGlzLmRpc3RhbmNlc3VjY2VzcyhkaXN0YW5jZSksXG4gICAgICAgICAgICBlcnJvciA9PiB0aGlzLmRpc3RhbmNlZXJyb3IoZXJyb3IpXG4gICAgICAgIClcbiAgICB9XG5cbiAgICBkaXN0YW5jZXN1Y2Nlc3MoZGlzdGFuY2UpIHtcbiAgICAgICAgbGV0IGRpc3QgPSBkaXN0YW5jZS5yZXNwb25zZS5yb3V0ZVswXS5zdW1tYXJ5LmRpc3RhbmNlXG4gICAgICAgIGxldCB0cmF2ZWxUaW1lID0gZGlzdGFuY2UucmVzcG9uc2Uucm91dGVbMF0uc3VtbWFyeS50cmF2ZWxUaW1lO1xuICAgICAgICB0aGlzLnRvdGFsUmlkZURpc3RhbmNlID0gZGlzdCAvIDEwMDA7XG4gICAgICAgIEFwcGxpY2F0aW9uU2V0dGluZ3Muc2V0U3RyaW5nKFwicmlkZWRpc3RhbmNlXCIsIHRoaXMudG90YWxSaWRlRGlzdGFuY2UudG9TdHJpbmcoMikpO1xuICAgIH1cblxuICAgIGRpc3RhbmNlZXJyb3IoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xuICAgIH1cbn1cbiJdfQ==